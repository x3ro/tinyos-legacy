/**
 * CelsiusConverter.java is a 1.4 application that 
 * demonstrates the use of JButton, JTextField and
 * JLabel.  It requires no other files.
 */

package net.tinyos.serialdemo;

// Mote console interface
import net.tinyos.util.*;
//import java.io.*;
import net.tinyos.packet.*;
import net.tinyos.message.*;

import java.util.*;
import java.text.*;
// Mote console interface

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class SerialDemo implements ActionListener, MessageListener {
	
	private static SerialDemo demo;
	
    //Specify the look and feel to use.  Valid values:
    //null (use the default), "Metal", "System", "Motif", "GTK+"
    final static String LOOKANDFEEL = "System";
    private static String lookAndFeel = null;
    public static JFrame mainFrame;
    
    // Setup and create the JNI interface for the motelist app
	private native String getDevices(String arguments);
	//static {
	//    System.loadLibrary("configtool");
	//}
    private static PhoenixSource serialStub;
    private static String connection;
    private static String[] availablePorts;
    //public SFListen listenServer;
    //public String motecom = "serial@COM3";
    
    // Setup and create the system time globals
	Calendar currentTime;
	
	// Mote console interface
    public static final byte LED_ON = 1;
    public static final byte LED_OFF = 2;
    public static final byte SEND_DATA = 3;
    public static final byte SERIAL_DATA = 4;
    
    // Create a define for the broadcast message address
    public static final short TOS_BCAST_ADDR = (short) 0xffff;
	
	// Create the text area for displaying the raw messages.
	private static JTextArea msgLog;
	
	// Create the console message control bytes.
	private static JFormattedTextField consoleSourceID;
	private static JFormattedTextField consoleLength;
	private static JFormattedTextField consoleMsgType;
	
	// Create the received data byte text fields.
	private static JFormattedTextField consoleData1;
	private static JFormattedTextField consoleData2;
	private static JFormattedTextField consoleData3;
	private static JFormattedTextField consoleData4;
	private static JFormattedTextField consoleData5;
	private static JFormattedTextField consoleData6;
	private static JFormattedTextField consoleData7;
	private static JFormattedTextField consoleData8;
	private static JFormattedTextField consoleData9;
	private static JFormattedTextField consoleData10;
	private static JFormattedTextField consoleData11;
	private static JFormattedTextField consoleData12;
	private static JFormattedTextField consoleData13;
	private static JFormattedTextField consoleData14;
	private static JFormattedTextField consoleData15;
	private static JFormattedTextField consoleData16;
	private static JFormattedTextField consoleData17;
	private static JFormattedTextField consoleData18;
	private static JFormattedTextField consoleData19;
	private static JFormattedTextField consoleData20;
	
	// Create the command message control bytes.
	private static JFormattedTextField commandSeqNumber;
	private static JFormattedTextField commandHopCount;
	private static JFormattedTextField commandSourceAddr;
	private static JFormattedTextField commandDestinationAddr;
	private static JFormattedTextField commandMsgType;
	private static JFormattedTextField commandLength;
	
	// Create the command message data text fields.
	private static JFormattedTextField commandData1;
	private static JFormattedTextField commandData2;
	private static JFormattedTextField commandData3;
	private static JFormattedTextField commandData4;
	private static JFormattedTextField commandData5;
	private static JFormattedTextField commandData6;
	private static JFormattedTextField commandData7;
	private static JFormattedTextField commandData8;
	private static JFormattedTextField commandData9;
	private static JFormattedTextField commandData10;
	private static JFormattedTextField commandData11;
	private static JFormattedTextField commandData12;
	private static JFormattedTextField commandData13;
	private static JFormattedTextField commandData14;
	private static JFormattedTextField commandData15;
	private static JFormattedTextField commandData16;
	private static JFormattedTextField commandData17;
	private static JFormattedTextField commandData18;
	private static JFormattedTextField commandData19;
	private static JFormattedTextField commandData20;
	
	//Create the message types
	private static MoteIF mote;
	
    private JPanel createMessagePanel() {
    	JPanel messagePane = new JPanel(new GridBagLayout());
    	GridBagConstraints c = new GridBagConstraints();
    	JPanel receiveSubPane = new JPanel(new GridLayout(2, 23));
		JPanel sendSubPane = new JPanel(new GridLayout(2, 26));
    	
        //Create the received console message labels.
        JLabel consoleSourceIDLabel = new JLabel("Src",  SwingConstants.CENTER);
		JLabel consoleLengthLabel = new JLabel("Len",  SwingConstants.CENTER);
		JLabel consoleMsgTypeLabel = new JLabel("Msg",  SwingConstants.CENTER);
		JLabel consoleData1Label = new JLabel("1",  SwingConstants.CENTER);
		JLabel consoleData2Label = new JLabel("2",  SwingConstants.CENTER);
		JLabel consoleData3Label = new JLabel("3",  SwingConstants.CENTER);
		JLabel consoleData4Label = new JLabel("4",  SwingConstants.CENTER);
		JLabel consoleData5Label = new JLabel("5",  SwingConstants.CENTER);
		JLabel consoleData6Label = new JLabel("6",  SwingConstants.CENTER);
		JLabel consoleData7Label = new JLabel("7",  SwingConstants.CENTER);
		JLabel consoleData8Label = new JLabel("8",  SwingConstants.CENTER);
		JLabel consoleData9Label = new JLabel("9",  SwingConstants.CENTER);
		JLabel consoleData10Label = new JLabel("10",  SwingConstants.CENTER);
		JLabel consoleData11Label = new JLabel("11",  SwingConstants.CENTER);
		JLabel consoleData12Label = new JLabel("12",  SwingConstants.CENTER);
		JLabel consoleData13Label = new JLabel("13",  SwingConstants.CENTER);
		JLabel consoleData14Label = new JLabel("14",  SwingConstants.CENTER);
		JLabel consoleData15Label = new JLabel("15",  SwingConstants.CENTER);
		JLabel consoleData16Label = new JLabel("16",  SwingConstants.CENTER);
		JLabel consoleData17Label = new JLabel("17",  SwingConstants.CENTER);
		JLabel consoleData18Label = new JLabel("18",  SwingConstants.CENTER);
		JLabel consoleData19Label = new JLabel("19",  SwingConstants.CENTER);
		JLabel consoleData20Label = new JLabel("20",  SwingConstants.CENTER);
		
		//Create the received console message text fields.
		consoleSourceID = new JFormattedTextField(new DecimalFormat("####0"));
		consoleSourceID.setColumns(5);
		consoleSourceID.setEditable(false);
		consoleSourceID.setHorizontalAlignment(JTextField.CENTER);
		consoleSourceID.setText("0");
		
		consoleLength = new JFormattedTextField(new DecimalFormat("#0"));
		consoleLength.setColumns(2);
		consoleLength.setEditable(false);
		consoleLength.setHorizontalAlignment(JTextField.CENTER);
		consoleLength.setText("0");
		
		consoleMsgType = new JFormattedTextField(new DecimalFormat("##0"));
		consoleMsgType.setColumns(3);
		consoleMsgType.setEditable(false);
		consoleMsgType.setHorizontalAlignment(JTextField.CENTER);
		consoleMsgType.setText("0");
		
		consoleData1 = new JFormattedTextField();
		consoleData1.setColumns(2);
		consoleData1.setEditable(false);
		consoleData1.setHorizontalAlignment(JTextField.CENTER);
		consoleData1.setText("00");
		
		consoleData2 = new JFormattedTextField();
		consoleData2.setColumns(2);
		consoleData2.setEditable(false);
		consoleData2.setHorizontalAlignment(JTextField.CENTER);
		consoleData2.setText("00");
		
		consoleData3 = new JFormattedTextField();
		consoleData3.setColumns(2);
		consoleData3.setEditable(false);
		consoleData3.setHorizontalAlignment(JTextField.CENTER);
		consoleData3.setText("00");
		
		consoleData4 = new JFormattedTextField();
		consoleData4.setColumns(2);
		consoleData4.setEditable(false);
		consoleData4.setHorizontalAlignment(JTextField.CENTER);
		consoleData4.setText("00");
		
		consoleData5 = new JFormattedTextField();
		consoleData5.setColumns(2);
		consoleData5.setEditable(false);
		consoleData5.setHorizontalAlignment(JTextField.CENTER);
		consoleData5.setText("00");
		
		consoleData6 = new JFormattedTextField();
		consoleData6.setColumns(2);
		consoleData6.setEditable(false);
		consoleData6.setHorizontalAlignment(JTextField.CENTER);
		consoleData6.setText("00");
		
		consoleData7 = new JFormattedTextField();
		consoleData7.setColumns(2);
		consoleData7.setEditable(false);
		consoleData7.setHorizontalAlignment(JTextField.CENTER);
		consoleData7.setText("00");
		
		consoleData8 = new JFormattedTextField();
		consoleData8.setColumns(2);
		consoleData8.setEditable(false);
		consoleData8.setHorizontalAlignment(JTextField.CENTER);
		consoleData8.setText("00");
		
		consoleData9 = new JFormattedTextField();
		consoleData9.setColumns(2);
		consoleData9.setEditable(false);
		consoleData9.setHorizontalAlignment(JTextField.CENTER);
		consoleData9.setText("00");
		
		consoleData10 = new JFormattedTextField();
		consoleData10.setColumns(2);
		consoleData10.setEditable(false);
		consoleData10.setHorizontalAlignment(JTextField.CENTER);
		consoleData10.setText("00");
		
		consoleData11 = new JFormattedTextField();
		consoleData11.setColumns(2);
		consoleData11.setEditable(false);
		consoleData11.setHorizontalAlignment(JTextField.CENTER);
		consoleData11.setText("00");

		consoleData12 = new JFormattedTextField();
		consoleData12.setColumns(2);
		consoleData12.setEditable(false);
		consoleData12.setHorizontalAlignment(JTextField.CENTER);
		consoleData12.setText("00");
		
		consoleData13 = new JFormattedTextField();
		consoleData13.setColumns(2);
		consoleData13.setEditable(false);
		consoleData13.setHorizontalAlignment(JTextField.CENTER);
		consoleData13.setText("00");
		
		consoleData14 = new JFormattedTextField();
		consoleData14.setColumns(2);
		consoleData14.setEditable(false);
		consoleData14.setHorizontalAlignment(JTextField.CENTER);
		consoleData14.setText("00");
		
		consoleData15 = new JFormattedTextField();
		consoleData15.setColumns(2);
		consoleData15.setEditable(false);
		consoleData15.setHorizontalAlignment(JTextField.CENTER);
		consoleData15.setText("00");
		
		consoleData16 = new JFormattedTextField();
		consoleData16.setColumns(2);
		consoleData16.setEditable(false);
		consoleData16.setHorizontalAlignment(JTextField.CENTER);
		consoleData16.setText("00");
		
		consoleData17 = new JFormattedTextField();
		consoleData17.setColumns(2);
		consoleData17.setEditable(false);
		consoleData17.setHorizontalAlignment(JTextField.CENTER);
		consoleData17.setText("00");
		
		consoleData18 = new JFormattedTextField();
		consoleData18.setColumns(2);
		consoleData18.setEditable(false);
		consoleData18.setHorizontalAlignment(JTextField.CENTER);
		consoleData18.setText("00");
		
		consoleData19 = new JFormattedTextField();
		consoleData19.setColumns(2);
		consoleData19.setEditable(false);
		consoleData19.setHorizontalAlignment(JTextField.CENTER);
		consoleData19.setText("00");
		
		consoleData20 = new JFormattedTextField();
		consoleData20.setColumns(2);
		consoleData20.setEditable(false);
		consoleData20.setHorizontalAlignment(JTextField.CENTER);
		consoleData20.setText("00");
		
		//Add labels and fields to receive pane.
		receiveSubPane.add(consoleSourceIDLabel);
		receiveSubPane.add(consoleLengthLabel);
		receiveSubPane.add(consoleMsgTypeLabel);
		receiveSubPane.add(consoleData1Label);
		receiveSubPane.add(consoleData2Label);
		receiveSubPane.add(consoleData3Label);
		receiveSubPane.add(consoleData4Label);
		receiveSubPane.add(consoleData5Label);
		receiveSubPane.add(consoleData6Label);
		receiveSubPane.add(consoleData7Label);
		receiveSubPane.add(consoleData8Label);
		receiveSubPane.add(consoleData9Label);
		receiveSubPane.add(consoleData10Label);
		receiveSubPane.add(consoleData11Label);
		receiveSubPane.add(consoleData12Label);
		receiveSubPane.add(consoleData13Label);
		receiveSubPane.add(consoleData14Label);
		receiveSubPane.add(consoleData15Label);
		receiveSubPane.add(consoleData16Label);
		receiveSubPane.add(consoleData17Label);
		receiveSubPane.add(consoleData18Label);
		receiveSubPane.add(consoleData19Label);
		receiveSubPane.add(consoleData20Label);
		
		receiveSubPane.add(consoleSourceID);
		receiveSubPane.add(consoleLength);
		receiveSubPane.add(consoleMsgType);
		receiveSubPane.add(consoleData1);
		receiveSubPane.add(consoleData2);
		receiveSubPane.add(consoleData3);
		receiveSubPane.add(consoleData4);
		receiveSubPane.add(consoleData5);
		receiveSubPane.add(consoleData6);
		receiveSubPane.add(consoleData7);
		receiveSubPane.add(consoleData8);
		receiveSubPane.add(consoleData9);
		receiveSubPane.add(consoleData10);
		receiveSubPane.add(consoleData11);
		receiveSubPane.add(consoleData12);
		receiveSubPane.add(consoleData13);
		receiveSubPane.add(consoleData14);
		receiveSubPane.add(consoleData15);
		receiveSubPane.add(consoleData16);
		receiveSubPane.add(consoleData17);
		receiveSubPane.add(consoleData18);
		receiveSubPane.add(consoleData19);
		receiveSubPane.add(consoleData20);
		
		receiveSubPane.setBorder(BorderFactory.createCompoundBorder(
						   BorderFactory.createTitledBorder("Data Received"),
						   BorderFactory.createEmptyBorder(5,5,5,5)));
		
		// Create the command message control bytes.
		JLabel seqNumberLabel = new JLabel("Seq",  SwingConstants.CENTER);
		seqNumberLabel.setForeground(Color.RED);
		seqNumberLabel.setToolTipText("Why is this Red? It is used in all outgoing Messages.");
		JLabel hopCountLabel = new JLabel("Hop",  SwingConstants.CENTER);
		hopCountLabel.setForeground(Color.RED);
		hopCountLabel.setToolTipText("Why is this Red? It is used in all outgoing Messages.");
		JLabel commandSourceIDLabel = new JLabel("Src",  SwingConstants.CENTER);
		commandSourceIDLabel.setForeground(Color.RED);
		commandSourceIDLabel.setToolTipText("Why is this Red? It is used in all outgoing Messages.");
		JLabel destinationAddrLabel = new JLabel("Dst",  SwingConstants.CENTER);
		destinationAddrLabel.setForeground(Color.RED);
		destinationAddrLabel.setToolTipText("Why is this Red? It is used in all outgoing Messages.");
		
        //Create the received console message labels.
		JLabel commandLengthLabel = new JLabel("Len",  SwingConstants.CENTER);
		JLabel commandMsgTypeLabel = new JLabel("Msg",  SwingConstants.CENTER);
		JLabel commandData1Label = new JLabel("1",  SwingConstants.CENTER);
		JLabel commandData2Label = new JLabel("2",  SwingConstants.CENTER);
		JLabel commandData3Label = new JLabel("3",  SwingConstants.CENTER);
		JLabel commandData4Label = new JLabel("4",  SwingConstants.CENTER);
		JLabel commandData5Label = new JLabel("5",  SwingConstants.CENTER);
		JLabel commandData6Label = new JLabel("6",  SwingConstants.CENTER);
		JLabel commandData7Label = new JLabel("7",  SwingConstants.CENTER);
		JLabel commandData8Label = new JLabel("8",  SwingConstants.CENTER);
		JLabel commandData9Label = new JLabel("9",  SwingConstants.CENTER);
		JLabel commandData10Label = new JLabel("10",  SwingConstants.CENTER);
		JLabel commandData11Label = new JLabel("11",  SwingConstants.CENTER);
		JLabel commandData12Label = new JLabel("12",  SwingConstants.CENTER);
		JLabel commandData13Label = new JLabel("13",  SwingConstants.CENTER);
		JLabel commandData14Label = new JLabel("14",  SwingConstants.CENTER);
		JLabel commandData15Label = new JLabel("15",  SwingConstants.CENTER);
		JLabel commandData16Label = new JLabel("16",  SwingConstants.CENTER);
		JLabel commandData17Label = new JLabel("17",  SwingConstants.CENTER);
		JLabel commandData18Label = new JLabel("18",  SwingConstants.CENTER);
		JLabel commandData19Label = new JLabel("19",  SwingConstants.CENTER);
		JLabel commandData20Label = new JLabel("20",  SwingConstants.CENTER);
		
		//Create the received console message text fields.
		commandSeqNumber = new JFormattedTextField(new DecimalFormat("##0"));
		commandSeqNumber.setColumns(3);
		commandSeqNumber.setHorizontalAlignment(JTextField.CENTER);
		commandSeqNumber.setText("0");
		
		commandHopCount = new JFormattedTextField(new DecimalFormat("##0"));
		commandHopCount.setColumns(3);
		commandHopCount.setHorizontalAlignment(JTextField.CENTER);
		commandHopCount.setText("0");
		
		commandSourceAddr = new JFormattedTextField(new DecimalFormat("####0"));
		commandSourceAddr.setColumns(5);
		commandSourceAddr.setHorizontalAlignment(JTextField.CENTER);
		commandSourceAddr.setText("0");

		commandDestinationAddr = new JFormattedTextField(new DecimalFormat("####0"));
		commandDestinationAddr.setColumns(5);
		commandDestinationAddr.setHorizontalAlignment(JTextField.CENTER);
		// Set the default destination address to 1, the default of make if not specified
		commandDestinationAddr.setText("1");
		
		commandMsgType = new JFormattedTextField();
		commandMsgType.setColumns(3);
		commandMsgType.setHorizontalAlignment(JTextField.CENTER);
		// Set the default message type to the send serial device data
		commandMsgType.setText(Integer.toString(SEND_DATA));
		
		commandLength = new JFormattedTextField();
		commandLength.setColumns(3);
		commandLength.setHorizontalAlignment(JTextField.CENTER);
		commandLength.setText("0");

		commandData1 = new JFormattedTextField();
		commandData1.setColumns(2);
		commandData1.setHorizontalAlignment(JTextField.CENTER);
		commandData1.setText("00");
		
		commandData2 = new JFormattedTextField();
		commandData2.setColumns(2);
		commandData2.setHorizontalAlignment(JTextField.CENTER);
		commandData2.setText("00");
		
		commandData3 = new JFormattedTextField();
		commandData3.setColumns(2);
		commandData3.setHorizontalAlignment(JTextField.CENTER);
		commandData3.setText("00");
		
		commandData4 = new JFormattedTextField();
		commandData4.setColumns(2);
		commandData4.setHorizontalAlignment(JTextField.CENTER);
		commandData4.setText("00");
		
		commandData5 = new JFormattedTextField();
		commandData5.setColumns(2);
		commandData5.setHorizontalAlignment(JTextField.CENTER);
		commandData5.setText("00");
		
		commandData6 = new JFormattedTextField();
		commandData6.setColumns(2);
		commandData6.setHorizontalAlignment(JTextField.CENTER);
		commandData6.setText("00");
		
		commandData7 = new JFormattedTextField();
		commandData7.setColumns(2);
		commandData7.setHorizontalAlignment(JTextField.CENTER);
		commandData7.setText("00");
		
		commandData8 = new JFormattedTextField();
		commandData8.setColumns(2);
		commandData8.setHorizontalAlignment(JTextField.CENTER);
		commandData8.setText("00");
		
		commandData9 = new JFormattedTextField();
		commandData9.setColumns(2);
		commandData9.setHorizontalAlignment(JTextField.CENTER);
		commandData9.setText("00");
		
		commandData10 = new JFormattedTextField();
		commandData10.setColumns(2);
		commandData10.setHorizontalAlignment(JTextField.CENTER);
		commandData10.setText("00");
		
		commandData11 = new JFormattedTextField();
		commandData11.setColumns(2);
		commandData11.setHorizontalAlignment(JTextField.CENTER);
		commandData11.setText("00");
		
		commandData12 = new JFormattedTextField();
		commandData12.setColumns(2);
		commandData12.setHorizontalAlignment(JTextField.CENTER);
		commandData12.setText("00");
		
		commandData13 = new JFormattedTextField();
		commandData13.setColumns(2);
		commandData13.setHorizontalAlignment(JTextField.CENTER);
		commandData13.setText("00");
		
		commandData14 = new JFormattedTextField();
		commandData14.setColumns(2);
		commandData14.setHorizontalAlignment(JTextField.CENTER);
		commandData14.setText("00");
		
		commandData15 = new JFormattedTextField();
		commandData15.setColumns(2);
		commandData15.setHorizontalAlignment(JTextField.CENTER);
		commandData15.setText("00");
		
		commandData16 = new JFormattedTextField();
		commandData16.setColumns(2);
		commandData16.setHorizontalAlignment(JTextField.CENTER);
		commandData16.setText("00");
		
		commandData17 = new JFormattedTextField();
		commandData17.setColumns(2);
		commandData17.setHorizontalAlignment(JTextField.CENTER);
		commandData17.setText("00");
		
		commandData18 = new JFormattedTextField();
		commandData18.setColumns(2);
		commandData18.setHorizontalAlignment(JTextField.CENTER);
		commandData18.setText("00");
		
		commandData19 = new JFormattedTextField();
		commandData19.setColumns(2);
		commandData19.setHorizontalAlignment(JTextField.CENTER);
		commandData19.setText("00");
		
		commandData20 = new JFormattedTextField();
		commandData20.setColumns(2);
		commandData20.setHorizontalAlignment(JTextField.CENTER);
		commandData20.setText("00");
		
		//Add labels and fields to receive pane.
		sendSubPane.add(seqNumberLabel);
		sendSubPane.add(hopCountLabel);
		sendSubPane.add(commandSourceIDLabel);
		sendSubPane.add(destinationAddrLabel);
		sendSubPane.add(commandMsgTypeLabel);
		sendSubPane.add(commandLengthLabel);
		sendSubPane.add(commandData1Label);
		sendSubPane.add(commandData2Label);
		sendSubPane.add(commandData3Label);
		sendSubPane.add(commandData4Label);
		sendSubPane.add(commandData5Label);
		sendSubPane.add(commandData6Label);
		sendSubPane.add(commandData7Label);
		sendSubPane.add(commandData8Label);
		sendSubPane.add(commandData9Label);
		sendSubPane.add(commandData10Label);
		sendSubPane.add(commandData11Label);
		sendSubPane.add(commandData12Label);
		sendSubPane.add(commandData13Label);
		sendSubPane.add(commandData14Label);
		sendSubPane.add(commandData15Label);
		sendSubPane.add(commandData16Label);
		sendSubPane.add(commandData17Label);
		sendSubPane.add(commandData18Label);
		sendSubPane.add(commandData19Label);
		sendSubPane.add(commandData20Label);
		
		sendSubPane.add(commandSeqNumber);
		sendSubPane.add(commandHopCount);
		sendSubPane.add(commandSourceAddr);
		sendSubPane.add(commandDestinationAddr);
		sendSubPane.add(commandMsgType);
		sendSubPane.add(commandLength);
		sendSubPane.add(commandData1);
		sendSubPane.add(commandData2);
		sendSubPane.add(commandData3);
		sendSubPane.add(commandData4);
		sendSubPane.add(commandData5);
		sendSubPane.add(commandData6);
		sendSubPane.add(commandData7);
		sendSubPane.add(commandData8);
		sendSubPane.add(commandData9);
		sendSubPane.add(commandData10);
		sendSubPane.add(commandData11);
		sendSubPane.add(commandData12);
		sendSubPane.add(commandData13);
		sendSubPane.add(commandData14);
		sendSubPane.add(commandData15);
		sendSubPane.add(commandData16);
		sendSubPane.add(commandData17);
		sendSubPane.add(commandData18);
		sendSubPane.add(commandData19);
		sendSubPane.add(commandData20);
		
		sendSubPane.setBorder(BorderFactory.createCompoundBorder(
				   BorderFactory.createTitledBorder("Data to Send"),
				   BorderFactory.createEmptyBorder(5,5,5,5)));
		
		//Create button to send message to retrieve data bytes from serial device connected to mote
		JButton serialDataButton = new JButton("Get");
		serialDataButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        //Listen to events from the get button.
        serialDataButton.addActionListener(this);
        serialDataButton.setActionCommand("SerialData");
		
		//Create the send button to send a command message to the mote
		JButton sendDataButton = new JButton("Send");
		sendDataButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        //Listen to events from the send button.
        sendDataButton.addActionListener(this);
        sendDataButton.setActionCommand("SendData");
        
        c.weightx = 0.0;
        c.weighty = 0.0;
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.CENTER;
        messagePane.add(receiveSubPane, c);
        
        c.weightx = 0.0;
        c.weighty = 0.5;
        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.PAGE_START;
        messagePane.add(serialDataButton, c);
        
        c.weightx = 0.0;
        c.weighty = 0.0;
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.CENTER;
        messagePane.add(sendSubPane, c);
        
        c.weightx = 0.0;
        c.weighty = 0.5;
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.PAGE_START;
        messagePane.add(sendDataButton, c);
        
		return messagePane;
    }
    
    private JPanel createControlLEDPanel() {
    	JPanel controlLEDPane = new JPanel(new GridBagLayout());
    	GridBagConstraints c = new GridBagConstraints();
        
        // Create the buttons for changing the LED states
		JButton redOnButton = new JButton("Red On");
		JButton redOffButton = new JButton("Red Off");
		
		JButton greenOnButton = new JButton("Green On");
		JButton greenOffButton = new JButton("Green Off");
		
		JButton yellowOnButton = new JButton("Yellow On");
		JButton yellowOffButton = new JButton("Yelow Off");
        
		//Listen to events from the buttons.
        redOnButton.addActionListener(this);
        redOnButton.setActionCommand("RedOn");
        
        redOffButton.addActionListener(this);
        redOffButton.setActionCommand("RedOff");
        
        greenOnButton.addActionListener(this);
        greenOnButton.setActionCommand("GreenOn");
        
        greenOffButton.addActionListener(this);
        greenOffButton.setActionCommand("GreenOff");
        
        yellowOnButton.addActionListener(this);
        yellowOnButton.setActionCommand("YellowOn");
        
        yellowOffButton.addActionListener(this);
        yellowOffButton.setActionCommand("YellowOff");
        
        c.weightx = 0.1;
        c.weighty = 0.1;
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.LINE_END;
        c.insets = new Insets(3,3,3,3);
        controlLEDPane.add(redOnButton, c);
        
        c.weightx = 0.1;
        c.weighty = 0.1;
        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.LINE_START;
        c.insets = new Insets(3,3,3,3);
        controlLEDPane.add(redOffButton, c);
        
        c.weightx = 0.1;
        c.weighty = 0.1;
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.LINE_END;
        c.insets = new Insets(3,3,3,3);
        controlLEDPane.add(greenOnButton, c);
        
        c.weightx = 0.1;
        c.weighty = 0.1;
        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.LINE_START;
        c.insets = new Insets(3,3,3,3);
        controlLEDPane.add(greenOffButton, c);
        
        c.weightx = 0.1;
        c.weighty = 0.1;
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.LINE_END;
        c.insets = new Insets(3,3,3,3);
        controlLEDPane.add(yellowOnButton, c);
        
        c.weightx = 0.1;
        c.weighty = 0.1;
        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.LINE_START;
        c.insets = new Insets(3,3,3,3);
        controlLEDPane.add(yellowOffButton, c);
        
        // create the empty space filler
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.gridwidth = 2;
        c.gridx = 0;
        c.gridy = 3;
        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.CENTER;
        controlLEDPane.add(new JPanel(), c);
        
        return controlLEDPane;
    }
    
    private JPanel createRawMessagePanel(){
		JPanel rawMessagePane = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		msgLog = new JTextArea(25, 50);
		JScrollPane scrollPane = new JScrollPane(msgLog);
		scrollPane.setPreferredSize(new Dimension(400, 200));
		
		//Add button and label to button pane
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.REMAINDER;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(5,5,5,5);
        rawMessagePane.add(scrollPane, c);
		
		return rawMessagePane;
    }
    
    public void addComponentsToPane(Container pane) {
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Setup the message panel for the tabbed interface
        // Add widgets to the message panel
        JPanel messagePanel = createMessagePanel();
        
        // Add widgets to the control LEDs panel
		JPanel controlLEDPanel = createControlLEDPanel();
		
        // Add widgets to the raw message panel
        JPanel rawMessagePanel = createRawMessagePanel();
        
        // Add the individual panels to the tabbed layout
		tabbedPane.addTab("Data", null, messagePanel, "Data Bytes");
		tabbedPane.addTab("LED", null, controlLEDPanel, "Control LEDs");
		tabbedPane.addTab("Raw", null, rawMessagePanel, "Raw Messages");
		
		pane.add(tabbedPane);		// , BorderLayout.CENTER
    }
	
	private void sendSendDataMessage() {
		ConsoleCmdMsg packet = new ConsoleCmdMsg();
		packet.set_seqno((short)Integer.parseInt(commandSeqNumber.getText()));
		packet.set_hop_count((short)Integer.parseInt(commandHopCount.getText()));
		packet.set_source((short)Integer.parseInt(commandSourceAddr.getText()));
		packet.set_destaddr((short)Integer.parseInt(commandDestinationAddr.getText()));
		packet.set_cmdType((short)Integer.parseInt(commandMsgType.getText()));
		packet.set_length((short)Integer.parseInt(commandLength.getText()));
		
		// The follow code will set all the data elements reguardless of what
		// the commandLength value is set to, if using a data array instead of
		// text fields then this could be replaced with a for loop so that only
		// the defined number of bytes are loaded.  On the mote side the code will
		// only read out the number of bytes defined by length.
		packet.setElement_data(0, (short)Integer.parseInt(commandData1.getText(),16));
		packet.setElement_data(1, (short)Integer.parseInt(commandData2.getText(),16));
		packet.setElement_data(2, (short)Integer.parseInt(commandData3.getText(),16));
		packet.setElement_data(3, (short)Integer.parseInt(commandData4.getText(),16));
		packet.setElement_data(4, (short)Integer.parseInt(commandData5.getText(),16));
		packet.setElement_data(5, (short)Integer.parseInt(commandData6.getText(),16));
		packet.setElement_data(6, (short)Integer.parseInt(commandData7.getText(),16));
		packet.setElement_data(7, (short)Integer.parseInt(commandData8.getText(),16));
		packet.setElement_data(8, (short)Integer.parseInt(commandData9.getText(),16));
		packet.setElement_data(9, (short)Integer.parseInt(commandData10.getText(),16));
		packet.setElement_data(10, (short)Integer.parseInt(commandData11.getText(),16));
		packet.setElement_data(11, (short)Integer.parseInt(commandData12.getText(),16));
		packet.setElement_data(12, (short)Integer.parseInt(commandData13.getText(),16));
		packet.setElement_data(13, (short)Integer.parseInt(commandData14.getText(),16));
		packet.setElement_data(14, (short)Integer.parseInt(commandData15.getText(),16));
		packet.setElement_data(15, (short)Integer.parseInt(commandData16.getText(),16));
		packet.setElement_data(16, (short)Integer.parseInt(commandData17.getText(),16));
		packet.setElement_data(17, (short)Integer.parseInt(commandData18.getText(),16));
		packet.setElement_data(18, (short)Integer.parseInt(commandData19.getText(),16));
		packet.setElement_data(19, (short)Integer.parseInt(commandData20.getText(),16));
		
		try {
			//mote.send(TOS_BCAST_ADDR, packet);
			mote.send(Integer.parseInt(commandDestinationAddr.getText()), packet);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void sendSerialDataMessage() {
		ConsoleCmdMsg packet = new ConsoleCmdMsg();
		packet.set_seqno((short)Integer.parseInt(commandSeqNumber.getText()));
		packet.set_hop_count((short)Integer.parseInt(commandHopCount.getText()));
		packet.set_source((short)Integer.parseInt(commandSourceAddr.getText()));
		packet.set_destaddr((short)Integer.parseInt(commandDestinationAddr.getText()));
		packet.set_cmdType(SERIAL_DATA);
		packet.set_length((short)1);
		
		packet.setElement_data(0, (short)1);	// Send number of bytes to get
		
		try {
			//mote.send(TOS_BCAST_ADDR, packet);
			mote.send(Integer.parseInt(commandDestinationAddr.getText()), packet);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void sendLEDOnMessage(String color) {
		ConsoleCmdMsg packet = new ConsoleCmdMsg();
		packet.set_seqno((short)Integer.parseInt(commandSeqNumber.getText()));
		packet.set_hop_count((short)Integer.parseInt(commandHopCount.getText()));
		packet.set_source((short)Integer.parseInt(commandSourceAddr.getText()));
		packet.set_destaddr((short)Integer.parseInt(commandDestinationAddr.getText()));
		packet.set_cmdType(LED_ON);
		packet.set_length((short)1);
		
		if (color.equals("Red")){
			packet.setElement_data(0, (short)1);
		}
		else if (color.equals("Green")){
			packet.setElement_data(0, (short)2);
		}
		else if (color.equals("Yellow")){
			packet.setElement_data(0, (short)3);
		}
		
		try {
			//mote.send(TOS_BCAST_ADDR, packet);
			mote.send(Integer.parseInt(commandDestinationAddr.getText()), packet);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void sendLEDOffMessage(String color) {
		
		ConsoleCmdMsg packet = new ConsoleCmdMsg();
		packet.set_seqno((short)Integer.parseInt(commandSeqNumber.getText()));
		packet.set_hop_count((short)Integer.parseInt(commandHopCount.getText()));
		packet.set_source((short)Integer.parseInt(commandSourceAddr.getText()));
		packet.set_destaddr((short)Integer.parseInt(commandDestinationAddr.getText()));
		packet.set_cmdType(LED_OFF);
		packet.set_length((short)1);
		
		if (color.equals("Red")){
			packet.setElement_data(0, (short)1);
		}
		else if (color.equals("Green")){
			packet.setElement_data(0, (short)2);
		}
		else if (color.equals("Yellow")){
			packet.setElement_data(0, (short)3);
		}
		
		try {
			//mote.send(TOS_BCAST_ADDR, packet);
			mote.send(Integer.parseInt(commandDestinationAddr.getText()), packet);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
    public void actionPerformed(ActionEvent event) {
    	if ("SendData".equals(event.getActionCommand())) {
    		sendSendDataMessage();
    	}
    	else if ("SerialData".equals(event.getActionCommand())) {
    		sendSerialDataMessage();
    	}
    	else if ("RedOn".equals(event.getActionCommand())) {
    		sendLEDOnMessage("Red");
    	}
    	else if ("RedOff".equals(event.getActionCommand())) {
    		sendLEDOffMessage("Red");
    	}
    	else if ("GreenOn".equals(event.getActionCommand())) {
    		sendLEDOnMessage("Green");
    	}
    	else if ("GreenOff".equals(event.getActionCommand())) {
    		sendLEDOffMessage("Green");
    	}
    	else if ("YellowOn".equals(event.getActionCommand())) {
    		sendLEDOnMessage("Yellow");
    	}
    	else if ("YellowOff".equals(event.getActionCommand())) {
    		sendLEDOffMessage("Yellow");
    	}
    }
	
    /**
    * Convert a byte[] array to readable string format. This makes the "hex" readable!
    * @return result String buffer in String format 
    * @param in byte[] buffer to convert to string format
    */
    static String byteArrayToHexString(byte in[]) {
        byte ch = 0x00;
        int i = 0; 
        if (in == null || in.length <= 0)
            return null;
            
        String pseudo[] = {"0", "1", "2",
    "3", "4", "5", "6", "7", "8",
    "9", "A", "B", "C", "D", "E",
    "F"};
        StringBuffer out = new StringBuffer(in.length * 2);
        
        while (i < in.length) {
            ch = (byte) (in[i] & 0xF0); // Strip off high nibble
            ch = (byte) (ch >>> 4);
            // shift the bits down
            ch = (byte) (ch & 0x0F);    
            // must do this is high order bit is on!
            out.append(pseudo[ (int) ch]); // convert the nibble to a String Character
            ch = (byte) (in[i] & 0x0F); // Strip off low nibble 
            out.append(pseudo[ (int) ch]); // convert the nibble to a String Character
            i++;
        }
        String rslt = new String(out);
        return rslt;
    }
    
    public void messageReceived(int dest_addr, Message m) {
    	ConsoleMsg lm = (ConsoleMsg) m;
    	StringBuffer dataString = new StringBuffer();
	
    	msgLog.append(byteArrayToHexString(lm.dataGet())+"\n");
	
    	if (lm.get_msgType() == SERIAL_DATA) {
    		consoleSourceID.setText(Integer.toString(lm.get_sourceMoteID()));
    		consoleLength.setText(Integer.toString(lm.get_length()));
    		consoleMsgType.setText(Integer.toString(lm.get_msgType()));
    		
    		// Clear out old data from text fields
    		consoleData1.setText("00");
    		consoleData2.setText("00");
    		consoleData3.setText("00");
    		consoleData4.setText("00");
    		consoleData5.setText("00");
    		consoleData6.setText("00");
    		consoleData7.setText("00");
    		consoleData8.setText("00");
    		consoleData9.setText("00");
    		consoleData10.setText("00");
    		consoleData11.setText("00");
    		consoleData12.setText("00");
    		consoleData13.setText("00");
    		consoleData14.setText("00");
    		consoleData15.setText("00");
    		consoleData16.setText("00");
    		consoleData17.setText("00");
    		consoleData18.setText("00");
    		consoleData19.setText("00");
    		consoleData20.setText("00");
    		
    		for (int i = 1; i <= lm.get_length(); i++) {
    			dataString.delete(0, dataString.length());
    			if (lm.getElement_data(i - 1) < 16) {
    				dataString.append('0');
    			}
    			dataString.append(Integer.toHexString(lm.getElement_data(i - 1)));
    			switch (i) {
					case 1:
						consoleData1.setText(dataString.toString());
						break;
					case 2:
						consoleData2.setText(dataString.toString());
						break;
					case 3:
						consoleData3.setText(dataString.toString());
						break;
					case 4:
						consoleData4.setText(dataString.toString());
						break;
					case 5:
						consoleData5.setText(dataString.toString());
						break;
					case 6:
						consoleData6.setText(dataString.toString());
						break;
					case 7:
						consoleData7.setText(dataString.toString());
						break;
					case 8:
						consoleData8.setText(dataString.toString());
						break;
					case 9:
						consoleData9.setText(dataString.toString());
						break;
					case 10:
						consoleData10.setText(dataString.toString());
						break;
					case 11:
						consoleData11.setText(dataString.toString());
						break;
					case 12:
						consoleData12.setText(dataString.toString());
						break;
					case 13:
						consoleData13.setText(dataString.toString());
						break;
					case 14:
						consoleData14.setText(dataString.toString());
						break;
					case 15:
						consoleData15.setText(dataString.toString());
						break;
					case 16:
						consoleData16.setText(dataString.toString());
						break;
					case 17:
						consoleData17.setText(dataString.toString());
						break;
					case 18:
						consoleData18.setText(dataString.toString());
						break;
					case 19:
						consoleData19.setText(dataString.toString());
						break;
					case 20:
						consoleData20.setText(dataString.toString());
						break;
					default:
						break;
    			}
    		}
    	}
    	synchronized (this) {
    		this.notifyAll();
    	}
    }

    private static void initLookAndFeel() {
        //String lookAndFeel = null;

        if (LOOKANDFEEL != null) {
            if (LOOKANDFEEL.equals("Metal")) {
                lookAndFeel = UIManager.getCrossPlatformLookAndFeelClassName();
            } else if (LOOKANDFEEL.equals("System")) {
                lookAndFeel = UIManager.getSystemLookAndFeelClassName();
            } else if (LOOKANDFEEL.equals("Motif")) {
                lookAndFeel = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";
            } else if (LOOKANDFEEL.equals("GTK+")) { //new in 1.4.2
                lookAndFeel = "com.sun.java.swing.plaf.gtk.GTKLookAndFeel";
            } else {
                System.err.println("Unexpected value of LOOKANDFEEL specified: "
                                   + LOOKANDFEEL);
                lookAndFeel = UIManager.getCrossPlatformLookAndFeelClassName();
            }

            try {
                UIManager.setLookAndFeel(lookAndFeel);
            } catch (ClassNotFoundException e) {
                System.err.println("Couldn't find class for specified look and feel:"
                                   + lookAndFeel);
                System.err.println("Did you include the L&F library in the class path?");
                System.err.println("Using the default look and feel.");
            } catch (UnsupportedLookAndFeelException e) {
                System.err.println("Can't use the specified look and feel ("
                                   + lookAndFeel
                                   + ") on this platform.");
                System.err.println("Using the default look and feel.");
            } catch (Exception e) {
                System.err.println("Couldn't get specified look and feel ("
                                   + lookAndFeel
                                   + "), for some reason.");
                System.err.println("Using the default look and feel.");
                e.printStackTrace();
            }
        }
    }

    private void changeCOMPort () {
        //Create the message listener
        if (connection == null) {
        	connection = "serial@" + "COM1" + ":" + "telos";
        }
        System.out.println("Connecting to: " + connection);
        serialStub = BuildSource.makePhoenix(connection, PrintStreamMessenger.err);
        //try{
        //	serialStub.open(net.tinyos.util.PrintStreamMessenger.err);
        //} catch(Exception e) {
        //	System.err.println("Could not connect to local port: " + e.toString());
        //}
        
        mote = new MoteIF(serialStub);
        SerialDemo bc = new SerialDemo();
		mote.registerListener(new ConsoleMsg(), bc);
    }
    
    private void createCommDialog () {
    	String s = new String();
        if (availablePorts.length == 0) {
            s = (String)JOptionPane.showInputDialog(
                    //frame,
            		mainFrame,
                    "No devices found.\n"
                    + "Enter the COM port to open:\n",
                    "Communications Port",
                    //JOptionPane.PLAIN_MESSAGE,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    null,
                    "serial@COM1:telos");
        }
        else {
            s = (String)JOptionPane.showInputDialog(
                    //frame,
            		mainFrame,
                    "Enter the COM port to open:\n"
                    + "serial@COM?:telos",
                    "Communications Port",
                    //JOptionPane.PLAIN_MESSAGE,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    availablePorts,
                    availablePorts[0]);
        }

        //If a string was returned, say so.
        if ((s != null) && (s.length() > 0)) {
        	connection = s;
        	changeCOMPort();
        	//return;
        } else {
        	JOptionPane.showMessageDialog(mainFrame,
        			"Please enter a value.",
        			"Input Error",
        			JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public JMenuBar createMenuBar() {
    	
    	String[ ] connectionItems = new String[ ] { "New" };
    	char[ ] connectionShortcuts = { 'N' };
    	
    	JMenuBar menuBar = new JMenuBar();
    	menuBar.setOpaque(true);
    	menuBar.setBackground(mainFrame.getBackground());
    	
    	JMenu connectionMenu = new JMenu("Connection");
    	connectionMenu.setBackground(mainFrame.getBackground());

    	// Assemble the File menus with mnemonics.
    	ActionListener printListener = new ActionListener(  ) {
    		public void actionPerformed(ActionEvent event) {
    			if ("New".equals(event.getActionCommand())) {
    				createCommDialog();
    			}
    		}
    	};
    	// Assemble the Connection menu with keyboard accelerators.
    	for (int i=0; i < connectionItems.length; i++) {
    		JMenuItem item = new JMenuItem(connectionItems[i], connectionShortcuts[i]);
    		item.addActionListener(printListener);
    		connectionMenu.add(item);
    	}

    	// Finally, add all the menus to the menu bar.
    	menuBar.add(connectionMenu);
    	return menuBar;
    }
    
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */

    private static void createAndShowGUI() {	
        //Set the look and feel.
        initLookAndFeel();

		//Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);
        
        //Create and set up the window.
        mainFrame = new JFrame("Telos Serial Demo");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set up the content pane.
        demo = new SerialDemo();
        demo.addComponentsToPane(mainFrame.getContentPane());
        
        if (System.getProperty("os.name").indexOf("Windows") != -1 ) {
        	// Load the motelist DLL for searching the registry
        	System.loadLibrary("motelist");
            // Grab the available mote devices from system registry
            // pass the cpp file the argument for compressed output format
        	String input = demo.getDevices("-c");
    		// If the cpp file returns error then no motes were found
    		
    		// Seperate out the available comm port numbers and use it to create
    		// the strings used for connecting to the MoteIF message handler
    		if (input.indexOf("error") == -1) {
    			String[] seperate = input.split("\n");
    			String[] removedCom = new String[seperate.length];
    			availablePorts = new String[seperate.length];
    			for (int i=0; i < seperate.length; i++) {
    				removedCom[i] = seperate[i].substring((seperate[i].indexOf("COM"))+3, (seperate[i].indexOf(",",(seperate[i].indexOf("COM")))));
    				availablePorts[i] = "serial@COM" + removedCom[i] + ":telos";
    			}
    		}
    		else {
    			System.out.println("Motelist output: " + input);
    			availablePorts = new String[0];
    		}
        }
        else {
        	availablePorts = new String[0];
        }
        
        //Display the window.
        mainFrame.setJMenuBar(demo.createMenuBar());
        mainFrame.setSize(600,300);
        //mainFrame.pack();
        mainFrame.setVisible(true);
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}
