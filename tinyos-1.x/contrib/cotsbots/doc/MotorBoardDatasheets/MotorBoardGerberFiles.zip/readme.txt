

File listings: 

drill.nc	drill file
drill.tol	drill listing

BRD.gbr		gerber file specifying the board outline 

TOP.gbr		top metal layer
BOT.gbr		bottom metal layer
SMT.gbr		top solder mask
SMB.gbr		bottom solder mask
SST.gbr		top legend layer	
SSB.gbr		bottom legend layer

motor2b.app	aperture file for all layers	
motor2b.MAX	orcad layout file

Sarah Bergbreiter
UC Berkeley
(510)643-2235
sbergbre@eecs.berkeley.edu