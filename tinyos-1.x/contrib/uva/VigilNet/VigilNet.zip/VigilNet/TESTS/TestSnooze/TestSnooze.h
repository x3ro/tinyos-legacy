

typedef struct {
uint8_t SeqNo;
tos_time_t now;   
tos_time_t last_sleep_time;
uint32_t diff;
} TestMsg;

