/*
 * Copyright (c) 2004-2006, University of Virginia
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF VIRGINIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE VANDERBILT
 * UNIVERSITY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF VIRGINIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF VIRGINIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

// Authors:Tian He
//$Id: TripWire.h,v 1.2 2004/10/31 05:06:37 th7c Exp $
#ifndef _TRIPWIRE_H_
#define _TRIPWIRE_H_

#define MAX_NUM_TRIPWIRES 5
#define INVALID_TRIPWIRE_ID 9999
#define MAX_HOPS 100
#define MAX_NETWORK_DISTANCE 20000

typedef struct TripWireType {
   
/* ID is the node id of the mote attached to the relay*/   
uint16_t TripWireID;

/* for now we use hop_count as the selection metric */
uint8_t hops;   
uint8_t active;

/* location can be also used  */
int16_t baseX;
int16_t baseY;

}TripWireType;

typedef uint16_t TripWireScheduleType;

#endif

