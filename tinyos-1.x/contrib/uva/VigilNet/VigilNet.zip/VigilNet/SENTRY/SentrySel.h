/* "Copyright (c) 2000-2004 University of Virginia.  
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF VIRGINIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * VIRGINIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF VIRGINIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF VIRGINIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 */

// Authors: Tian He,Jonathan W Hui 
// $Id: SentrySel.h,v 1.2 2004/10/31 05:06:37 th7c Exp $

#ifndef __SENTRYSEL_H__
#define __SENTRYSEL_H__

/* some parameters used in this module*/
enum {  
  MAX_SENSING_NEIGHBORS = 20,
  SENTRYSEL_MSG = 16,
  INVALID_ADDR = 7777,
  SENDING_POWER_BASED_SELECTION = 0, //use radio range to emulate sensing range
  LOCATION_BASED_SENTRY_SELECTION = 1, //use location information to do sentry selection  
  INVALID_DISANCE = 0xffff,
};

typedef enum {
  SS_NONSENTRY,
  SS_SENTRY,
} sentry_status_t;

/* sentry selection state */
typedef enum {
 SEL_CHAOS,
 START_UP,
 DECLARE,
 SEL_STOP     
} selection_status_t;

typedef struct {
  uint16_t sourceID;        //who am I
  uint16_t sentryID;        //who is my sentry if sentryID == sourceID, then itself is sentry
  uint8_t  state;           // sentry_status_t type
  uint8_t  num_covered;     //how many non-sentry use me as sentry
  uint8_t  num_sentries;    // how many sentries I have heard from
  uint8_t  num_nonsentries; // how many non-sentries I have heard from;
  uint16_t voltage;         //my voltage
  int16_t xPosition;
  int16_t yPosition;
} SentryItem; 

typedef SentryItem* SentryItemPtr;

#ifdef PLATFORM_PC
enum {
  TOSH_ACTUAL_VOLTAGE_PORT = 7,
  TOS_ADC_VOLTAGE_PORT = 7
};
#endif // PC

#endif // __SENTRYSEL_H__
