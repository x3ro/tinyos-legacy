/* "Copyright (c) 2000-2004 University of Virginia.  
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF VIRGINIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * VIRGINIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF VIRGINIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF VIRGINIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 */

// Authors: Tian He
// $Id: Report.h,v 1.2 2004/07/23 00:48:02 th7c Exp $

#ifndef __REPORT_H__
#define __REPORT_H__


typedef struct {
  uint16_t nodeId;
  uint16_t x;
  uint16_t y;  	
  uint16_t sentry;
  uint16_t route_to_base;
  uint16_t voltage;	
  uint8_t  num_sentries;
  uint8_t  num_neighbors;
  uint8_t  state;
  uint8_t  SensorStatus;
  uint32_t reportStartTime;
} NodeStatusRecord;

typedef struct {
 uint8_t NetworkStatus;	
 tos_time_t  global_time;
 uint8_t roundCount;
 uint8_t isActive;
}NetworkStatusRecord;

enum {
 SENTRY_AWAKE,
 SENTRY_SLEEP,
 NON_SENTRY_AWAKE,
 NON_SENTRY_SLEEP,
 BASE_AWAKE,
} NodeStatusRecord_State;

enum {
/* do not use  0x77. it is used by routing internally */
TRANSPORT_NODE_REPORT = 0,    
MIN_REPORT_PERIOD = 4000ul,  /* in millisecond */
};

#endif // __REPORT_H__
