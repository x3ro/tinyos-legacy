/* "Copyright (c) 2000-2004 University of Virginia.  
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF VIRGINIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * VIRGINIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF VIRGINIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF VIRGINIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 */

/* Authors: Tian He, Sudha, etc */
//$Id: configuration.h,v 1.11 2004/08/05 04:16:06 th7c Exp $

#ifndef __CONFIGURATION_H__
#define __CONFIGURATION_H__

#include "AM.h"

/******************************************************************************
*  FOllowing marco defines whether start system from GUI or it automatically  *
*  starts when a basemote is turned on.                                        *      
* *****************************************************************************/

#define GUI_CONTROL_START

/******************************************************************************
*   Following macros are used to speed up test.                               *      
* *****************************************************************************/

#define FAST_SYNC //speed up sync. always use it when we test small network.

enum{
LEDS_ENABLE = 1 << 0,  //enable LEDS. turn them off in real deployment to save power.
SKIP_DETECTION = 1 << 1, //skip symmetric detection phase, assuming links are symmetric.
SKIP_REPORT  = 1 << 2, //no node report
SKIP_SENTRY_SELECTION = 1 << 3, //only node inside the diffusion tree is sentry
SKIP_PM  = 1 <<  4, //no power management.
SKIP_TRACKING = 1 << 5, //no tracking 
REAL_LOCALIZATION =  1 << 6, //use real or faked localization
SOFT_RANGE = 1 << 7, //used to enforce multihop 
POWER_BASED_SENTRY_MODE = 1 << 8, //whether use location based sentry selection mode
TRIPWIRE_MODE = 1 << 9, //whether use location base tripwire partition
BASE_FILTER_DISABLE = 1 << 10, //whether use flase alarm processing in the base
MAG_ENABLED = 1 << 11, //whether the mag sensor is enabled
PIR_ENABLED = 1 << 12, //whether the PIR sensor is enabled
ACOUSTIC_ENABLED = 1 << 13, //whether the acoustic sensor is enabled
SENTRY_REPORT_ONLY = 1 <<14, //whether only sentry report its status
MULTI_SYNC_ROOT = 1 << 15, // whether use backbone node as static leader, otherwise use sentry
};

/******************************************************************************
*   Following are fixed parameters for the SOWN system.                         *      
* *****************************************************************************/

enum {
VERSION = 7u,	
MAX_NETWORK_DIAMETER  = 100u,
MIN_BCAST_PERIOD = 2000u,
MIN_REPORT_DELAY = 2000u, //unit of millisecond
SHORT_PHASE_DELAY = 5000u, //unit of millisecond
START_DELAY = 5000u,
CHAO_DELAY = 5000u,
NUM_TRIPWIRE = 10,
DEFAULT_GridY = 10,
JIFFIES_PER_SECOND = 32768u,
MILLS_PER_SECOND = 1000u,
MAX_SENDING_POWER = 0xff,
CALIBRATION_DELAY = 35000u,
};

/******************************************************************************
*   Following parameters are used to divide network into tripwire sections.   *      
* *****************************************************************************/


/* The schedule bitmap of this tripwire section;
 * 1 denotes that this section should be active
 * 0 denotes that this secton should be dormant
 **************************************************************/ 
#define DEFAULT_TRIPWIRE_SCHEDULE  0xffff

uint16_t TripWireSchedule = DEFAULT_TRIPWIRE_SCHEDULE; 

/* the only node who initiates time sync & configuration messages */
uint16_t SYN_BASE_ID = 0;

/******************************************************************************
*         Follwing provides three types of dyanmic configurations             *      
*                                                                             *
* *****************************************************************************/
 
#define SMALL_NETWORK_TEST   //less than 4 motes and one hop
//#define MEDIUM_NETWORK_TEST  // less than 25 motes and two~three hops
//#define LARGE_NETWORK_TEST   // more than 25 motes and real deployment

/******************************************************************************
*                      CONFIGURATION FOR SMALL SIZE NETWORKS                  *      
*                                                                             *
* *****************************************************************************/

#ifdef SMALL_NETWORK_TEST 
/* now 110 second per rotation, accuracy within 7 millisecond */

/******************* BaseStation Tunable Parameters *************/
enum {
    
   DEFAULT_START_TIME = 0, 
   
   /* only need to reinstall mote zero to reset the parameters in all the motes */	  
   DEFAULT_GridX = 10, /* rule: 0 < DEFAULT_GridX  */
   
   DEFAULT_SYN_DELAY = 30, /* rule: 20 <= DEFAULT_SYN_DELAY  */
   
   DEFAULT_SD_THRESHOLD = 70, /* rule:   0 <= DEFAULT_SD_THRESHOLD <= 100 */
   DEFAULT_SD_POWER = 255, /* rule:   0 <= DEFAULT_SD_POWER <= 255 */
   DEFUALT_SD_COUNT = 5, /* rule:   4 <= DEFUALT_SD_COUNT <= 20 */
   
   /* Power Management */      
   DEFAULT_SENTRY_RANGE = 10, /* rule:   0 <= DEFAULT_SENTRY_RANGE <= 255 */
    
	/* DEFAULT_POWER_MODE should be smaller than 6
	DEFAULT_POWER_MODE = 0 --> 100%  radio duty cycle
	DEFAULT_POWER_MODE = 1 --> 35.5% radio duty cycle
	DEFAULT_POWER_MODE = 2 --> 11.5% radio duty cycle
	DEFAULT_POWER_MODE = 3 --> 7.53% radio duty cycle
	DEFAULT_POWER_MODE = 4 --> 5.61%  radio duty cycle
	DEFAULT_POWER_MODE = 5 --> 2.22%  radio duty cycle
	DEFAULT_POWER_MODE = 6 --> 1.00%  radio duty cycle	
   */ 
   
    DEFAULT_POWER_MODE = 4, /* rule:   0 <= DEFAULT_POWER_MODE <= 6 */
    DEFAULT_PM_TIME_OUT = 60, /* rule:   0 < DEFAULT_POWER_MODE <=255 */

   /* network state transition */              
    DEFAULT_PHASE_DELAY = 20, // in seconds /* rule:   10 < DEFAULT_POWER_MODE <=255 */
    DEFAULT_REPORT_PERIOD = 8, // in seconds /* rule:   4 < DEFAULT_REPORT_PERIOD <= 10 */
    //the duration of Tracking phase is DEFAULT_TPHASE_DELAY *  DEFAULT_PM_DURATION_COUNT
    DEFAULT_TRACKIN_PHASE_COUNT  = 1000, /* rule:   1 <= DEFAULT_TRACKIN_PHASE_COUNT <= 65535 */

    /* envioTrack */
    DEFAULT_SAMPLING_INTERVAL = 20, //in units of millisecond  /* rule:   1 <= DEFAULT_SAMPLING_INTERVAL/10 <= 4 */
    DEFAULT_REFRESH_INTERVAL = 500, //in units of millisecond  /* rule:   30 <= DEFAULT_REFRESH_INTERVAL/10 <= 100 */

    #ifdef PLATFORM_XSM
    DEFAULT_PIR_THRESHOLD = 150,   
    DEFAULT_MAG_THRESHOLD = 25,  /* rule:   0 <= DEFAULT_MAG_THRESHOLD <= 255 */ 
    DEFAULT_ACOUSTIC_THRESHOLD = 60,         
    #else    
    DEFAULT_PIR_THRESHOLD = 150,    
    DEFAULT_MAG_THRESHOLD = 25,  /* rule:   0 <= DEFAULT_MAG_THRESHOLD <= 255 */
    DEFAULT_ACOUSTIC_THRESHOLD = 60,      
    #endif


    DEFAULT_DEGREE_OF_AGGREGATION=1,   // degree of aggregation  /* rule:   0 <= DEFAULT_DEGREE_OF_AGGREGATION <= 5 */
    
    //parameters to be tuned
    DEFAULT_SENSE_CNT_THRESHOLD  = DEFAULT_SAMPLING_INTERVAL,
    DEFAULT_WAIT_THRESHOLD = 5 * DEFAULT_REFRESH_INTERVAL, 
    DEFAULT_RANGE = 20,
    DEFUALT_TIME_DIFF = 0,
    DEFUALT_LAT_REF = 0,    
    DEFUALT_LONG_REF = 0,
    DEFAULT_WINDOW_SIZE = 60,
    DEFAULT_SENSING_PERCENTAGE = 70,
    DEFAULT_DETECTION_THRESHOLD = 3,
    DEFAULT_FLOW_RATE = 5,       
    DEFAULT_SETTING_BITS = MAG_ENABLED | PIR_ENABLED | LEDS_ENABLE
};

/******************************************************************************
*                      CONFIGURATION FOR MEDIUM SIZE NETWORK                  *      
*                                                                             *
* *****************************************************************************/
#elif defined(MEDIUM_NETWORK_TEST)

/******************* BaseStation Tunable Parameters ************/

/******************************************************************************
*                      CONFIGURATION FOR LARGE SIZE NETWORK                   *      
*                                                                             *
* *****************************************************************************/

#elif defined(LARGE_NETWORK_TEST)

#endif


/******************************************************************************
*                      CONFIGURATION STOPS HERE                               *      
*                                                                             *
* *****************************************************************************/

uint16_t FormatType = 12345;

/* Piggyback system parameters inside Timesync */
typedef struct {
   
   /*round begin time */
   uint32_t time; 
  
   /* topology control */
   uint8_t GridX;
   
   /* time sync control*/
   uint8_t syncDelay;
   
   /* SD Control */
   uint8_t SDThreshold; 
   uint8_t SDPower;
   uint8_t SDBeaconCount;
                                                                          
   /* Power Management */    
   uint8_t sentryRange;
   uint8_t powerMode;
   uint8_t pmTimeOut;  
                
   /* envioTrack */
   uint8_t samplingInterval; //default 20
   uint8_t refreshInterval; //deault 500
   uint8_t magThreshold; //default 50
   uint8_t PIRThreshold; //default 50
   uint8_t AccousticThreshold; //default 50      
   uint8_t DOA;           
          
   /* network state transition */   
   uint8_t phaseDelay;
   uint8_t reportPeriod;  //20 bytes first configuration message
   
   uint32_t MasterClock2NetworkTimeDiff;  
   int32_t 	reflatitude;
   int32_t  reflongitude;
   uint16_t trackingPhaseCount;    
   uint16_t settingBits;  /* phase enable bits */ 
   uint8_t range ;/* soft enforcement of range debug*/
   uint8_t shutdownThreshold;   
   uint8_t DetetionThreshold;
   uint8_t FlowRate;
            
} SystemParameters;

/* This buffer is used by multiple modules in order to save memory */
#ifdef SHARED_MEMORY
TOS_Msg GlobalSendingBuffer;
#endif

SystemParameters DefaultParameters = 
{  
   DEFAULT_START_TIME, 
    /* topology control */
   DEFAULT_GridX,

   /* time sync control*/   
   DEFAULT_SYN_DELAY,
   
   DEFAULT_SD_THRESHOLD,   
   DEFAULT_SD_POWER, 
   DEFUALT_SD_COUNT,
        
   /* Power Management */ 
   DEFAULT_SENTRY_RANGE,
   DEFAULT_POWER_MODE,
   DEFAULT_PM_TIME_OUT,
      
    /* envioTrack */
   DEFAULT_SAMPLING_INTERVAL/10, //in unit of 1/100 second
   DEFAULT_REFRESH_INTERVAL/10, //in unit of 1/100 second
   DEFAULT_MAG_THRESHOLD, 
   DEFAULT_PIR_THRESHOLD,
   DEFAULT_ACOUSTIC_THRESHOLD,
   DEFAULT_DEGREE_OF_AGGREGATION,  
   
   /* network state transition */   
   DEFAULT_PHASE_DELAY,
   DEFAULT_REPORT_PERIOD,

   DEFUALT_TIME_DIFF,
   DEFUALT_LAT_REF,    
   DEFUALT_LONG_REF,
          
   DEFAULT_TRACKIN_PHASE_COUNT,         
   DEFAULT_SETTING_BITS,
   DEFAULT_RANGE,  
   DEFAULT_SENSING_PERCENTAGE, 
   DEFAULT_DETECTION_THRESHOLD,
   DEFAULT_FLOW_RATE,                   
};

#endif


      
      
