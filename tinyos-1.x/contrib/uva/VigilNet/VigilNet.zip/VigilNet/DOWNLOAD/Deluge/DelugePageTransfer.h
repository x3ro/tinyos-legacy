// $Id: DelugePageTransfer.h,v 1.1 2004/10/28 04:24:12 th7c Exp $

/*									tab:4
 *
 *
 * "Copyright (c) 2000-2004 The Regents of the University  of California.  
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 */

/**
 * Parameters used by PageTransfer component.
 *
 * @author Jonathan Hui <jwhui@cs.berkeley.edu>
 */

#ifndef __DELUGE_PAGE_TRANSFER_H__
#define __DELUGE_PAGE_TRANSFER_H__

enum {
  DELUGE_PKTS_PER_PAGE    = 48,
  DELUGE_PKT_PAYLOAD_SIZE = 23,
  DELUGE_BYTES_PER_PAGE   = ((DELUGE_PKTS_PER_PAGE*DELUGE_PKT_PAYLOAD_SIZE)-2),
  DELUGE_PKT_BITVEC_SIZE  = (((DELUGE_PKTS_PER_PAGE-1) / 8) + 1),
  DELUGE_DATA_Q_SIZE      = 2,
  DELUGE_NO_PAGE          = 0xff,
};

#endif
