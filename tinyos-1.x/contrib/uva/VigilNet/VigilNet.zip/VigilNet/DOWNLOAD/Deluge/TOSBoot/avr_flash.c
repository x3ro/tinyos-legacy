// $Id: avr_flash.c,v 1.1 2004/10/28 04:24:17 th7c Exp $

/*									tab:4
 *
 *
 * "Copyright (c) 2000-2004 The Regents of the University  of California.  
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 */

/**
 * avr_flash.c
 *
 * @author Jonathan Hui <jwhui@cs.berkeley.edu>
 * @since  0.1
 */

#include <inttypes.h>
#include <avr/boot.h>
#include <bl_flash.h>

void eeprom_write_page(void *buf, uint32_t pageBaseByteAddr, uint16_t length) {
  uint16_t *wordBuf = (uint16_t*)buf;
  uint32_t i = 0;
  
  boot_page_erase(pageBaseByteAddr);
  
  while(boot_rww_busy()) { boot_rww_enable(); }
  
  for (i = 0; i < length / sizeof(uint16_t); i++)
    boot_page_fill(pageBaseByteAddr + i * (uint32_t)2, wordBuf[i]);
  
  boot_page_write(pageBaseByteAddr);
  
  while(boot_rww_busy()) { boot_rww_enable(); }
}
