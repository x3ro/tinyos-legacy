// $Id: DelugeMsgs.h,v 1.1 2004/10/28 04:24:12 th7c Exp $

/*									tab:4
 *
 *
 * "Copyright (c) 2000-2004 The Regents of the University  of California.  
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 */

/**
 * Message structures used by Deluge components.
 *
 * @author Jonathan Hui <jwhui@cs.berkeley.edu>
 */

#ifndef __DELUGE_MSGS_H__
#define __DELUGE_MSGS_H__

#include "Deluge.h"
#include "DelugeMetadata.h"
#include "DelugePageTransfer.h"

enum {
  AM_DELUGEADVMSG            = 161,
  AM_DELUGEREQMSG            = 162,
  AM_DELUGEDATAMSG           = 163,
};

enum {
  DELUGE_SHARED_MSG_BUF = unique("SharedMsgBuf"),
};

enum {
  DELUGE_ADV_NORMAL,
  DELUGE_ADV_PC,
  DELUGE_ADV_NOT_READY,
};

typedef struct DelugeAdvMsg {
  uint16_t         sourceAddr;
  int16_t          globalVNum;
  uint8_t          runningImgNum;
  bool             type;
  DelugeImgSummary imgSummaries[DELUGE_NUM_IMGS];
  uint16_t         crc;
} DelugeAdvMsg;

typedef struct DelugeReqMsg {
  uint16_t  dest;
  imgvnum_t vNum;
  uint8_t   imgNum;
  pgnum_t   pgNum;
  uint8_t   requestedPkts[DELUGE_PKT_BITVEC_SIZE];
} DelugeReqMsg;

typedef struct DelugeDataMsg {
  imgvnum_t vNum;
  uint8_t   imgNum;
  pgnum_t   pgNum;
  uint8_t   pktNum;
  uint8_t   data[DELUGE_PKT_PAYLOAD_SIZE];
} DelugeDataMsg;

#endif
