#ifndef _H_Routing_h
#define _H_Routing_h

#include "common_structs.h"

//msg type shown in TOS_Msg Header
enum {
  BACKBONE_FWD_MSG = 17,
  BACKBONE_INFO_MSG = 18,
  AM_BC_DATA_MSG   = 5,
  RETRY_LIMIT = 3
};


typedef uint8_t RoutingProtocol_t;
typedef uint8_t RoutingHopCount_t;
typedef uint16_t RoutingAddress_t;

typedef struct {
  bool broadcast;
  Triple_int16_t pos;
  Triple_int16_t radius;
} RoutingGeo_t;

typedef RoutingGeo_t RoutingLocation_t;

typedef union {
  RoutingAddress_t address;
  RoutingHopCount_t hops;
  RoutingLocation_t* location;
} RoutingDestination_t;

# include "AM.h"

int8_t* initRoutingMsg( TOS_MsgPtr msg, uint8_t length )
{
  if( length <= TOSH_DATA_LENGTH )
  { 
  	
    msg->length = length;
    return msg->data;
  }else {
  	
   dbg(DBG_USR1,"Fail,Please reduce packet length!!!! Max %d,now length %d\n",TOSH_DATA_LENGTH,length);	
   return 0;
  }
  
}

int8_t* pushToRoutingMsg( TOS_MsgPtr msg, uint8_t length )
{
  if( length <= TOSH_DATA_LENGTH )
  {
    int8_t* head = msg->data + msg->length;
    msg->length += length;
    return head;
  }
  return 0;
}

int8_t* popFromRoutingMsg( TOS_MsgPtr msg, uint8_t length )
{
  if( length <= TOSH_DATA_LENGTH )
  {
    msg->length -= length;
    return msg->data + msg->length;
  }
  return 0;
}

int8_t* peekFromRoutingMsg( TOS_MsgPtr msg, uint8_t length )
{
  if( length <= TOSH_DATA_LENGTH )
  {
    return msg->data + msg->length - length;
  }
  return 0;
}

#endif // _H_Routing_h

