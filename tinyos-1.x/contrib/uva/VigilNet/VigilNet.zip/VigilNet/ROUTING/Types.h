
#ifndef __TYPES_H__
#define __TYPES_H__

typedef struct {
  //routing_t type; ??? // one or all
  int16_t xCenter;
  int16_t yCenter;
  int16_t zCenter;
  uint16_t range;
} location_t;

typedef struct {
  uint8_t id; // attribute id
  int16_t lower;
  int16_t upper;
} constraint_t;

typedef struct {
  uint8_t id; // attribute id
  uint8_t type; // maximize or minimize
} objective_t;

typedef struct {
  constraint_t *cons;
  uint8_t num;
} constraints_t;

typedef struct {
  objective_t *obj;
  uint8_t num;
} objectives_t;

typedef struct {
  //routing_t type; ???
  constraints_t *dest;
  constraints_t *rout;
  objectives_t *objs;
} CBR_t;

typedef struct {
  uint8_t hops;
  uint16_t address;
  location_t *location;
  CBR_t *dest;
} destination_t;

#endif
