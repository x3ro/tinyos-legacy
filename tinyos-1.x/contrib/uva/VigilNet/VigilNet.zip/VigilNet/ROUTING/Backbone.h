/* "Copyright (c) 2000-2004 University of Virginia.  
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF VIRGINIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * VIRGINIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF VIRGINIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF VIRGINIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 */

/* Authors: Tian He, Jonathan W Hui */

/* this module build a single diffusion tree inside a tripwire section 
 * multi-diffusion tree structure is maintained in tripwire management code 
 */
//$Id: Backbone.h,v 1.4 2004/11/10 18:57:47 th7c Exp $

#ifndef __BACKBONE_H__
#define __BACKBONE_H__

# include "AM.h"

#define INFO_MSG_QUEUE_SIZE  3
#define MAX_SENTRY_NEIGHBORS 16

#define BACK_BONE_PAYLOAD_SIZE 25
#define MAX_BASE_HEARD 2
#define MAX_PARENTS 3 * MAX_BASE_HEARD
#define MAX_HOP_COUNT 100
#define INVALID_DISTANCE  0xffff
#define INVALID_ADDRESS 0x7fff
#define FAIL_SAFE_COUNT 2

enum{
STATE_NONE,
STATE_BUILDING,
STATE_COMMITING,
STATE_READY,
} BackboneState;

typedef struct {
  uint16_t base_id;     //where to sent
  uint16_t parentAddr;          // addr provided by nbr
  uint8_t FailSafeCount;   //How many deliver failure before this parentItem should be deleted
  uint8_t hopcount;  
} ParentItem;

  
typedef struct {  
  uint16_t base_id; //TripWire ID 
  int16_t baseX;   //X location of the base
  int16_t baseY;   //Y location of the base
  int16_t senderX;
  int16_t senderY;
  uint16_t source; //Last Hop ID
  uint8_t  num_hops; //running hop count
  uint8_t  max_num_hops; //assign by the base to control the flooding area. (Optional)
  uint8_t  active; //Whether this tripwire section is active or not
} BackboneFloodMsg_t;

typedef BackboneFloodMsg_t* BackboneFloodMsgPtr;

typedef struct {
  uint8_t  Transport_ID;
  uint8_t  size;			  
  uint16_t dest;
    
}BackbonePacketHeader;

typedef struct {
	uint16_t sender;
	uint16_t parent;	
}BackboneCommitMsg;


typedef struct {	
  BackbonePacketHeader header;	  
  uint8_t payload[BACK_BONE_PAYLOAD_SIZE]; //tian  
} BackboneInfoMsg_t;

typedef BackboneInfoMsg_t* BackboneInfoMsgPtr;

enum {   
  BECOME_NON_LEAF = 0x77,
};

#endif
