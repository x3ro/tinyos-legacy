/* "Copyright (c) 2000-2004 University of Virginia.  
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF VIRGINIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * VIRGINIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF VIRGINIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF VIRGINIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 */

/* Authors: Gary Zhou, Tian He */
//$Id: BC.h,v 1.1.1.1 2004/07/13 21:42:39 th7c Exp $

#ifndef __BC_H__
#define __BC_H__

# include "AM.h"

#define MAX_BC_BUFFER 5

#define PAYLOAD_SIZE 23
typedef char PAYLOAD[PAYLOAD_SIZE];

typedef struct{
  uint16_t globalSenderID;
  uint8_t seqNO;
  int8_t hopCountLeft;  
  uint8_t appID;
} BC_HEADER;



/* buffer to filter out duplicate packets */
typedef struct{
    uint16_t globalSenderID[MAX_BC_BUFFER];
    uint16_t seqNO[MAX_BC_BUFFER];
    uint16_t head;
} BC_BUFFER;

typedef struct{
	BC_HEADER header;
	PAYLOAD data;
} BC_PACKET;

#endif
