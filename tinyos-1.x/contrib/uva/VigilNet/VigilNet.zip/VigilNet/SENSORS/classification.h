typedef enum {
  Any = 2,
  All = 3,
  BigVehicle = 4,
  SmallVehicle = 6,
  PersonNoWeapon = 0x10,
  PersonArmed = 0x18,
} TargetType;

typedef struct {
  int nSampleRate;
  int nThreshold; 
  int nHitCnt; /* # of hits (sensor readings exceeding the threshold) before 
		  firing a positive report. */
  int nRepDamping; /* # of milliseconds a sensor must wait before firing a
		       new report after a previous report. This is when there
is no dramatic change or urgent report. When there is
dramatic change or urgent report, the sensor reports
immediately. */
} ParamSetting;

typedef char TargetConfidence[8];
