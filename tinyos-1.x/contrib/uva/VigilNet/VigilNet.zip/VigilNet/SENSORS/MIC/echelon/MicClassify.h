// Indexes for confidence vector.

#define BIG_VEHICLE 0
#define SMALL_VEHICLE 1
#define PERSON_W_WEAPON 2
#define PERSON_WO_WEAPON 3

//#define MIC_DEBUG
