/*
 * Copyright (c) 2004-2006, University of Virginia
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF VIRGINIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE VANDERBILT
 * UNIVERSITY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF VIRGINIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF VIRGINIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

// Authors: Ting Yan, Tian He, etc


#ifndef RELAY_H
#define RELAY_H

// #define DEBUG_BASE_MODE

enum {
	UART_QUEUE_SIZE = 5, // uart buffer size
	FLASH_QUEUE_SIZE = 3, // flash buffer size
	FLASH_RETRY_LIMIT = 4, 
	UART_RETRY_LIMIT = 4,
	REPORT_FLASH_BLOCK = 16, // block size in bytes
	RAM_REPORT_BLOCK = 20,
	// now, x:2, y:2, timestamp:4, last:2, group:1
	FLASH_POOL_IN_BLOCKS = 1024, // pool size in blocks
	FLASH_POOL = unique("ByteEEPROM"),
	PARAM_FLASH_POOL = unique("ByteEEPROM"),
	PARAM_SIZE = 44,
	GROUP_NUMBER = 10, // maximum number of groups
	GROUP_THRESHOLD = 1000, // if distance greater than it, try another group
	EXPIRE_TIME = 180, // in 0.1 seconds
	VEHICLE_EXPIRE_TIME = 60, // in 0.1 seconds
	VELOCITY_HISTORY = 8, // history to calculate velocity
	MIN_VELOCITY_HISTORY = 4, // threshold to calculate velocity
	POTENTIAL_THRESHOLD = 3,
	CLASSIFY_THRESHOLD = 4, 
	CONFIRMED_THRESHOLD = 9,
	VELOCITY_THRESHOLD = 20, // in 0.1m/s
	MAXIMUM_VELOCITY = 500, // in 0.1m/s
	DUPLICATE_HISTORY = 5, // check the history for duplicates
	// FLASH_POOL1 = unique("ByteEEPROM")
	COMMAND_FLAG = 3,
	MOTE_TYPE = 0,
	
	VEH_CONF_THRESH = 2,
	VEH_UNCONF_THRESH = 2,
	
	/* see ICD document table 2 for detailed information */
	TRACKING_RECORD = 1,
	NODE_STATUS = 2,
	NETWORK_STATUS = 3,
	SENSOR_WAKEUP = 4,
	SYSTEM_CONFIGURATION = 5,
	ECHO = 6,
	
	
	/* see ICD document table 6 for detailed information */
	REQUEST_PARAMETERS = 1,
	RESET_TYPE = 2,
	PROBING_TYPE = 4,	
	NOTIFICATION_TYPE = 4,
	

	
	/* see ICD document table 8 for detailed information */
	SET_PARAMETERS = 1,		
	ORGIN_OF_REFERENCE = 3,	
	MAIN_CLOCK = 4,		
	SYSTEMCONFIG_TYPE = 5,
	
	/* for writing/reading parameters in FLASH */
	// FLASH_PARAM_LOCATION = 5121, 
	FLASH_VERSION = 12348,
	// FIRST_LINE_RD = 0, 
	// SECOND_LINE_RD = 1,
	// THIRD_LINE_RD = 2,
	// FOURTH_LINE_RD = 3,
	// FIRST_LINE_WR = 4,
	// SECOND_LINE_WR = 5,
	// THIRD_LINE_WR = 6,
	// FOURTH_LINE_WR = 7,
	FLASH_READ = 0, 
	FLASH_WRITE = 1,
	
	// MAGIC1 = 0xfb1c,
	// MAGIC2 = 0xb477,
	// MAGIC3 = 0x31e3,
	// MAGIC4 = 0xedf5,

	MAX_REPORTING_NODES = 200,
	
	MAG_DIFF_THRESHOLD = 3,
	ACOUSTIC_DIFF_THRESHOLD = 3,
};

enum {
	GROUP_NULL,
	GROUP_NEW,
	GROUP_POTENTIAL,
	GROUP_CONFIRMED
};

typedef struct {
	uint8_t flags;
	uint8_t recordType;
	uint8_t messageID;	
}META_HEADER;	


typedef struct {
	int16_t x; 
	int16_t y;
	uint32_t timeStamp;
	uint16_t last; // pointer to the last record in the same group
	uint8_t group;
	uint8_t status;
	uint16_t size;
	uint16_t recent; 
	
} FlashRecord;

typedef struct {
	uint16_t size; // number of records in the group
	uint16_t recent; // pointer to the recent record in flash
	int16_t x; // the x location of the group
	int16_t y; // the y location of the group
	int16_t xVel; // the x velocity of the group
	int16_t yVel; // the y velocity of the group
	uint32_t timeStamp; // the latest timeStamp of the group
	uint32_t sendingTimeStamp; // the latest timeStamp of the group
	uint8_t status; // the status of the group
	uint8_t type;
	int16_t groupX;
	int16_t groupY;
	uint8_t sendingStatus; //: 0 never sent for this group
							//: 1 sent but no classification or velocity
							//: 2 sent with classification, but no velocity
							//: 3 sent with classification and velocity
	uint8_t lastMagDiff;
	uint8_t lastAcousticDiff;
	uint16_t totalMagDiff;
	uint16_t totalAcousticDiff;
	uint32_t startTimeStamp;
	uint16_t numHits;
} Group; // 37 bytes
	
typedef struct {
   META_HEADER header;
	uint8_t eventID;
	uint8_t eventType;
	uint8_t reportType;
#ifdef DEBUG_BASE_MODE	
	uint16_t leaderID;
#endif	
	int16_t xCoord;
	int16_t yCoord;
	int16_t xVelocity;
	int16_t yVelocity;
	uint32_t timeStamp;
	uint8_t confLevel;
	uint16_t delays;
	uint8_t tDiff;
	
#ifdef DEBUG_BASE_MODE		
	int16_t timeDiff;
	uint8_t groupSize;
#endif
	
} TrackingNotification;

typedef struct {
   META_HEADER header;
	uint16_t nodeID;
	int16_t xCoord;
	int16_t yCoord;
	uint16_t sentryID;
	uint16_t parentID;
	uint8_t numSentries;
	uint8_t numNbrs;
	uint16_t voltage;
	uint8_t state;
	uint8_t sensorStatus;
#ifdef DEBUG_BASE_MODE		
	uint32_t reportStartTime;	
#endif
	
} NodeStatusNotification;

typedef struct {
   META_HEADER header;
	uint16_t baseID;   
	uint8_t networkPhase;
	uint8_t networkRound;   
	uint32_t latitude;
	uint32_t longitude;
	uint32_t networkTime;
} NetworkStatusNotification;


typedef struct {
   META_HEADER header;
	uint8_t paramCode;
	uint8_t gridX;
	uint8_t sentryRange;
	uint8_t powerMode;
	uint8_t SDThreshold;
	uint8_t pmTimeOut;
	uint8_t FlowRate;
	uint8_t PIRThreshold;
	uint8_t DetetionThreshold;
	uint8_t MagThreshold;
	uint8_t AcousticThreshold;
	uint8_t shutDownThreshold;	
	uint8_t phaseDelay;
	uint16_t trackingPhaseCount;
	uint16_t settingBits;
	uint16_t schedule;
	
   #ifdef DEBUG_BASE_MODE	
   uint8_t syncDelay;
	uint8_t reportPeriod;
   uint8_t SDBeaconCount;	
	#endif   
	
} ParameterizedResetCommand;

typedef struct {
   META_HEADER header;
	uint8_t paramCode;
   uint32_t currentTime;
   uint16_t  offset;
	uint32_t reflatitude;
	uint32_t reflongitude;   
} MasterClockCommand;

typedef struct {
   META_HEADER header;
	uint16_t srcID;
	uint8_t eventType;
	uint16_t attributeType;
	uint16_t confidence;
	uint16_t accuracy;
	uint32_t periodicity;
} QueryCommand;

typedef struct {
   META_HEADER header;
   uint8_t paramCode;
   GpsCoord reference; /* global reference point */
   GpsCoord selfLocation; /* value set by relay */
} ReferenceGPSCommand;

typedef struct {
	uint16_t statusNodeID;
} ReportItem; 

typedef struct {
   META_HEADER header;  //flag 
} PingCommand;

#endif

