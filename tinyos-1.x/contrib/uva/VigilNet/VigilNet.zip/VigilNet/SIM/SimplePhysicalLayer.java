import java.util.*;

class SimplePhysicalLayer implements PhysicalLayer
{
   final static float PACKET_SPEED = 1000.0f;
    OverlayNetwork net;

    SimplePhysicalLayer(OverlayNetwork olNet)
    {
        net = olNet;
    }

    public boolean sendMsg(SimEventMsg msg)
    {
        float time_start = net.simTime();
        float time_end = time_start + msg.getSize()/PACKET_SPEED;
        boolean collision=false;
        OverlayNode srcNode = msg.getSender();

        /* Detect collisions with previous transmissions from self */
        if(srcNode.timeLastMsg > time_start)
            collision = true;
        /* Detect collisions with previous transmissions from neighbors */
        if(!collision)
        {
            Enumeration enum = srcNode.getPhyNeighbor();
          while( enum.hasMoreElements() ) {
              OverlayNode onode = (OverlayNode) enum.nextElement();
                 if(onode.timeLastMsg > time_start)
                 {
                     collision = true;
                     break;
                 }
          }
        }

        if(!collision)
        {
         msg.setTime( time_end );
         net.insertEvent(msg);
            srcNode.timeLastMsg = time_end;
            return true;
        }
        return false;
    }
}
