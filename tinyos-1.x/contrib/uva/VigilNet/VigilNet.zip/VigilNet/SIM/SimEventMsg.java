/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

/**
 * This class implements message event by extending SimEvent
 */

abstract class SimEventMsg extends SimEvent
{
    //this is the physical layer routing
    /** source of the message, note that src can be different from sender in the
     *  SimEvent because a message can be forwarded for multiple hops before
     *  reaching the destination. While src and dst of the message are the same
     *  during the whole process, sender and recipient are changed at each forwarding
     *  node
     */
    OverlayNode src;
    /** destination of the message */
    OverlayNode dst;
    /** type of the message */
    int msgType;

    public SimEventMsg(
                       OverlayNode osrc,
                       OverlayNode odst,
                       int mtype )
    {
        super( 0, osrc, odst, SimEvent.MESSAGE_EVENT );
        src = osrc;
        dst = odst;
        msgType = mtype;
     }


    public OverlayNode getSrc()
    {
        return src;
    }

    public void setSrc( OverlayNode o)
    {
        src = o;
    }
    //public void setSrc( OverlayNode osrc ) { src = osrc; }

    public OverlayNode getDst()
    {
        return dst;
    }

    public void setDst( OverlayNode o)
    {
        dst = o;
    }

    //public void setDst( OverlayNode odst ) { dst = odst; }
    public int getMsgType(){ return msgType; }

     public int getSize(){ return 8; }

    abstract public String getMsgLabel(int type);
}
