/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

import java.util.*;
import java.awt.*;

/**
 * Overlay Network, the main class for the simulation.
 * Main components
 * a. physical nodes </p>
 *      the physical node </p>
 *      the protocol </p>
 *      the physical links and weights </p>
 *      the logical links </p>
 * b. a set of the active nodes within the network </p>
 * c. a discrete event simulator </p>
 * Main functions </p>
 * a. physical structure maintenence ( nodes add/deletion, physical link add/deletion) </p>
 * b. import/export physical topology </p>
 * c. import/export topology with protocol specific information </p>
 * d. execute the simulation, i.e. start, run, pause, step </p>
 * e. logical routing, used by the statisic collection package </p>
 * f. physical routing, used to provide services for the protocols </p>
 * g. graph-based simulation </p>
 *
 */

abstract class OverlayNetwork
{
    final static Color phyNodeColor = Color.gray;
    final static Color phyEdgeColor = Color.gray;
     final static float SIM_STEP = 0.005f;

     /** a vector that holds all the nodes in the network */
    Vector nodes;
    /** a vector that holds all the nodes in the overlay network */
    Vector active_nodes;
    /** indicate whether a re-calculation of routing table is needed */
    boolean reroute=true;
    /** a discrete-event simulator */
    SimEventProcessor seq;
    /** The Physical Layer Simulator */
     public PhysicalLayer phyLayer;
     public float sim_time;
    
     
    /**Constructor
     * @param ta    a physical network topolog
     */
    OverlayNetwork( TopoAdaptor ta ){
          sim_time = 0.0f;
        phyLayer = new SimplePhysicalLayer(this);
        nodes = new Vector();
        active_nodes = new Vector();
        seq = new SimEventProcessor();

        int i;
        PhyNode[] pnodes = ta.getNodes();

        for(i=0; i<pnodes.length;i++){
            addNode( pnodes[i]);
        }
        for(i=0; i<nodes.size();i++){
            fireMenu((OverlayNode)nodes.elementAt(i),0);
        }
        
    }

    /**
     * Constructor
     */
    OverlayNetwork( ) {
          sim_time = 0.0f;
        phyLayer = new SimplePhysicalLayer(this);
        nodes = new Vector();
        active_nodes = new Vector();
        seq = new SimEventProcessor();
    }

    /**
     * add an physical edge. Note, edges are always bi-directional
     * @param from starting node
     * @param to   ending node
     * @param distance the lenght of the edge
     */
    public boolean addEdge( OverlayNode from, OverlayNode to, float distance ){
    //add edges in a symmetrically way, i.e. always add two edges
        if( from.hasPhyEdge(to) ) return false;

        reroute = true;
        from.insertPhyEdge( to, distance );
        to.insertPhyEdge( from, distance );
        return true;
    }

    /**
     * @return the vector containing the nodes in the overlay network
     */
    public Vector getActiveNodes() { return active_nodes;}

    /**
     * @return the vector containing all the nodes
     */
    public Vector getPhyNodes() { return nodes;}

    /*public boolean addLogicalEdge( OverlayNode from, OverlayNode to ){
    //add edges in a symmetrically way, i.e. always add two edges
        if( from.hasLogicalEdge(to) ) return false;

        from.insertLogicalEdge( to );
        to.insertLogicalEdge( from );
        return true;
    }*/
	
    /**
     * add a physical node with a specified address
     * @param addr the physical address of the node
     */
    public OverlayNode addNode( XYAddress addr ){
        reroute = true;
        Enumeration e = nodes.elements();
        OverlayNode onode;
        boolean unique = true;

        while( e.hasMoreElements() ){
            onode = (OverlayNode)e.nextElement();
            if( onode.getAddress().equals(addr) ){
            lotusDebug.errorln(" non unique node insertion detected");
            lotusDebug.errorln(" non unique address:" + addr.getX() + ":" + addr.getY() );
            unique = false;
            break;
            }
        }
//luo
//				if (addr.x != -1)
        onode = new OverlayNode( addr, this,  null); //there must be a name??
        nodes.addElement( onode );
        return onode;

    }
    
      /**
       * added in Oct 25 for mobile node
     * add a physical node with a specified address
     * @param addr the physical address of the node
     */
    public OverlayNode addNode( PhyNode pnode ){
            XYAddress addr = new XYAddress(pnode.GetX(),pnode.GetY());                                       
        Enumeration e = nodes.elements();
        OverlayNode onode;
        boolean unique = true;
        

        while( e.hasMoreElements() ){
            onode = (OverlayNode)e.nextElement();
            if( onode.getAddress().equals(addr) ){
            lotusDebug.errorln(" non unique node insertion detected");
            lotusDebug.errorln(" non unique address:" + addr.getX() + ":" + addr.getY() );
            unique = false;
            break;
            }
        }

        onode = new OverlayNode( pnode, this, null);
        nodes.addElement( onode );
        return onode;

    }
    /**
     * remove a node in the network
     * @param node the node to be removed
     * @reutrn ture if the node exists, false otherwise
     */
    public boolean removeNode( OverlayNode node ){
        if( nodes.contains(node) == false ) return false;
        reroute = true;
        Enumeration enum = node.getPhyNeighbor();
        while( enum.hasMoreElements() ) {
            OverlayNode onode = (OverlayNode) enum.nextElement();
            onode.removePhyEdge(node);
        }
        nodes.remove(node);
        active_nodes.remove(node);
        return true;
    }

    /**
     * remove an edge
     * @param from the starting node
     * @param to the ending node
     */
    public boolean removeEdge( OverlayNode from, OverlayNode to ){
        if( from.hasPhyEdge(to) == false || to.hasPhyEdge(from) == false ) return false;
        from.removePhyEdge(to);
        to.removePhyEdge(from);
        reroute = true;
        return true;
    }

    /**
     * An abstract function, which must be implemented by each overlay
     * protocol.
     * @param src the source node
     * @param dst the destination node
     * @return the next hope node in the logical network
     */
    public abstract OverlayNode getLogicalNextHop(OverlayNode src, OverlayNode dst);


    /**
     * find the closest node to a physical location. Used in GUI interface
     */
    public OverlayNode findClosest( XYAddress addr, int radius ){
        int i;
        float dist=Float.MAX_VALUE;
        int index=-1;

        for( i=0; i<nodes.size(); i++){
            if( dist > addr.distanceTo( ((OverlayNode)nodes.elementAt(i)).getAddress()  ) ){
            dist = addr.distanceTo( ((OverlayNode)nodes.elementAt(i)).getAddress()  );
            index=i;
            }
        }

        if( -1 == index ) return null;
        if( dist > radius ) return null;

        return (OverlayNode)nodes.elementAt(index);

    }

    /**
     * find the edge which is the closest to a physical address
     */

    public boolean findClosestLine( XYAddress addr, int radius, OverlayNode []nodeArray ){
        double dista;
        double distb;
        double distc;
        double cos1;
        double cos2;
        double sin1;

        for( int i=0; i<nodes.size(); i++){
            for( int j=0; j<i; j++){
                OverlayNode fromnode = (OverlayNode) nodes.elementAt(i);
                OverlayNode tonode = (OverlayNode) nodes.elementAt(j);

                dista = addr.distanceTo(fromnode.getAddress());
                distb = addr.distanceTo(tonode.getAddress());
                distc = fromnode.getAddress().distanceTo(tonode.getAddress());

                /* the structure

                        from ------------c-------------to
                           - 1                       2-
                             -                      -
                               a                 b
                                 -            -
                                    -      -
                                       node

                    */
                cos1 = (dista*dista + distc*distc - distb*distb)/(2*dista*distc);
                cos2 = (distb*distb + distc*distc - dista*dista)/(2*distb*distc);

                if( cos1 < 0 || cos2 < 0 ) continue;
                sin1 = Math.sqrt(1.0 - cos1*cos1);
                if( dista*sin1 <= radius ) {
                    if( fromnode.hasPhyEdge(tonode) ) {
                        nodeArray[0] = fromnode;
                        nodeArray[1] = tonode;
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * @return the physical topology of the network
     */
    public TopoAdaptor returnTopo( ){
        TopoAdaptor_HM topo = new TopoAdaptor_HM();

        topo.nodes = new PhyNode[nodes.size()];

        int numedges=0;
        Enumeration e = nodes.elements();

        while( e.hasMoreElements() ){
            OverlayNode onode =(OverlayNode) e.nextElement();
            numedges += onode.getPhyNeighborNumber();
        }

        topo.edges = new PhyEdge[numedges];

        int i, j;
        for( i=0,j=0; i<nodes.size(); i++){

            OverlayNode fromnode = (OverlayNode) nodes.elementAt(i);
            topo.nodes[i] = new PhyNode(
                        fromnode.getAddress().getX(),
                        fromnode.getAddress().getY() );

            /*if( active_nodes.contains( fromnode )){
            topo.activeNodes.addElement( topo.nodes[i] );
            }*/

            Enumeration neighbor = fromnode.getPhyNeighbor();

            while( neighbor.hasMoreElements() ){
            OverlayNode tonode = (OverlayNode) neighbor.nextElement();

            topo.edges[j++] = new PhyEdge(
                            i,
                            nodes.indexOf(tonode),
                            fromnode.getDistanceTo(tonode) );

            }
        }

        return topo;
    }

    /**
     * Update the Adjacency list of node to node connectivity
     */
    public void updatePhysicalAdjacency()
    {
        for (int i = 0; i < nodes.size(); i++)
            ((OverlayNode) nodes.elementAt(i)).updatePhysicalNeighbors();
    }
    public void updatePhysicalNodes()
    {
        for (int i = 0; i < nodes.size(); i++)
            ((OverlayNode) nodes.elementAt(i)).phyNode.move();
    }
    public void MACStep()
    {
        for (int i = 0; i < nodes.size(); i++)
            ((OverlayNode) nodes.elementAt(i)).MAC.MACStep();
    }

    /**
     * @return the simulation time
     */
    final float simTime(){ return seq.getSimTime(); }

    /**
     * insert an simulation event to the discrete event simulator
     */
    final void insertEvent( SimEvent e ) { seq.insertEvent(e); }

    /**
     * get all the pending events
     */
    final Enumeration getPendingEvent( ) { return seq.getPendingEvents(); }

    /**
     * advance the simulation to the next pending event
     */
    void step()
    {
        SimEvent se;
        float end_time = sim_time + SIM_STEP;

        while(end_time > sim_time)
        {
        	se = seq.getNextEvent(end_time);
        	
            if( (se == null) || (se.eventType() != se.MESSAGE_EVENT))
            {
                this.updatePhysicalNodes();
                this.updatePhysicalAdjacency();
                this.MACStep();
                sim_time = end_time;
                end_time = sim_time + SIM_STEP;
            }
            else
            {
            	
                if( se != null )
                {
                    if(se.getRecipient()==null)
                    {
                        for(int i =0;i <se.getSender().physical_neighbors.size();i++)
                        {
                            OverlayNode temp = (OverlayNode)se.getSender().physical_neighbors.elementAt(i);
                            if(temp!=se.getSender())
                                temp.receiveEvent(se);
                        }
                    }
                    else if(se.getRecipient().phyNode.isNeighbor(se.getSender().phyNode))
                        se.getRecipient().receiveEvent(se);
                }
                return;
            }
        }
    }

    /**
     * run the simulation for the specific amount of time
     * @param time the duration to run the simulation
     */
   void advance(float time)
    {
        SimEvent se;
        float end_time = sim_time + SIM_STEP;
        this.updatePhysicalNodes();
        this.updatePhysicalAdjacency();
        this.MACStep();
        sim_time = end_time;
        while( (se=seq.getNextEvent(end_time)) != null )
        {
        	if(se.getRecipient()==null)
            {
            	for(int i =0;i <se.getSender().physical_neighbors.size();i++)
                {
                    OverlayNode temp = (OverlayNode)se.getSender().physical_neighbors.elementAt(i);
                    if(temp!=se.getSender())
                        temp.receiveEvent(se);
                }
            }
            else if(active_nodes.contains(se.getRecipient())&& (se.getRecipient().phyNode.isNeighbor(se.getSender().phyNode)) )
            {
                se.getRecipient().receiveEvent(se);
            }
            
        }
    }
    //start the simulation: start the timers of each node and sending the Iam leader to
    //the server
    boolean simRunning = false;

    /**
     * Abstract function, used by each overlay protocol to implement those
     * initialze functions before the staring of the simulation
     */
    abstract boolean start();
    /**
     * Abstract function, used by each overlay protocol to clean up the current simulation
     * and restore the simulator to its default state
     */
    abstract void reset();
    /**
     * @return whether the simulation is running
     */
    boolean isRunning() { return simRunning; }

    /**
     * An abstract function, implemented by each overlay protocol to build
     * its own overaly topology. This function actually implements the
     * static simulation
     */
    abstract boolean buildOverlay();

    //the protocol-dependent part of the GUI interface part
    /**
     * Abstract function, used by each protocol to implement protoc-specific
     * functions
     */
    public abstract String [] getMenus( );
    /**
     * Abstract function, it is the callback function invoked by the simulator
     * and implemented by each overlay protocol to execute protocol-specific
     * operations
     */
    public abstract boolean fireMenu( OverlayNode onode, int index );

    
    //the protocol menu and instance creation part
    final static String [] theMobilemode = {
        "Random Motion",
          "Linear Motion",
    };
    
    /** @return current supported protocols */
    static String[] getMobilemode(){
        return theMobilemode;
    }
    //the protocol menu and instance creation part
    final static String [] theProtocols = {
        "DT-precise",
    };
    /** @return current supported protocols */
    static String[] getProtocols(){
        return theProtocols;
    }
    
    /**
     * Create a simulation network
     */
    //Why do we need such a method to create a instance??
    static OverlayNetwork createInst(int index){
        switch (index) {
            //case 0: return new simDTPrecise();
            //should return a Run node ??
              case 0: ;//return new RunDTNetwork(null);
        }
        return null;
    }
    
    /**create a simulation network
     * @param index the type of simulation created
     * @param ta the physical topology of the network
     */
    static OverlayNetwork createInst(int index, TopoAdaptor ta){
        switch (index) {
            //case 0: return new simDTPrecise(ta);
            //should return a Run node ??
              case 0: ;//return new RunDTNetwork(null, ta);
        }
        return null;
    }

    //import/export protocol-specific protocols
    /**
     * An abstract function, implemented by each protocol to read topology description file
     * with protocol-specific information
     */
    abstract boolean protocolReader( String fname );

    /**
     * An abstract function, implemented by each protocol to save topology description file
     * with protocol-specific information
     */
    abstract boolean protocolWriter( String fname );
}

