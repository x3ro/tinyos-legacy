import java.awt.*;
import java.util.*;
import java.io.*;


abstract class SensorNetwork extends OverlayNetwork{
    final static String formatTag = "sensor";
    float bcast_dist;
    float packet_speed;
    
    SensorNetwork(String eventfile, float bd, float bs)throws Exception{
    	super();
    	bcast_dist=bd;
    	packet_speed=bs;
    	seq=new SensorEventProcessor(eventfile, this);	
    }
    
    SensorNetwork() { super(); }
    SensorNetwork( TopoAdaptor ta ) { super(ta); }

	public abstract OverlayNode findNode(int sensorID);
	public abstract void addSensor(int sensorID);
	
   	OverlayNode findNode(XYAddress addr){
		return findClosest(addr, 0);	
	}
	
    boolean buildOverlay() {
    	//buildPhysicalRoute();

	    return true;
    }

    private final String [] treeMenu = {
        "activate",
        "deactivate",
    };

    public String[] getMenus() {return treeMenu;}

    /**
     * add a node to the overlay network
     */
    private boolean activateNode( OverlayNode o, int sensorID){
        //if( dtServer == null ) return false;
        if( active_nodes.contains(o)) return false;
        SensorNode ssnode = new SensorNode( o, sensorID, this);
        o.setProtocol(ssnode);
        active_nodes.addElement(o);
        return true;
    }

    /**
     * delete a node from the overlay network
     */
    private boolean deactivateNode( OverlayNode o){
        if( active_nodes.contains(o) ){
            o.getProtocol().resetProtocol();
            o.setProtocol(null);
            active_nodes.remove(o);
            return true;
        }else{
            return false;
        }
    }
   

    boolean start() {
        this.simRunning = true;
        for( int i=0; i<active_nodes.size(); i++ ){
            OverlayNode onode = (OverlayNode) active_nodes.elementAt(i);
            onode.getProtocol().startProtocol();
        }
        return true;
    }

    void reset() {
        this.simRunning = false;
        for( int i=0; i<active_nodes.size(); i++ ){
            OverlayNode onode = (OverlayNode) active_nodes.elementAt(i);
            onode.getProtocol().resetProtocol();
        }
        sim_time=0;
        try{
        	seq.reset();
        }catch(Exception e){
        	lotusDebug.errorln(e.toString());	
        }
    }


    boolean protocolReader( String filename ){
        
	    return true;

    }

    boolean protocolWriter( String filename ){
        
        return true;
    }

    public OverlayNode getLogicalNextHop(OverlayNode src, OverlayNode dst ) {
		return null;
	}
	
	public boolean fireMenu( OverlayNode onode, int index ) {
        //do nothing
        return true;
    }

	void step()
    {
        SimEvent se;
        

        while((se = seq.getNextEvent())!=null)
        {
        	//lotusDebug.errorln(" simtime:"+sim_time);
        	
        	if(se!=null && se.eventType()>=3 && se.getRecipient()!=null){
        		//added by Guangyu to support sensor event
        		SensorNode sn=(SensorNode)se.getRecipient().getProtocol();
        		if(sn!=null){
        			lotusDebug.errorln("Handle event: "+se);
        			sn.handleEvent(se);
        		}else{
        			lotusDebug.errorln("Fail to find handler: "+se);
        		}
        		sim_time=se.getTime();
        		//lotusDebug.errorln(" simtime:"+sim_time);
        		return;
        	}
        
        }
    }
	boolean hasMoreEvents(){
		return !((SensorEventProcessor)seq).endOfEvent;
	}
    /**
     * run the simulation for the specific amount of time
     * @param time the duration to run the simulation
     */
   void advance(float time)
    {
    	
    	float end_time;
    	end_time = sim_time + time;
        if(time<0){
        	sim_time=0;
        	reset();
    	}
        SimEvent se;
        SensorNode sn=null;
        
        while( (se=seq.getNextEvent(end_time)) != null )
        {
        	if(se!=null && se.eventType()>=3 && se.getRecipient()!=null){
        		//added by Guangyu to support sensor event
        		sn=(SensorNode)se.getRecipient().getProtocol();
        		if(sn!=null){
        			if(time>0)
        				lotusDebug.errorln("Handle event: "+se);
        			sn.handleEvent(se);
        		}else{
        			lotusDebug.errorln("Fail to find handler: "+se);
        		}
        	}
            
        }
        
        sim_time=end_time;
    }
    
}

