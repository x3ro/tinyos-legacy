import java.io.*;
import java.util.*;


class SensorEventProcessor extends SimEventProcessor{
	
	BufferedReader event_input;
	float start_time=0;
	String event_file;
	SensorNetwork sensor_net;
	boolean endOfEvent=false;
	final static int MAX_QUEUE_SIZE=1000;
	
	SensorEventProcessor(String filename, SensorNetwork sn)throws Exception{
		super();
		event_file=filename;
		sensor_net=sn;
		reset();
	}
	public void insertEvent( SimEvent se)
    {
    	if(start_time<=0 && se.getTime()>0){
    		//set the initial sim_time
    		//start_time=se.getTime();	
    	}
    	se.time-=start_time;
    	
    	super.insertEvent(se);
    	
    	
    }
    
	int readSomeEvents(){
		String line;
		int count=0;
		if(the_queue.size()>=MAX_QUEUE_SIZE)return count;
		
		try{
			line=event_input.readLine();
			
			while(line!=null){
				endOfEvent=false;
				line=line.trim();
				if(!line.equals("") && !line.startsWith("#")){
					
					SensorEvent se=new SensorEvent(line, sensor_net);
					//debug
					//lotusDebug.errorln("line="+line);
    				//lotusDebug.errorln("Insert event: "+se.toString());
    				if(se.event_type!=SensorEvent.SSEVENT_NULL){
						insertEvent(se);
						count++;
						if(the_queue.size()>=MAX_QUEUE_SIZE)return count;
					}
					
				}
				
				line=event_input.readLine();
			}
			if(line==null)endOfEvent=true;
			
			return count;
		}catch(IOException e){
			lotusDebug.errorln(e.toString());
			return 0;	
		}
	}
	/** @return those pending events */
    public Enumeration getPendingEvents() {
    	readSomeEvents();
        return super.getPendingEvents();
    }
    
	/** @return the next pending event and advance the sim time */
    public SimEvent getNextEvent()
    {
        readSomeEvents();
        SimEvent se=super.getNextEvent();
        return se;
    }

    /** @return the next event within the endTime
     *  If the return is null, advance the time to end time
     *  If the return is not-null, advance the time using getNextEvent
     */

    public SimEvent getNextEvent(float endTime ){
		readSomeEvents();
        SimEvent se=super.getNextEvent(endTime);
        return se;
    }
    
    public void reset()throws Exception{
    	start_time=0;
    	super.reset();
    	sim_time=0;
    	endOfEvent=false;
    	if(event_input!=null)event_input.close();
    	event_input=new BufferedReader(new FileReader(event_file));
    	//readSomeEvents();
	}
	
}