class SimpleMAC implements MACInterface
{
    public final int MAC_QUEUE_SIZE = 10;
    public final int MAX_BACKOFF_STEPS = 16;

    OverlayNode node;
    SimEventMsg msgQueue[];
    int queueHead, queueTail;
    int backoffStep;
    int backoffInterval;

    public SimpleMAC(OverlayNode olNode)
    {
        msgQueue = new SimEventMsg[MAC_QUEUE_SIZE];
        node = olNode;
        backoffStep = 1;
        backoffInterval = 0;
        queueHead = 0;
        queueTail = 0;
    }

    public boolean sendMsg(SimEventMsg msg)
    {
        if(insertIntoMsgQueue(msg))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean insertIntoMsgQueue(SimEventMsg msg)
    {
        if((queueTail+1)%MAC_QUEUE_SIZE == queueHead) /* Queue Full */
            return false;
        else
        {
            msgQueue[queueTail] = msg;
            queueTail = (queueTail+1)%MAC_QUEUE_SIZE;
            return true;
        }
    }

    public void sendMessages()
    {
        if((backoffInterval == 0) && (queueHead != queueTail) )
        {
            if(node.net.phyLayer.sendMsg(msgQueue[queueHead]))
            {
                queueHead = (queueHead+1)%MAC_QUEUE_SIZE;
                backoffStep = 1;
            }
            else
            {
                if(backoffStep < MAX_BACKOFF_STEPS)
                    backoffStep *= 2;
                backoffInterval = backoffStep + (int)(Math.random()*backoffStep);
            }
        }
    }

    public void MACStep()
    {
        sendMessages();
        if(backoffInterval != 0)
            backoffInterval--;
    }
}

