/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/
import java.lang.*;
import java.awt.*;
import java.util.*;

/**
 * Overlay Node, composed of physical and logical parts
 * Main components </p>
 * a. physical address </p>
 * b. physical links </p>
 * c. logical links </p>
 * d. physical name </p>
 * e. routing table to provide the physical network service </p>
 * f. protocol(logical part) </p>
 * Main functions </p>
 * a. maintenence of the physical/logical links </p>
 *      note: the physical links are added/deleted by outside
 *            the logical links are added/deleted by the protocol/graph-sim
 * b. dispatch/receive the events for two layers. </p>
 *          interface to the event dispatcher: send/receive the event(timer/msg)
 *          interface to the protocol: send/receive the event(timer/msg)
 *          for the message, it may need to route the message to the next hop
 * c. add/delete/start/end the running protocol </p>
 */

class OverlayNode implements physicalInterface{

    final static float PACKET_SPEED = 3f;
    final static float PACKET_BCAST_DIST = 1f;
    //node attributes
    /** name of the node */
    String name;
     /** physical node*/
     PhyNode phyNode;
    /** physical address of the node */
    XYAddress addr;

    //logical structure
    /**
     * protocol running on this node. It can be empty
     * if no protocol is running
     */
    protocolInterface protocol;
    /** neighbors in the overlay */
    Vector logical_neighbors;      // logical neighbors
    /** color used to display edges in the overlay */
    Vector logical_colors;         // the link color, display purpose
    /** the width of the logical edges */
    Vector logical_width;          // the link width, display purpose;

    //physical structure
    /** physical neighbors */
    Vector physical_neighbors;       // physical neighbors
    /** the lenght of the physical edges */
    Vector physical_distances;       // physical neighbors

    //routing table, the next hop is indexed by the node's position
    //in the OverlayNetwork's nodes vector
    /** routing table at this node. It stores the next hope node from this
     *  node to all the other nodes
     *
     */
    OverlayNode [] routing_nexthop;
    /** a referece to the class Overlay Network */
    OverlayNetwork net;
     /** MAC Layer simulator */
     public MACInterface MAC;
     /** time when the last message sent by this node will be delivered (junk data) */
     public float timeLastMsg;

    /**constructor
     * @param a node's physical address
     * @param onet a reference to the overlay network
     * @param sname node's name
     */
    public OverlayNode(XYAddress a, OverlayNetwork onet, String sname)
    {
        phyNode = new PhyNode(a.getX(), a.getY());
        addr = a;
        net = onet;
        name = sname;
        logical_neighbors = new Vector();
        logical_colors = new Vector();
        logical_width = new Vector();
        physical_neighbors = new Vector();
        physical_distances = new Vector();
          timeLastMsg = net.simTime();
          MAC = new SimpleMAC(this);
    }

    /**constructor
     * @param a node's physical address
     * @param onet a reference to the overlay network
     * @param sname node's name
     */
    public OverlayNode(PhyNode pnode, OverlayNetwork onet, String sname)
    {
        phyNode = pnode;
        addr = new XYAddress(pnode.GetX(),pnode.GetY());
        net = onet;
        name = sname;
        logical_neighbors = new Vector();
        logical_colors = new Vector();
        logical_width = new Vector();
        physical_neighbors = new Vector();
        physical_distances = new Vector();
          timeLastMsg = net.simTime();
          MAC = new SimpleMAC(this);
    }
    
    

    //attributes method
    /** @return node name */
    public String getName() { return name; }
    public String getDetails() {
        if(protocol!=null){
            return protocol.getDetails();
        }else return "";    
    }
    
    /** set the name of this node */
    public void setName( String sname) { name = sname; }
    /** @return the physical address of the node */
    public XYAddress getAddress()  {   return new XYAddress(phyNode.GetX(),phyNode.GetY()); }
    /** set the address of the node */
    public void setAddress( XYAddress a ) { 
        phyNode.SetXF(a.getX());
        phyNode.SetYF(a.getY());
    }

    //logical & physical links' related method
    /**
     * test if the node is its physical neighbor
     */
    boolean hasPhyEdge( OverlayNode n ) {
        if( physical_neighbors.contains(n) ) return true;
        else return false;
    }

    /**
     * test if the node is its logical neighbor
     */
    boolean hasLogicalEdge( OverlayNode n){
        if( logical_neighbors.contains(n)) return true;
        else return false;
    }

    /**
     * insert a physical edge for this node
     * @param n the new neigbhor
     * @param weight the length of the node
     */
    boolean insertPhyEdge( OverlayNode n, float weight ){
        if( physical_neighbors.contains(n) ) return false;
        else  {
            physical_neighbors.addElement(n);
            physical_distances.addElement( new Float(weight) );
        }
        return true;
    }

    /**
     * @return all the physical neighbors of this node
     */
    Enumeration getPhyNeighbor(){
        return physical_neighbors.elements();
    }

    /**
     * @return all the logical neighbors of this node
     */
    Enumeration getLogicalNeighbor(){
        return logical_neighbors.elements();
    }

    /**
     * @return the colors of the logical links
     */
    Enumeration getLogicalColor() {
        return logical_colors.elements();
    }

    /**
     * @return the lengths of the logical links
     */
    Enumeration getLogicalWidth() {
        return logical_width.elements();
    }

    /**
     * @return the total number of logical neighbors
     */
    int getLogicalNeighborNumber(){ return logical_neighbors.size();}
    /**
     * @return the total number of physical neighbors
     */
    int getPhyNeighborNumber( ) { return physical_neighbors.size(); }
    /**
     * @return the index of this physical node in all the neighbors
     */
    int getPhyNeighborIndex( OverlayNode onode ) {
        return physical_neighbors.indexOf( onode );
    }

    /**
     * @return the legth of a physical edge, which is represented by
     * its index among all the neighbors
     */
    float getPhyEdgeLen( int index ){
        return ((Float)physical_distances.elementAt(index)).floatValue();
    }

    /**
     * remove an physical edge
     * @param n the node at the other end of the edge
     * @return true if such a neighbor exists, false otherwise
     */
    boolean removePhyEdge( OverlayNode n ){
        if( physical_neighbors.contains(n) ) {
            int index = physical_neighbors.indexOf(n);
            physical_neighbors.remove(index);
            physical_distances.remove(index);
            return true;
        }else{
            return false;
        }
    }

    /**
     * Update the physical neighbor list
     */
    public void updatePhysicalNeighbors()
    {
        PhyNode temp;
        float distance;
        OverlayNode otherNode;
        
        Enumeration enum = getPhyNeighbor();
        while( enum.hasMoreElements() ) {
            otherNode = (OverlayNode) enum.nextElement();
            removePhyEdge(otherNode);
        }

        for (int i = 0; i < net.nodes.size(); i++)
        {
            otherNode = (OverlayNode)net.nodes.elementAt(i);
            if( phyNode.isNeighbor(otherNode.phyNode) )
                insertPhyEdge(otherNode, phyNode.distanceTo(otherNode.phyNode));
        }
    }
    
    public void move()
    {
        phyNode.move();
    }
    
    //routing related functions
    /**
     * get the distance to a node
     * @param n the destination node
     * @return the distance
     */
    public final float getDistanceTo( OverlayNode n)
    {
        if (n == this)
            return (float) 0.0;

       else return phyNode.distanceTo(n.phyNode);

    }

    /**
     * clear the routing table of this node
     */
    public void clearRoutingTable()
    {
        routing_nexthop = null;
        routing_nexthop = new OverlayNode[net.getPhyNodes().size()];
    }

    /**
     * insert an routing table entry
     */
    public void insertIntoRoutingTable(OverlayNode destination, OverlayNode next_hop, float distance)
    {
        int index = net.getPhyNodes().indexOf(destination);
        routing_nexthop[index] = next_hop;
    }

    /**
     * @return the next hop node from this node to destination
     */
    public OverlayNode getPhyNextHop( OverlayNode destination)
    {
        int index = net.getPhyNodes().indexOf(destination);
        //lotusDebut.println("inidex at: " + index );
        if( index < 0 ) return null;
        if( routing_nexthop[index] == null ) return null;
        return routing_nexthop[index];
    }

    /**
     * clear all the logical edges
     */
    public void clearLogicalEdges(){
        this.logical_colors.clear();
        this.logical_neighbors.clear();
        this.logical_width.clear();
    }

    //physicalInterface
    /**
     * part of the physicalInterface implemenation
     * @return the logical neighbors of this node
     */
    public Enumeration logicalLinks() {
        return getLogicalNeighbor();
    }

    /**
     * part of the physicalIniterface implementation
     * @return the physical neighbors of this node
     */
    public Enumeration physicalLinks(){
        return getPhyNeighbor();
    }

    /** <0 if the physical node is not a neighbor
     *  otherwise, the link weight
     */
    //float physicalWeight( physicalInterface );

    /**
     * @the physical address of this node
     */
    public XYAddress physicalAddress(){
        return getAddress();
    }

    /**
     * insert a logical edge at this node
     * @param n the other end of the logical edge
     * @param color the color of the edge, for display purpose
     * @param width the width of the edge, for dispaly purpose
     */
    public boolean insertLogicalEdge( OverlayNode n, Color color, int width ){
        if( logical_neighbors.contains(n) ) return false;
        else  {
            logical_neighbors.addElement(n);
            logical_colors.addElement(color);
            logical_width.addElement( new Integer(width) );
        }
        return true;
    }

    /**
     * remove a logical neighbor
     */
    public boolean removeLogicalEdge(OverlayNode n){
        if( logical_neighbors.contains(n) ){
            int index = logical_neighbors.indexOf(n);
            logical_neighbors.remove(index);
            logical_colors.remove(index);
            logical_width.remove(index);
            return true;
        }
        else{
            return false;
        }
    }

    //both the timer and the messages
    /**
     * send a message, used by the logical part of the node
     */
    public boolean sendMsg( SimEventMsg msg ){
        OverlayNode dst = msg.getDst();
        //multicast message
          if(dst==null){
            msg.setSender( this );
            msg.setSrc( this );
            msg.setRecipient(null);
                if(msg.eventType() == SimEvent.MESSAGE_EVENT)
                {
                    //net.phyLayer.sendMsg(msg);
                    MAC.sendMsg(msg);
                    return true;
                }
                else
             {
                    msg.setTime( net.simTime()+ this.phyNode.GetRadiusF()/PACKET_SPEED );
                net.insertEvent( msg );
                return true;
                }
        }
          //unicast message
          else{
            // OverlayNode nextHop = this.getPhyNextHop(dst);
            // if( null == nextHop ){
            // lotusDebug.errorln("packet can not be routed");
            // return false;
            // }
            msg.setSender( this );
            msg.setSrc( this );
                msg.setRecipient(dst);
                if(msg.eventType() == SimEvent.MESSAGE_EVENT)
                {
                    //net.phyLayer.sendMsg(msg);
                    MAC.sendMsg(msg);
                    return true;
                }
                else
             {
                    msg.setTime( net.simTime()+ this.phyNode.GetRadiusF()/PACKET_SPEED );
                net.insertEvent( msg );
                return true;
                }
         }
     }

    /**
     * set a timer event
     * @param interval the interval of this node
     * @param index the type of the timer
     *
     */
    public void setTimer( float interval, int index ) {
        SimEventTimer timer = new SimEventTimer( net.simTime()+interval, this, index );
        //added by Guimin
        timer.setSender(this);
        timer.setRecipient(this);
        net.insertEvent( timer );
    }

    /**
     * @return the simulation time
     */
    public float simTime( ) { return net.simTime(); }

    //message handling from/to Simulation Event Processor
    /**
     * handle the events from simulation event
     */
    public void receiveEvent( SimEvent event){
        if( (event.getRecipient() != this) && (event.getRecipient() != null)) {
            lotusDebug.errorln("event dispatch error");
            return;
        }
        if( event.eventType() == SimEvent.PROTOCOL_TIMER_EVENT ) {
            if( protocol == null ) {
                lotusDebug.errorln("pending timer event is discarded");
                return;
            }
            protocol.handleTimer( ((SimEventTimer)event).getIndex() );
        }else if( event.eventType() == SimEvent.MESSAGE_EVENT ){
            SimEventMsg msg = (SimEventMsg) event;
            if( ! ( net.getPhyNodes().contains(msg.getSrc())) ) {
                lotusDebug.errorln("unknown sender/receiver packet" );
                return;
            }
            if( msg.getDst() == this || msg.getDst() == null) {
                if( protocol == null ) {
                    lotusDebug.errorln("pending msg event is discarded");
                    return;
                }
                protocol.handleMsg( msg );
                
            }/*else{
                
                OverlayNode nextHop = getPhyNextHop( msg.getDst() );
                if( null == nextHop ) {
                    lotusDebug.errorln("packet can not be routed");
                    return;
                }else{
                    msg.setSender( this );
                    msg.setRecipient( nextHop );
                    msg.setTime( net.simTime() + getDistanceTo(nextHop)/PACKET_SPEED );
                    net.insertEvent( msg );
                }
            }*/
        }
    }

    /** set the logical node running on this node */
    void setProtocol( protocolInterface p ) {
        protocol = p;
    }

    /** return the logical node running on this node*/
    protocolInterface getProtocol( ) {
        return protocol;
    }
}
