/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

/**
 * This class implements the simulation event
 */
class SimEvent
{
    /** time of the event */
    float time;
    /** sender of the event */
    OverlayNode sender;
    /** recipient of the event */
    OverlayNode recipient;
    /** type of the message */
    int event_type;

    final static int MESSAGE_EVENT = 1;
    final static int PROTOCOL_TIMER_EVENT = 2;

    public SimEvent(float t, OverlayNode asender, OverlayNode onode, int et)
    {
        time = t;
        recipient = onode;
        sender = asender;
        event_type = et;
    }

    public float getTime()
    {
        return time;
    }

    public void setTime(float t)
    {
        time = t;
    }

    public OverlayNode getRecipient()
    {
        return recipient;
    }

    public OverlayNode getSender()
    {
        return sender;
    }

    public void setRecipient(OverlayNode onode ){
        recipient = onode;
    }

    public void setSender(OverlayNode onode ){
        sender = onode;
    }

    public int eventType()
    {
        return event_type;
    }
}
