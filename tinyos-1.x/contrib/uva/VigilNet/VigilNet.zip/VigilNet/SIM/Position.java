class Position
{
    private float x;
    private float y;
    private float z;

    Position()
    {
        x = 0;
        y = 0;
        z = 0;
    }

    Position(float xVal, float yVal, float zVal)
    {
        x = xVal;
        y = yVal;
        z = zVal;
    }
    
    Position(Position initial)
    {
        x = initial.getX();
        y = initial.getY();
        z = initial.getZ();
    }
    
    public float getX()
    {
        return x;
    }

    public float getY()
    {
        return y;
    }

    public float getZ()
    {
        return z;
    }

    public void setX(float xVal)
    {
        x = xVal;
    }

    public void setY(float yVal)
    {
        y = yVal;
    }

    public void setZ(float zVal)
    {
        z = zVal;
    }

    public float distanceTo(Position toPosition)
    {
        return (float)Math.sqrt(
                                (x - toPosition.getX())*(x - toPosition.getX()) +
                                (y - toPosition.getY())*(y - toPosition.getY()) +
                                (z - toPosition.getZ())*(z - toPosition.getZ()) 
                            );
    }
}

