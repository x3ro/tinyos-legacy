/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/
import java.util.*;
import java.lang.*;
import java.io.*;

/**
 * Topology adaptor for home-made description
 */
class TopoAdaptor_HM extends TopoAdaptor{

    TopoAdaptor_HM( String filename ){
    loadFile(filename);
    }

    TopoAdaptor_HM( ){}

    boolean loadFile( String filename ){
        try
        {
            FileReader input = new FileReader(filename);
            BufferedReader br_input = new BufferedReader(input);
            processLoadStream( br_input  );
            br_input.close();  // I assume this closes input.
        }
        catch (Exception e)
        {
            lotusDebug.println("exception at TopoAdaptor_HM" + e );
            return false;
        }
        return true;

    }

    private void processLoadStream(BufferedReader br) throws Exception
    {
    String line = br.readLine();
    
    StringTokenizer token = new StringTokenizer(line);

    int numnodes = (Integer.valueOf( token.nextToken() )).intValue();
    lotusDebug.println(new Integer(numnodes).toString());
    nodes = new PhyNode[numnodes];

    int i;
    for( i=0; i<numnodes; i++){

        line = br.readLine();

        token = new StringTokenizer(line);

        //token.nextToken();
        float speed = 0;
        float xc = (Float.valueOf( token.nextToken() )).floatValue();
        float yc = (Float.valueOf( token.nextToken() )).floatValue();
        int mobilityMode = (Integer.valueOf( token.nextToken() )).intValue();
        if(mobilityMode!=0){
            speed =    (Float.valueOf( token.nextToken() )).floatValue();

        }
        nodes[i] = new PhyNode(xc,yc);
        if(mobilityMode != 0)
        {
            nodes[i].setSpeed(speed);
            if(mobilityMode == 1)
                nodes[i].initMobility("Random Motion");
            else if(mobilityMode == 2)
                nodes[i].initMobility("Linear Motion");
        }
        //lotusDebug.println( "Add nodes:" + xc + "," + yc );
        /*if( token.hasMoreTokens() ) {
        String tag = (token.nextToken()).trim();
        if( tag.equals( "Y" ) ){
            activeNodes.addElement(nodes[i]);
        }
        }*/
    }

    
    }

}
