public interface MobilityInterface
{
    void mobilityEnable();
    void mobilityDisable();
    Position move(float timeDifference, Position prev);
}
