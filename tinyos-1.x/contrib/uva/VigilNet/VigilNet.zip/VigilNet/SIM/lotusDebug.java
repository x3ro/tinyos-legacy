/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

import java.io.*;

/**
 * the output utility of the lotos system.
 * In case of application, the output is directed to the stdout
 * In other cases, it can be directed to different output
 */

public class lotusDebug {
    static void println( String s ) {
        System.out.println(s);
    }
    static void print( String s ){
        System.out.print(s);
    }
    static void println( ) {
        System.out.println();
    }
    static void errorln( String s ) {
        System.err.println(s);
    }
    static void error( String s ) {
        System.err.print(s);
    }
}
