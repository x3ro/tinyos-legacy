/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/
import java.awt.*;

/**
 * physical address of a node
 */

class XYAddress
{
    float x, y;

public XYAddress(float x2, float y2)
    {
        x = x2;
        y = y2;
    }

public XYAddress(Point p)
    {
        x = p.x;
        y = p.y;
    }

    /**
     * constructor in "xx,yy" format
     */
public XYAddress(String s) {
    int word_end = s.indexOf(',');
    x = Integer.valueOf(s.substring(0,word_end)).intValue();
    y = Integer.valueOf(s.substring(word_end+1,s.length())).intValue();
}

public final String toString()
    {
        StringBuffer s = new StringBuffer();
        s.append(x);
        s.append(",");
        s.append(y);
        return s.toString();
    }

public int getX()
    {
        return (int)x;
    }

public int getY()
    {
        return (int)y;
    }

public float getFloatX()
    {
        return (float)x;
    }

public float getFloatY()
    {
        return (float)y;
    }

public boolean equals(XYAddress a)
    {
            return a.getX() == x && a.getY() == y;
    }

public float distanceTo(XYAddress addr)
    {
        int dx = (int)x - addr.getX();
        int dy = (int)y - addr.getY();

        float d = (float) Math.sqrt(dx*dx + dy*dy);
    return d;
    }

public Point toPoint()
    {
        return new Point((int)x, (int)y);
    }

}
