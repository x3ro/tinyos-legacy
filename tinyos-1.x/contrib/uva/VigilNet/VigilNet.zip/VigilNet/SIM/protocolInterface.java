/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

import java.awt.*;

/**
 * This is the interfaces implemented by all the overlay protocols.
 * The physical network communiates with the protocol through this interface.
 * The interface abstracts two main functions: </p>
 * a. display related function, i.e. how to display the logial node</p>
 * b. protocol-related function, i.e. how to handle timer/packet event and
 * the start and reset of the protocol
 */
public interface protocolInterface {

    static final int shapeCircle = 0;
    static final int shapeTriangle = 1;
    static final int shapeSquare = 2;

    //*display properties
    /** the color of the logical node */
    public Color getColor();
    /** the shape of the logical node */
    public int getShape();
    
    public XYAddress getAddr1();
    public XYAddress getAddr2();
    
    public XYAddress[] getTrack1();
    public XYAddress[] getTrack2();
 
    public int getSize1();

    public String getDetails();

    //*protocol handling
    /** handle timer event */
    public void handleTimer( int index);

    /** handle message event */
    public void handleMsg( SimEventMsg msg );

    /** start the protocol at this logical node */
    public void startProtocol( );
    /** reset the protocol to its default state */
    public void resetProtocol();

}