#!/usr/bin/perl -w
use strict;
#function 0: filter result files for display
if ($ARGV[0] == 0) {
  my $file = "../ET/SystemParameters.h.et";
  local *FH;
  my $fh = *FH;

  open $fh, "< $file" or die "ERROR, module file $file, $!, aborting.\n";
  my $text = join("",<$fh>);
  close $fh;

  if (!(defined $ARGV[1]) || (($ARGV[1] != 1) && ($ARGV[1] != 2))) {
  } else {
    $text =~ s/TARGET_NUMBER\=\d\,/TARGET_NUMBER\=$ARGV[1]\,/g;
  }

  open $fh, "> $file" or die "ERROR, writing file $file, $!, aborting.\n";
  print $fh $text;
  close $fh;
}
#function 1: filter result files for display
if ($ARGV[0] == 1) {
  open(INFILE, $ARGV[1]) or die "Can't open $ARGV[1]: $!";
  open(OUTFILE, ">".$ARGV[2]) or die "Can't open $ARGV[2]: $!";
  my %GID = ();
  my $count = 1;
  my $lines = 0;
  while (<INFILE>) {
    $lines ++;
    my $line = $_;
    if ($line =~ /TRACK(\d\d+):/) {
      my $ID = $1;
      if (defined $GID{$ID}) {
        $line =~ s/$ID/$GID{$ID}/;
      } else {
        $GID{$ID} = $count;
        $line =~ s/$ID/$GID{$ID}/;
        $count ++;
      }
    }
    print OUTFILE $line;
  }

  print $lines;
  close INFILE;
  close OUTFILE; 
}
 
