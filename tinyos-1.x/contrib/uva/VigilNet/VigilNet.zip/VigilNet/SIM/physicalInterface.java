/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

import java.awt.*;
import java.util.*;

/**
 * This interface abstracts the the services provided by the physical layer.
 * A logical node can only access services from the physical network from
 * this interface.
 */

public interface physicalInterface {

    //services to the logical layer
    /** the logical links of this node */
    Enumeration logicalLinks();
    /** the physical links of this node */
    Enumeration physicalLinks();
    /** insert a logical edge
     *  @param n the other end of the edge
     *  @param c the color of the edge, for display purpose
     *  @param width the width of the edge, for display purpose
     */
    boolean insertLogicalEdge( OverlayNode n, Color c, int width);
    /**
     * remove a logical edge
     * @param n the logical neighbor
     */
    boolean removeLogicalEdge( OverlayNode n );
    /** <0 if the physical node is not a neighbor
     *  otherwise, the link weight
     */
    //float physicalWeight( physicalInterface );
    /**
     * @return the physical address of the node
     */
    XYAddress physicalAddress();
    //both the timer and the messages
    /**
     * send a message
     * @param msg the message
     * @return whether the message is sent successfully or not
     */
    boolean sendMsg( SimEventMsg msg);
    /**
     * set a timer event
     * @param interval the time after which this timer expires
     * @param the type of the timer
     */
    void setTimer( float interval, int index );
    /**
     * @return the current simulation time
     */
    float simTime( );
}