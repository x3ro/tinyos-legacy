interface MACInterface
{
    boolean sendMsg(SimEventMsg msg);
    void MACStep();
}
