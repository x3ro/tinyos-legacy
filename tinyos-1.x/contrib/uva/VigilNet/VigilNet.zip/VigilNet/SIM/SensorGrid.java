public class SensorGrid extends SensorNetwork{

	int grid_width;
	int grid_height;
	
	public SensorGrid(int gw, int gh, String eventfile, float bcast_dist, float bcast_speed)throws Exception{
		super(eventfile, bcast_dist, bcast_speed);
		grid_width=gw;
		grid_height=gh;	
		buildGrid();
		
	}
	
	void buildGrid(){
		for(int i=0;i<grid_height;i++){
			for(int j=0;j<grid_width;j++){
				OverlayNode onode=addNode(new XYAddress(j,i));
				
				if(onode!=null){
					OverlayNode left=findNode(new XYAddress(j-1,i));
					OverlayNode up=  findNode(new XYAddress(j,i-1));
					if(left!=null){
						onode.insertPhyEdge(left, 1);
						left.insertPhyEdge(onode, 1);
					}
					if(up!=null){
						onode.insertPhyEdge(up, 1);
						up.insertPhyEdge(onode, 1);	
					}
					addSensor(addressToId(new XYAddress(j,i)));
				}
			}
		}

//		OverlayNode onode=addNode(new XYAddress(0, grid_height));
//		addSensor(addressToId(new XYAddress(6,6)));
	}
	public void addSensor(int sensorID){
		activateNode(sensorID);	
	}
	private boolean activateNode(int sensorID){
        OverlayNode o=findNode(idToAddress(sensorID));
        
        if( active_nodes.contains(o)) return false;
        SensorNode ssnode = new SensorNode( o, sensorID, this);
        o.setProtocol(ssnode);
        active_nodes.addElement(o);
        return true;
        
    }
	public OverlayNode findNode(int sensorID){
		return findNode(idToAddress(sensorID));
	}
	
	XYAddress idToAddress(int id){
		return new XYAddress(id%grid_width, id/grid_width);	
	}
	
	int addressToId(XYAddress addr){
		return addr.getY()*grid_width+addr.getX();
	}
}