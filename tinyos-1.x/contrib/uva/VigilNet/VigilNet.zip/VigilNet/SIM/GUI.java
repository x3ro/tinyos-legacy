/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.*;

/**
 * The framework of the GUI interface
 */

public class GUI extends Applet implements ActionListener, ItemListener
{
    // Global Definition of the GUI Interface
    final static Color bkColor = new Color(223, 223, 223);
    final static Color dwColor = new Color(160, 160, 223);
    final static Dimension winSize = new Dimension(1000, 750);
    final static Color ndColor = Color.black;
    final static int ndDiameter = 8;
    final static Color edgeColor = Color.black;
    final static float SIM_STEP = 0.1f;
    final static int SIM_SLEEP = 100;//was 100
    //static float PACKET_SPEED = 1000.0f;
    final static Color packetColor = Color.red;
    final static int packetSRadius = 6;
    final static int packetLRadius = 60;
    final static int packetAngle = 24;
    static Dimension packetSize = new Dimension(10, 5);
    static Dimension imageButtonSize = new Dimension( 20, 20 );
    static float zoominFactor = 1.25f;
    static float zoomoutFactor = 0.75f;
	
   
    Animation animation;

    /** a handle to the simulated network */
    SensorGrid gOverlay;

    float advance_time ;
    boolean animationRunning; //indicate if the packet-simulation is running

    //applet mode or application mode
    public boolean isApplet;

    //GUI components
    Frame theApplicationWindow;

    /**the main display window */
    GUI_DisplayWindow dw;

    //menus
    PopupMenu pm_file;
    MenuItem mi_quit;

    //View menu and contained items
    PopupMenu pm_packet_view;
    CheckboxMenuItem cbmi_display_logical_net;
    CheckboxMenuItem cbmi_display_physical_net;
    CheckboxMenuItem cbmi_display_node_labels;
    CheckboxMenuItem cbmi_display_any_messages;
    CheckboxMenuItem cbmi_display_message_labels;
    //** menu items to zoo in and out the display
    MenuItem mi_zoomin;
    MenuItem mi_zoomout;
    MenuItem mi_bestfit;
    MenuItem mi_restore;
    //CheckboxMenuItem cbmi_display_multicast_messages;

    // Buttons which activate the File and View menues
    Button b_filemenu;
    Button b_viewmenu;
    
    // Run control items
    Panel run_palette;
    Button b_stop;
    Button b_step;
    Button b_advance;
    Button b_backward;
    
    TextField tf_advance_time;
    Label l_sec;
    Button b_run;
    Button b_restart;
	Panel edit_palette;
	
    // for warning message at bottom
    Label l_warning_message;


    /**construct function. Not used for the compatibility with Applet
     *
     */
    public GUI()
    {
         // only used in main().
         // real initialization done in init()
    }

    /**whether the packet simulation is running
     *@return   whether the animuation is running
     */
    public boolean animated() { return animationRunning; }


    /**
     * print a short message at the bottom of the GUI interface
     */
    public void printWarning(String s)
    {
        l_warning_message.setText(s);

    }

    /**
     * The initialization function, responsible for setup initial states and
     * components layout. Used both in applet and application.
     */
    public void init()
    {
    	try{
    	
        if( this.theApplicationWindow == null ) isApplet = true;
        else isApplet = false;

        //initialize the componetns states
        setBackground(bkColor);
        gOverlay = new SensorGrid(grid_w,grid_h,event_file, bcast_dist, packet_speed);
        
        
        
        animationRunning = false; 
		pm_file = new PopupMenu("File");
		if(this.isApplet==true){
			
        }else{
		    mi_quit = new MenuItem("Quit");
	        mi_quit.addActionListener(this);
	        pm_file.add(mi_quit);
	        			        
		}
		
		this.add(pm_file);
        // create view menu
        pm_packet_view = new PopupMenu("View");

/*
        mi_zoomin = new MenuItem( "zoomin" );
        pm_packet_view.add(mi_zoomin);
        mi_zoomin.addActionListener(this);

        mi_zoomout = new MenuItem( "zoomout" );
        pm_packet_view.add(mi_zoomout);
        mi_zoomout.addActionListener(this);

        mi_restore = new MenuItem( "restore" );
        pm_packet_view.add(mi_restore);
        mi_restore.addActionListener(this);

        mi_bestfit = new MenuItem( "best fit" );
        pm_packet_view.add(mi_bestfit);
        mi_bestfit.addActionListener(this);

        pm_packet_view.addSeparator();
*/

        //packet-based
        cbmi_display_physical_net = new CheckboxMenuItem("Show Grid", true);
        pm_packet_view.add(cbmi_display_physical_net);
        cbmi_display_physical_net.addItemListener(this);
/*
        cbmi_display_logical_net = new CheckboxMenuItem("Show Logical Net", true);
        pm_packet_view.add(cbmi_display_logical_net);
        cbmi_display_logical_net.addItemListener(this);
*/
/*
        cbmi_display_node_labels = new CheckboxMenuItem("Show Node Labels", true);
        pm_packet_view.add(cbmi_display_node_labels);
        cbmi_display_node_labels.addItemListener(this);
*/

        cbmi_display_any_messages = new CheckboxMenuItem("Show Messages", true);
        pm_packet_view.add(cbmi_display_any_messages);
        cbmi_display_any_messages.addItemListener(this);
/*
        cbmi_display_message_labels = new CheckboxMenuItem("Show Message Labels", true);
        pm_packet_view.add(cbmi_display_message_labels);
        cbmi_display_message_labels.addItemListener(this);
*/
        this.add(pm_packet_view);

        

        // create layout
        setLayout( new BorderLayout() );

        // create upper display options
        // (buttons to active File and View popup menus
        //Panel north_container = new Panel();
        //north_container.setLayout(new GridLayout(1, 2) );

        Panel north_panel = new Panel();
        //north_panel.setLayout(new GridLayout(1, 4, 4, 0));
		north_panel.setLayout(new FlowLayout(FlowLayout.LEFT));
		
        b_filemenu = new Button("File");
        north_panel.add(b_filemenu);
        b_filemenu.addActionListener(this);


        b_viewmenu = new Button("View");
        north_panel.add(b_viewmenu);
        b_viewmenu.addActionListener(this);

        
		add(BorderLayout.NORTH,  north_panel);
        // create lower left controls
        Panel southwest_panel = new Panel();

        // create lower right display options
        // e.g. stop, advance, play
        Panel southeast_panel = new Panel();

        //Image loading is different for applet-based case and application
       


		run_palette = new Panel();
        run_palette.setLayout(new GridLayout(0,1));

        b_run = new Button("Run");
        run_palette.add(b_run);
        b_run.addActionListener(this);

        // initialize speed to real time
        Panel advance_time_panel = new Panel();
        advance_time = (float) SIM_SLEEP/1000;
        tf_advance_time = new TextField(Float.toString((float) 1.0));
        advance_time_panel.add(tf_advance_time);
        tf_advance_time.addActionListener(this);

        l_sec = new Label("Sim. Sec. per Real Sec.");
        advance_time_panel.add(l_sec);
        run_palette.add(advance_time_panel);

        b_stop = new Button("Stop");
        run_palette.add(b_stop);
        b_stop.addActionListener(this);

        b_step = new Button("Go To Next Event");
        run_palette.add(b_step);
        b_step.addActionListener(this);

        b_advance = new Button("Step Forward");
        run_palette.add(b_advance);
        b_advance.addActionListener(this);
        
        b_backward = new Button("Step Backward");
        run_palette.add(b_backward);
        b_backward.addActionListener(this);

            
        b_restart = new Button("Reset");
        run_palette.add(b_restart);
        b_restart.addActionListener(this);

   
        edit_palette = new Panel();
        edit_palette.setLayout(new GridLayout(0,1));

        
		Panel west_panel = new Panel();
        west_panel.setLayout(new BorderLayout());

        west_panel.add(BorderLayout.NORTH, run_palette);
        west_panel.add(BorderLayout.SOUTH, edit_palette);


        add(BorderLayout.WEST, west_panel);

        l_warning_message = new Label("RSADemo Started.");
        l_warning_message.setBackground(new Color(160, 160, 160));
        add(BorderLayout.SOUTH, l_warning_message);

        // create DisplayWindow
        dw = new GUI_DisplayWindow(this);
        add(BorderLayout.CENTER, dw);
        dw.setEditMode( GUI_DisplayWindow.EDIT_NODE );
        // set the edit mode buttons to the right state
        this.repaint();
        dw.repaint();
        
    	}catch(Exception e){
    		lotusDebug.errorln("init failed: "+e.toString());	
    	}
    }

	String event_file;
	int grid_w, grid_h;
	float bcast_dist;
	float packet_speed;
/**
 *  Called when the simulation runs as an application.
 */
    public static void main(String argv[])
    {
		
		if(argv.length<3){
			System.err.println("Usage: java GUI grid_width grid_height eventfile [broadcast_distance] [packet_speed]");	
			System.exit(-1);
		}
		
        GUI gui = new GUI();
        gui.theApplicationWindow = new Frame( "Reliable Service Architecture Demo" );

        gui.theApplicationWindow.add(BorderLayout.CENTER, gui);
        gui.theApplicationWindow.setSize(winSize);
		
		gui.grid_w=Integer.parseInt(argv[0]);
		gui.grid_h=Integer.parseInt(argv[1]);
		
		gui.event_file=argv[2];
		
		if(argv.length>=4){
			try{
				gui.bcast_dist=Float.parseFloat(argv[3]);
			}catch(Exception e){
				gui.bcast_dist=1.0f;	
			}
		}else gui.bcast_dist=1.0f;
		if(argv.length>=5){
			try{
				gui.packet_speed=Float.parseFloat(argv[4]);
			}catch(Exception e){
				gui.packet_speed=3f;	
			}	
		}else gui.packet_speed=3f;	
		
        gui.init();
        gui.start();
       // Toolkit tk = gui.theApplicationWindow.getToolkit();
       // gui.theApplicationWindow.setIconImage( tk.createImage("mng.gif") );

        gui.theApplicationWindow.show();
		
    }


    /** Called when the applet starts running or becomes visible */
    public void start()
    {
		//load("default.txt");
    }


    /**Called when the applet is no longer visible */
    public void stop()
    {
    }

    /** handles buttons, menu items, returns entered in textfield */
    public void actionPerformed(ActionEvent ae)
    {
        // synchronizing to prevent bad interaction from animation thread
        if (ae.getSource() == b_filemenu)
        {
            //if( animationRunning ) return;
            Point p = b_filemenu.getLocation();
            pm_file.show(this, p.x, p.y);
        }
        else if (ae.getSource() == mi_quit){
        	System.exit(0);	
        }
        else if (ae.getSource() == b_viewmenu)
        {
            //if( animationRunning ) return;
            Point p = b_viewmenu.getLocation();
            pm_packet_view.show(this, p.x, p.y);
        }
        else if( ae.getSource() == mi_zoomin ) {
            dw.scaleBy( zoominFactor );
            dw.repaint();
        }else if( ae.getSource() == mi_zoomout ) {
            dw.scaleBy( zoomoutFactor );
            dw.repaint();
        }else if( ae.getSource() == mi_bestfit ) {
            dw.bestfit();
            dw.repaint();
        }else if( ae.getSource() == mi_restore ) {
            dw.restore();
            dw.repaint();
        }else if( ae.getSource() == tf_advance_time ){
            try
            {
                advance_time = (Float.valueOf(tf_advance_time.getText())).floatValue()*SIM_SLEEP/1000;
            }
            catch (NumberFormatException nfe)
            {
                printWarning("incorrect numeric format");
            }
        }
        else if ( ae.getSource() == b_run)
        {
        	float ad_time = 0;
	      	try {
	            ad_time = (Float.valueOf(tf_advance_time.getText())).floatValue();
	        }catch( Exception e){
	            printWarning(" invalid advance time format");
	            return;
	        }
	        if( ad_time <= 0 ){
	            printWarning(" can not go backward" );
	            return;
	        }
	        advance_time=ad_time*SIM_SLEEP/1000;
	
            boolean started = true;
            if( gOverlay.isRunning() == false ) {
                started = gOverlay.start();
            }

            if( false == started ) {
                printWarning("simulation can not be started");
                return;
            }
            printWarning("start the simulation");
            animationRunning = true;
            animation = new Animation();
            animation.start();
            
        }else if ( ae.getSource() == b_restart)
        {
        	synchronized(gOverlay){
            
        		gOverlay.reset();
		    	dw.repaint();
		    }
		    
        }else if ( ae.getSource() == b_step )
        {
        	if(animationRunning){
        		printWarning("Demo is running");	
        	}else{
            	gOverlay.step();
				dw.repaint();
            }
        }
        else if( ae.getSource() == b_advance )
        {
           	if(animationRunning){
        		printWarning("Demo is running");	
        	}else{
            	float ad_time = 0;
	            try {
	                ad_time = (Float.valueOf(tf_advance_time.getText())).floatValue();
	            }catch( Exception e){
	                printWarning(" invalid advance time format");
	                return;
	            }
	            if( ad_time <= 0 ){
	                printWarning(" can not go backward" );
	                return;
	            }
	
	            gOverlay.advance(ad_time*SIM_SLEEP/1000);
	            dw.repaint();
	        }
        }else if( ae.getSource() == b_backward )
        {
           	if(animationRunning){
        		printWarning("Demo is running");	
        	}else{
            	float ad_time = 0;
	            try {
	                ad_time = (Float.valueOf(tf_advance_time.getText())).floatValue();
	            }catch( Exception e){
	                printWarning(" invalid advance time format");
	                return;
	            }
	            if( ad_time <= 0 ){
	                printWarning(" can not go backward" );
	                return;
	            }
	
	            gOverlay.advance(-ad_time*SIM_SLEEP/1000);
	            dw.repaint();
	        }
        }else if( ae.getSource() == b_stop )
        {
            printWarning("Simulation stops");
            if( animation != null )  { animation.stopAnimation(); }
            //if( gOverlay.isRunning() ) gOverlay.reset();

            animationRunning = false;
            dw.repaint();
        }

    }


/**
 * hanle the events from checked menu items
 */
public void itemStateChanged(ItemEvent ie){

    if ( ie.getSource() == cbmi_display_logical_net  )
		dw.setDisplayLogical(cbmi_display_logical_net.getState());
    else if ( ie.getSource() == cbmi_display_physical_net  )
		dw.setDisplayPhysical(cbmi_display_physical_net.getState());
    else if ( ie.getSource() == cbmi_display_node_labels  )
		dw.setDisplayNodeLabels(cbmi_display_node_labels.getState());
    else if ( ie.getSource() == cbmi_display_any_messages  )
		dw.setDisplayMessages(cbmi_display_any_messages.getState());
    else if ( ie.getSource() == cbmi_display_message_labels  )
		dw.setDisplayMessageLabels(cbmi_display_message_labels.getState());
	

	
}
   
OverlayNetwork getOverlay() { return gOverlay;}

    class Animation extends Thread {
        boolean exit;
        Animation() { super(); exit=false; }
        public void run(){
        	long this_time=0;
        	long start_time=System.currentTimeMillis();;
        	int i=0;
            while( !exit) {
            	/*
            	if(!gOverlay.hasMoreEvents()){
            		exit=true;
            		break;	
            	}*/
            	synchronized( gOverlay ) {
                    gOverlay.advance( advance_time );
                }
				i++;
                dw.repaint();
                
                this_time=System.currentTimeMillis();
                int sleep_time=SIM_SLEEP-(int)(this_time-start_time-i*SIM_SLEEP);
				if(sleep_time<0)sleep_time=0;
				try{
                    Thread.sleep(sleep_time);
                }catch( Exception e) {}
            }
        }

        void stopAnimation( ) { exit = true; }
    }


}

