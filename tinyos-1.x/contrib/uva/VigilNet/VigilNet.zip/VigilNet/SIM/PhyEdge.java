/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

/**
 * This class implements an edge in the physical network. It is mainly
 * used by the topology adaptors to store the topology description information.
 */
class PhyEdge{

    /** the index of the source node */
    int srcNode;
    /** the index of the destination node */
    int dstNode;
    /** the length of the node */
    float distance;

    PhyEdge( int src, int dst, float dist){
    srcNode = src;
    dstNode = dst;
    distance = dist;
    }

    int GetSrc() { return srcNode;}
    int GetDst() { return dstNode;}
    float GetDistance() {return distance;}
}
