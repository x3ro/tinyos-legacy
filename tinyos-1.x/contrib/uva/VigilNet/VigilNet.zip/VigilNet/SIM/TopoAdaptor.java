/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/
import java.io.*;
import java.util.*;
import java.lang.*;

/**
 * An abstract that abstracts the shared elements of all topology descriptions.
 */
abstract class TopoAdaptor{

    /** file name suffix: home-made format */
    static String suffix_HM = ".hm";
    /** file name suffix: GT_ITM */
    static String suffic_GT = ".alt";
    /** file name suffix: landmark */
    static String suffic_LM = ".lm";
    /** file name suffix: INET */
    static String suffic_IT = ".it";

    /** physical node array */
    PhyNode[] nodes;
    /** physical edge array */
    PhyEdge[] edges;
    //Vector activeNodes;

    PhyNode[] getNodes( ){ return nodes;}
    PhyEdge[] getEdges( ){ return edges;}
    //Vector getActiveNodes() { return activeNodes;}

    TopoAdaptor(){ //activeNodes = new Vector();
    }

    /**
     * Abstract function, implenented by each topology adaptor to
     * load its topology description file.
     * @param filename the description file to be loaded
     * @return true if loading is successful, false otherwise
     */
    abstract boolean loadFile( String filename );

    /**
     * Save the file to the default description format( home-made )
     * This function can be overiden by subclasses to save a topology
     * description to a specific format.
     * @param filename the file to save the topology description
     * @return true if the file is saved successfully, false otherwise
     */
    boolean saveFile( String filename ){
    //lotusDebut.println("in save to File");
    //lotusDebut.println("filename" + filename);

        try {
            FileWriter output = new FileWriter(filename);
            BufferedWriter bw_output = new BufferedWriter(output);
            PrintWriter pw_output = new PrintWriter(bw_output);

            saveToStream( pw_output  );

        //lotusDebut.println("before close");
            pw_output.close();  // I assume this closes output and bw_output
        //lotusDebut.println("after close");

        }
        catch (Exception e){
            lotusDebug.println("error when writing the file");
            return false;
        }
        return true;
    }

    private void saveToStream( PrintWriter pw )
    {
    //lotusDebut.println("in save to stream");
        pw.println("#Lotus save file");

    //lotusDebut.println("print the title");


        // Write out all the nodes.
    pw.print( nodes.length );
    pw.print( " " );
    if( null == edges ) pw.print( 0 );
    else pw.print( edges.length );
    pw.println();

    int index = 0;


        while (index < nodes.length)
        {

        PhyNode p = nodes[index];
        pw.print(p.GetX());
            pw.print(" ");
            pw.print(p.GetY());
            /*if (activeNodes.contains(p))
                pw.print(" Y ");
            else
                pw.print(" N ");*/
            pw.println();
            index++;

        //lotusDebut.println("save node" + p.x + ":" + p.y );
        }

        // Write out all the connections
        index = 0;
        if( null == edges ) return;
        while (index < edges.length)
        {
        PhyEdge p = edges[index];
        pw.print(p.srcNode);
            pw.print(" ");
            pw.print(p.dstNode);
        pw.print(" ");
        pw.print(p.distance);
            pw.println();

        index++;

        //lotusDebut.println("Save edges" + p.srcNode + ":" + p.dstNode );
        }

    //lotusDebut.println("end of save");

    }



}

