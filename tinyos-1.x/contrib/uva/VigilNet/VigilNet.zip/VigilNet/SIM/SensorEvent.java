

class SensorEvent extends SimEvent{
	
	static final int SSEVENT_NULL=3;
	static final int SSEVENT_UPDATE=4;
	static final int SSEVENT_SENDMSG=5;
	static final int SSEVENT_REPORT=6;
	static final int SSEVENT_TARGET_1=7;
	static final int SSEVENT_TARGET_2=8;
        static final int SSEVENT_TRACK_1=9;
	static final int SSEVENT_TRACK_2=10;

	int sensorID;
	String event_info;
	float event_info_x;
	float event_info_y;

	SensorEvent(String line, SensorNetwork sn){
		super(0,null,null,3);
		//get the event from a line of the event_file
		parseEvent(line, sn);
	}
	
	void parseEvent(String line, SensorNetwork sn){
		//line="id:time:event_type:event_info"
		String event_strs[]=new String[6];
		
		for(int i=0;i<event_strs.length;i++){
			line=line.trim();
			if(line.length()>0){
				int index=line.indexOf(':');
				if(index>=0){
					event_strs[i]=line.substring(0,index).trim();
					line=line.substring(index+1);
					
					//lotusDebug.errorln(event_strs[i]+","+line);
					
				}else{
					event_strs[i]=line;
					line="";
				}
			}else event_strs[i]="";	
		}
		
		if(!event_strs[1].equals("RSEVENT")){
			sensorID=0;
			event_type=SSEVENT_NULL;
		}
			
		
		try{
			sensorID=Integer.parseInt(event_strs[0]);
			OverlayNode onode=sn.findNode(sensorID);
			
			sender=onode;
			recipient=onode;
			
			time=Float.parseFloat(event_strs[2]);
			
			if(event_strs[3].equals("UPDATE"))
				event_type=SSEVENT_UPDATE;
			else if(event_strs[3].equals("SENDMSG"))
				event_type=SSEVENT_SENDMSG;
			else if(event_strs[3].equals("REPORT"))
				event_type=SSEVENT_REPORT;
			else if(event_strs[3].equals("TARGET1"))
			{
				event_type=SSEVENT_TARGET_1;
				event_info_x=Float.parseFloat(event_strs[4]);
				event_info_y=Float.parseFloat(event_strs[5]);
			}
			else if(event_strs[3].equals("TARGET2"))
			{
				event_type=SSEVENT_TARGET_2;
				event_info_x=Float.parseFloat(event_strs[4]);
				event_info_y=Float.parseFloat(event_strs[5]);
			}
			else if(event_strs[3].equals("TRACK1"))
			{
				event_type=SSEVENT_TRACK_1;
				event_info_x=Float.parseFloat(event_strs[4]);
				event_info_y=Float.parseFloat(event_strs[5]);
			}
			else if(event_strs[3].equals("TRACK2"))
			{
				event_type=SSEVENT_TRACK_2;
				event_info_x=Float.parseFloat(event_strs[4]);
				event_info_y=Float.parseFloat(event_strs[5]);
			}
			else event_type=SSEVENT_NULL;
			
			event_info=event_strs[4];
			
		}catch(Exception e){
			/*
			lotusDebug.errorln("invalid event:"+line);
			for(int i=0;i<event_strs.length;i++)
				System.err.print(event_strs[i]+"-");
			System.err.println("");
			*/
			//lotusDebug.errorln(e.toString());
			sensorID=0;
			event_type=SSEVENT_NULL;	
		}
	}
	
	public String toString(){
		return sensorID+":"+time+":"+event_type+":"+event_info;	
	}
	
}