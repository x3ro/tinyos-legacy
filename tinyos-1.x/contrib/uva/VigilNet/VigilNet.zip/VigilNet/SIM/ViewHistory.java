import java.util.*;

/**
	This class store the history of view changes
*/

public class ViewHistory{
	Vector history;
	int hIndex;
	
	public ViewHistory(){
		history=new Vector();
		hIndex=-1;
	}
	public void addView(View v){
		
		if(history.size()>0 && getView(hIndex).equals(v)){
			return;
		}
		
		while(history.size()>(hIndex+1))history.remove(hIndex+1);
		history.add(v);
		
		hIndex=history.size()-1;
	}
	public View getView(int index){
		if(index<0 || index>=history.size())return null;
		else return (View)history.get(index);	
	}
	public View back(){
		if(isFirst()){
			//can't go back
			return null;
		}else{
			hIndex--;
			return getView(hIndex);
		}
	}
	public View forward(){
		if(isLast()){
			//can't go forward
			return null;
		}else{
			hIndex++;
			return getView(hIndex);
		}	
	}
	public boolean isFirst(){
		return hIndex<=0;
	}
	public boolean isLast(){
		return hIndex>=(history.size()-1);
	}
}