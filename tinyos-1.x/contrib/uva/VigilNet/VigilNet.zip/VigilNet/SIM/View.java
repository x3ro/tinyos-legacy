import java.lang.*;


/**
	The View class decide the way GUI_DisplayWindow displays
	
**/

public class View{
	/** the display scale */
    public float scale; 

    /** view point, used to move the part of display shown */
    public int viewX, viewY;
    
    public int mode; //logical view or geographic view
    
    public boolean autofit;
    
    public final static int VIEW_LOGICAL =0;
    public final static int VIEW_GEOGRAPHIC =1;
    
    public String overlayID;
    
    public View(float sc, int vX, int vY, int md, boolean af, String olid){
    	scale=sc;
    	viewX=vX;
    	viewY=vY;
    	mode=md;
    	autofit=af;
    	overlayID= olid;
    }
    
    public boolean equals(View v){
    	
    	boolean equal1;
    	if(autofit && v.autofit)equal1=(mode==v.mode);
    	else equal1=(scale==v.scale && viewX==v.viewX && viewY==v.viewY &&
    			mode==v.mode && autofit==v.autofit);
    	
    	if(overlayID==null)
	    	return  equal1 && v.overlayID==null;
    	else
    		return  equal1 && overlayID.equals(v.overlayID);
    }
	
}