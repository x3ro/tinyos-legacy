/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

/**
 * This clas implements the timer event by extending SimEvent
 */
class SimEventTimer extends SimEvent
{
    /** the type of timer */
    int index;

    public SimEventTimer(float t, OverlayNode onode, int idx)
    {
        super( t, onode, onode, SimEvent.PROTOCOL_TIMER_EVENT);
        index = idx;
    }


    public int getIndex()
    {
        return index;
    }

}
