interface PhysicalLayer
{
    boolean sendMsg(SimEventMsg msg);
}

