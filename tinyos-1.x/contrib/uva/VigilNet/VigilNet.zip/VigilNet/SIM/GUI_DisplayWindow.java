/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.net.*;
import java.util.*;
import java.io.*;

/**
 * the display window of the GUI.
 */

class GUI_DisplayWindow
    extends Panel
    implements MouseMotionListener, MouseListener, ActionListener {
    // This is a constant used to scale distances in the network.
    // A packet in the network will travel at a distance of PIXELS_PER_SECOND
    // pixels in one simulated second.

    //Edit Mode
    final static int EDIT_ARROW = 0;
    final static int EDIT_NODE = 1;
    final static int EDIT_MOBILE_NODE = 2;
    final static int EDIT_DENODE = 3;
    final static int EDIT_START = 4;
    final static int EDIT_TREE = 5;
    String mobilityMode;
    MouseAdapter current_listener;

      /** the current edit mode of the display window */
    int edit_mode;
    /** the display scale */
    float scale; // node address * scale ==> point on the screen.

    /** view point, used to move the part of display shown */
    int viewX, viewY;

    /** Popup Menu as interface for different protocols */
    PopupMenu pm_edit;

    MenuItem[] mi_protocol;

    //static final float PIXELS_PER_SECOND = (float) 100000;  //  2/3speed of light * 1pix/2km

    /** a reference to class GUI */
    GUI the_gui;

    // These variables determine what will be drawn in the window.
    boolean display_logical;
    boolean display_physical;
    boolean display_node_labels;
    boolean display_messages;
    boolean display_message_labels;
    boolean display_multicast;

    static Font nodeFont = new Font("Helvetica", Font.PLAIN, 10);
	Font   time_font = new Font("Helvetica", Font.BOLD, 14);

    /** record the root of the multicast tree */
    OverlayNode multicastRoot;

    /**
     * Constructor. It initializes display reated setting
     */
    public GUI_DisplayWindow(GUI gui_arg) {

    //set up node modes
    edit_mode = EDIT_NODE;
    scale = 1.0f;
	mobilityMode = "Random Motion";

    pm_edit = new PopupMenu("Edit");

    this.add(pm_edit);

    the_gui = gui_arg;

    display_logical = true;
    display_physical = true;
    display_node_labels = true;
    display_messages = true;
    display_message_labels = true;
    display_multicast = true;

    setBackground(GUI.dwColor);
    addMouseListener(this);
    addMouseMotionListener(this);

    }


    private Image offScreenBuffer;
    private Graphics offGraphics;

    /**
     * Update the display in the window.
     * Use double buffers to avoid the flickering when updating
     */
    public void update(Graphics g)
    {
        if (offScreenBuffer==null ||
            (! (offScreenBuffer.getWidth(this) == this.getSize().width &&
                offScreenBuffer.getHeight(this) == this.getSize().height)))
        {
            offScreenBuffer = this.createImage(getSize().width, getSize().height);
        }

        // We need to use our buffer Image as a Graphics object:
        offGraphics = offScreenBuffer.getGraphics();
        paint(offGraphics);
        // Passes our off-screen buffer to our paint method, which,
        // unsuspecting, paints on it just as it would on the Graphics
        // passed by the browser or applet viewer.
        g.drawImage(offScreenBuffer, 0, 0, this);
        // And now we transfer the info in the buffer onto the
        // graphics context we got from the browser in one smooth motion.

    }

    /**
     * Paint the window and invoke the paint subroutine based on
     * the setting
     */
    public void paint(Graphics g)
    {
    	bestfit();
    	
        Dimension dim = this.getSize();
        g.setColor( GUI.dwColor );
        g.fillRect(0, 0, dim.width, dim.height);

        //if( display_physical ) paint_physical_transmission(g);
        if( display_physical ) paint_physical_edges(g);
        
        if( display_logical ) paint_logical_edges(g);
        paint_nodes(g);
        if( display_node_labels ) paint_nodes_name(g);

        if( display_messages ) paint_messages(g);
        if( display_messages ) paint_message_labels(g);


        g.setColor(Color.black);
        g.drawLine(0, 0, 0, dim.height-1);
        g.drawLine(0, 0, dim.width-1, 0);
        g.drawLine(dim.width-1, 0, dim.width-1, dim.height-1);
        g.drawLine(0, dim.height-1, dim.width-1, dim.height-1);
		// Draw current time
        // Draw the time it went stable
        String[] sarray = new String[1];
		OverlayNetwork psim = the_gui.getOverlay();
        //sarray[0] = psim.getProtocols().;
        sarray[0] = "Time = " + Float.toString(psim.simTime());
        
        //float time_stable = topo.stableSinceTime();
        //if (time_stable > 0.0)
        //    sarray[2] = "Stable at Time = " + Float.toString(time_stable);
        //else
        //    sarray[2] = "Not Stable";
        
        g.setFont(time_font);
        FontMetrics time_font_metrics = g.getFontMetrics();
        drawStringArray(sarray, 4, 4, g, time_font_metrics);
        drawMulticastTree( g );
    }
    
    
    
	private void drawStringArray(String[] sarray, int x, int y, Graphics g, FontMetrics fm) 
    {
        y += fm.getAscent();
        for (int i = 0; i < sarray.length; i++) 
        {
            g.drawString(sarray[i], x, y);
            y += fm.getHeight();
        }
    }
    /**
     * Paint the messages currently in the network
     */
    private void paint_messages(Graphics g) {
        OverlayNetwork psim = the_gui.getOverlay();
        Enumeration enum = psim.getPendingEvent();

        while( enum.hasMoreElements() ){
            SimEvent se = (SimEvent)enum.nextElement();
            
            if( se.eventType() == SimEvent.PROTOCOL_TIMER_EVENT ) continue;
            if( se.eventType() >=SensorEvent.SSEVENT_NULL) continue;
            
            SimEventMsg msg = (SimEventMsg) se;
            
            XYAddress src = msg.getSender().getAddress();
            
            XYAddress dst;
			float fraction;
			Point psrc=scaleToPoint(src);
			
			if(msg.getRecipient()==null){
				SensorMsg ssmsg=(SensorMsg)msg;
				
				fraction = ( ( msg.getTime() - psim.simTime() ) * ((SensorNetwork)psim).packet_speed ) / ssmsg.BCAST_DIST;
				
				float bcastRadius=ssmsg.BCAST_DIST*(1-fraction)*scale;
				
				g.setColor( GUI.packetColor );
				
				g.drawOval( (int)(psrc.x-bcastRadius), (int)(psrc.y-bcastRadius),
            				(int)(bcastRadius*2), (int)(bcastRadius*2));
			}
			else{
				dst= msg.getRecipient().getAddress();
				
					
				fraction = ( ( msg.getTime() - psim.simTime() ) * ((SensorNetwork)psim).packet_speed ) / se.getSender().getDistanceTo(se.getRecipient());
				g.setColor( GUI.packetColor );
				
	            
				
				Point p=new Point(
					(int)((src.getX() * fraction + dst.getX() * (1-fraction)-viewX)*scale),
					(int)((src.getY() * fraction + (float)dst.getY() * (1-fraction)-viewY)*scale));
				
	            g.fillRect( p.x - GUI.packetSRadius/2 , p.y - GUI.packetSRadius/2, GUI.packetSRadius, GUI.packetSRadius );
	            
        	}
            
        }
        return;
    }

    /**
     * Paint message label
     */
    private void paint_message_labels(Graphics g){
        OverlayNetwork psim = the_gui.getOverlay();
        Enumeration enum = psim.getPendingEvent();
        while( enum.hasMoreElements() ){
            SimEvent se = (SimEvent)enum.nextElement();
            if( se.eventType() == SimEvent.PROTOCOL_TIMER_EVENT ) continue;
            if( se.eventType() >=SensorEvent.SSEVENT_NULL) continue;
            
            SimEventMsg msg = (SimEventMsg) se;
            XYAddress src = msg.getSender().getAddress();
             XYAddress dst;
			float fraction;
			if(msg.getRecipient()==null){
				SensorMsg ssmsg=(SensorMsg)msg;
				
				dst = new XYAddress(src.getX()+msg.getSender().phyNode.GetRadius() ,src.getY()+msg.getSender().phyNode.GetRadius());
				//fraction = ( ( msg.getTime() - psim.simTime() ) * ((SensorNetwork)psim).packet_speed ) / se.getSender().phyNode.GetRadius();
				fraction = ( ( msg.getTime() - psim.simTime() ) * ((SensorNetwork)psim).packet_speed ) / ssmsg.BCAST_DIST;
				
				float bcastRadius=ssmsg.BCAST_DIST*(1-fraction);
				//lotusDebug.errorln("fraction="+fraction+" bcastr="+bcastRadius);
				
				Point p=new Point(
					(int)((src.getX() + bcastRadius-viewX)*scale),
					(int)((src.getY() -viewY)*scale));
					
	            g.setColor( Color.black );
	            String info=msg.getMsgLabel(msg.getMsgType());
	            g.drawString( info, p.x-info.length()*10/2, p.y);
	            
			}
			else{
				dst= msg.getRecipient().getAddress();
			    fraction = ( ( msg.getTime() - psim.simTime() ) * ((SensorNetwork)psim).packet_speed ) / se.getSender().getDistanceTo(se.getRecipient());

				Point p=new Point(
					(int)((src.getX() * fraction + dst.getX() * (1-fraction)-viewX)*scale),
					(int)((src.getY() * fraction + (float)dst.getY() * (1-fraction)-viewY)*scale));
					
	            g.setColor( Color.black );
	            g.drawString( msg.getMsgLabel(msg.getMsgType()), p.x, p.y+GUI.packetSRadius+5);
        	}
        }

        return;
    }

    private boolean outsidePanel( Point p ){
        Dimension dim = this.getSize();
        boolean b = p.x < 0 ||
                    p.y < 0 ||
                    p.x > dim.width ||
                    p.y > dim.height;

        return b;
    }

    /**
     * Paint the name of the nodes
     */
    private void paint_nodes_name(Graphics g){
        Dimension dim = this.getSize();
        for( int i=0; i<the_gui.getOverlay().getPhyNodes().size(); i++){
            OverlayNode onode = (OverlayNode ) the_gui.getOverlay().getPhyNodes().elementAt(i);
            //paint each node
            //if( null == onode.getName() ) continue;

            XYAddress addr = onode.getAddress();
            Point p = scaleToPoint( addr );
            if( outsidePanel( p ) ) continue;
            g.setFont(nodeFont);
            g.setColor(Color.black);
            
            SensorNode sn=(SensorNode)onode.getProtocol();
            if(sn!=null){
            	g.drawString( sn.getStateString(), p.x+2, p.y+12);
            	g.drawString( ""+sn.getProcessInfo(), p.x+2, p.y+20);
            }
        }
    }

    /**
     * Paint nodes, including physical and logical part.
     * The display of the logical nodes depends on the configuration
     * of each protocol.
     */
    private void paint_nodes(Graphics g)
    {
    	Enumeration nodes = the_gui.getOverlay().getPhyNodes().elements();
        while (nodes.hasMoreElements())
        {
	        OverlayNode onode = (OverlayNode) nodes.nextElement();
	        Point p = scaleToPoint( onode.getAddress() );
            if( outsidePanel(p) ) continue;
            if( onode.getProtocol() == null ) {
            //only physical node is painted
                g.setColor(OverlayNetwork.phyNodeColor);
                g.fillOval(p.x - GUI.ndDiameter/2,
                   p.y - GUI.ndDiameter/2,
                   GUI.ndDiameter,
                   GUI.ndDiameter);
            }else
            {
                protocolInterface protocol = onode.getProtocol();
	        			
	        			XYAddress addr = protocol.getAddr1();
	        			if ((int)addr.x != -1)
	        			{
									Color c = new Color(0.0f, 0.0f, 1.0f, 0.05f);  
	        				Point q = new Point( (int)( (addr.x - viewX)*scale ),
                          (int)( (addr.y - viewY)*scale ) );
      				g.setColor(Color.black);
                  g.draw3DRect(q.x - (int)(GUI.ndDiameter*0.8),
                        q.y - (int)(GUI.ndDiameter*0.8),
                        (int)(GUI.ndDiameter*1.6),
                        (int)(GUI.ndDiameter*1.6),
                        true);
		g.setColor(Color.blue);
                  g.fill3DRect(q.x - (int)(GUI.ndDiameter*0.8),
                        q.y - (int)(GUI.ndDiameter*0.8),
                        (int)(GUI.ndDiameter*1.6),
                        (int)(GUI.ndDiameter*1.6),
                        true);
	        				g.setColor(c);
                  g.fillOval(q.x - (int)(GUI.ndDiameter*12),
                        q.y - (int)(GUI.ndDiameter*12),
                        (int)(GUI.ndDiameter*24),
                        (int)(GUI.ndDiameter*24));
	        			}
	        			addr = protocol.getAddr2();
	        			if ((int)addr.x != -1)
	        			{
									Color c = new Color(1.0f, 0.0f, 0.0f, 0.05f);  
	        				Point q = new Point( (int)( (addr.x - viewX)*scale ),
                          (int)( (addr.y - viewY)*scale ) );
      				g.setColor(Color.black);
                  g.draw3DRect(q.x - (int)(GUI.ndDiameter*0.8),
                        q.y - (int)(GUI.ndDiameter*0.8),
                        (int)(GUI.ndDiameter*1.6),
                        (int)(GUI.ndDiameter*1.6),
                        true);
		g.setColor(Color.red);
                  g.fill3DRect(q.x - (int)(GUI.ndDiameter*0.8),
                        q.y - (int)(GUI.ndDiameter*0.8),
                        (int)(GUI.ndDiameter*1.6),
                        (int)(GUI.ndDiameter*1.6),
                        true);
	        				g.setColor(c);
                  g.fillOval(q.x - (int)(GUI.ndDiameter*12),
                        q.y - (int)(GUI.ndDiameter*12),
                        (int)(GUI.ndDiameter*24),
                        (int)(GUI.ndDiameter*24));
	        			}

		XYAddress[] addrs = protocol.getTrack1();
		int i;
		g.setColor(Color.red);
		i = 0;
		if (addrs[i].getFloatX() != -1) {
  		  Point q1 = null;
  		  Point p1 = new Point( (int)( (addrs[i].x - viewX)*scale ), (int)( (addrs[i].y - viewY)*scale ) );
		  while (addrs[i+1].getFloatX() != -1) {
//		for(i = 0; i < protocol.getSize1(); i ++) {		
		    q1 = new Point( (int)( (addrs[i+1].x - viewX)*scale ), (int)( (addrs[i].y - viewY)*scale ) );
                    g.drawLine(p1.x, p1.y, q1.x, q1.y);						
		    p1 = q1;
		    i ++;
		  }
		}
	        			
		XYAddress[] addrs2 = protocol.getTrack2();
		g.setColor(Color.blue);
		i = 0;
		if (addrs2[i].getFloatX() != -1) {
		  Point q2 = null;
  		  Point p2 = new Point( (int)( (addrs2[i].x - viewX)*scale ), (int)( (addrs2[i].y - viewY)*scale ) );
		  while (addrs2[i+1].getFloatX() != -1) {
		    q2 = new Point( (int)( (addrs2[i+1].x - viewX)*scale ), (int)( (addrs2[i].y - viewY)*scale ) );
                    g.drawLine(p2.x, p2.y, q2.x, q2.y);						
		    p2 = q2;
		    i ++;
		  }
		}

                g.setColor( protocol.getColor() );
                if( protocol.getShape() == protocolInterface.shapeCircle )
                    g.fillOval(p.x - (int)(GUI.ndDiameter*0.8),
                        p.y - (int)(GUI.ndDiameter*0.8),
                        (int)(GUI.ndDiameter*1.6),
                        (int)(GUI.ndDiameter*1.6));
                else if( protocol.getShape() == protocolInterface.shapeSquare )
                    g.fillRect(p.x - (int)(GUI.ndDiameter*0.8),
                        p.y - (int)(GUI.ndDiameter*0.8),
                        (int)(GUI.ndDiameter*1.6),
                        (int)(GUI.ndDiameter*1.6));
                else if( protocol.getShape() == protocolInterface.shapeTriangle ){
                    int []xline = new int[3];
                    int []yline = new int[3];
                    xline[0] = p.x;
                    xline[1] = p.x - (int)(GUI.ndDiameter*0.86);
                    xline[2] = p.x + (int)(GUI.ndDiameter*0.86);
                    yline[0] = p.y - GUI.ndDiameter;
                    yline[1] = p.y + GUI.ndDiameter/2;
                    yline[2] = p.y + GUI.ndDiameter/2;
                    g.fillPolygon( xline, yline, 3 );
                }
                if(onode.phyNode.isMobile()){
					g.setColor(Color.green);
				}
                else g.setColor(OverlayNetwork.phyNodeColor);
                g.fillOval(p.x - GUI.ndDiameter/2,
                   p.y - GUI.ndDiameter/2,
                   GUI.ndDiameter,
                   GUI.ndDiameter);
            }
        }
    }

    /**
     * Paint the logical edges
     */
    private void paint_logical_edges(Graphics g)
    {
        Color edge_color;

        Enumeration nodes = the_gui.getOverlay().getPhyNodes().elements();

        while (nodes.hasMoreElements())
        {
	        OverlayNode fromnode = (OverlayNode) nodes.nextElement();

            Enumeration other_ends = fromnode.getLogicalNeighbor();
            Enumeration other_colors = fromnode.getLogicalColor();
            Enumeration other_widths = fromnode.getLogicalWidth();

            while(other_ends.hasMoreElements())
            {
                OverlayNode tonode = (OverlayNode) other_ends.nextElement();

		        Point  p1 = scaleToPoint( fromnode.getAddress() );
        		Point  p2 = scaleToPoint( tonode.getAddress() );
                if( outsidePanel(p1) && outsidePanel(p2) ) continue;
                Point  pm = new Point( (int) ((p1.x+p2.x)/2), (int) ((p1.y+p2.y)/2) );
		        g.setColor((Color)other_colors.nextElement());
                int xinterval = ( p1.x - pm.x > 0 ) ? (p1.x-pm.x) : (pm.x-p1.x);
                int yinterval = ( p1.y - pm.y > 0 ) ? (p1.y-pm.y) : (pm.y-p1.y);
                int width = ((Integer)other_widths.nextElement()).intValue();

                if( xinterval > yinterval ){
                    for( int i=0; i<width; i++) g.drawLine( p1.x, p1.y-width/2+i, pm.x, pm.y-width/2+i);
                }else{
                    for( int i=0; i<width; i++) g.drawLine( p1.x-width/2+i, p1.y, pm.x-width/2+i, pm.y);
                }
            }
        }
    }

    /**
     * Paint the physical edges
     */
     
    private void paint_physical_edges(Graphics g)
    {
        final Color edge_color = OverlayNetwork.phyEdgeColor;

        Enumeration nodes = the_gui.getOverlay().getPhyNodes().elements();

        while (nodes.hasMoreElements())
        {
	    OverlayNode fromnode = (OverlayNode) nodes.nextElement();

            Enumeration other_ends = fromnode.getPhyNeighbor();
            if (other_ends == null)
                continue;

            while(other_ends.hasMoreElements())
            {
                OverlayNode tonode = (OverlayNode) other_ends.nextElement();

                Point  p1 = scaleToPoint( fromnode.getAddress() );
                Point  p2 = scaleToPoint( tonode.getAddress() );
                if( outsidePanel(p1) && outsidePanel(p2) ) continue;
                g.setColor(edge_color);
                g.drawLine( p1.x, p1.y, p2.x, p2.y );

            }
        }
    }
 
    
    private void paint_physical_transmission(Graphics g)
    {
        OverlayNetwork psim = the_gui.getOverlay();
        Enumeration enum = psim.getPendingEvent();

        while( enum.hasMoreElements() ){
            SimEvent se = (SimEvent)enum.nextElement();
            if( se.eventType() == SimEvent.PROTOCOL_TIMER_EVENT ) continue;
            SimEventMsg msg = (SimEventMsg) se;
            XYAddress src = msg.getSender().getAddress();
            Point p = scaleToPoint( src );
            g.setColor( Color.red );
			int r = (int)(msg.getSender().phyNode.GetRadiusF()/scale);
            g.drawOval( p.x-r, p.y-r,2*r,2*r );
        }
        return;
    }

	
    /**
     * set the display of logical edge
     */
    public final void setDisplayLogical(boolean b)
    {
        display_logical = b;
        repaint();
    }


    /**
     * set the display of physical edge
     */
    public final void setDisplayPhysical(boolean b)
    {
        display_physical = b;
        repaint();
    }

    /**
     * set the display of message
     */
    public final void setDisplayMessages(boolean b)
    {
        display_messages = b;
        repaint();
    }

    /**
     * set the display of message labels
     */
    public final void setDisplayMessageLabels(boolean b)
    {
        display_message_labels = b;
        repaint();
    }

    /**
     * set the display of node labels
     */
    public final void setDisplayNodeLabels(boolean b)
    {
        display_node_labels = b;
        repaint();
    }

    /**
     * set whether a multicast tree is displayed
     */
    public final void setDisplayMulticast(boolean b)
    {
        display_multicast = b;
        repaint();
    }

    /**
     * draw the multicast tree rooted at multicastRoot
     */
    private void drawMulticastTree( Graphics g ){
        OverlayNode root = this.multicastRoot;
        OverlayNetwork net = the_gui.getOverlay();
        if( net.active_nodes.contains(root) == false ) return ;

        Color edge_color = Color.blue;
        //Graphics g = this.getGraphics();

        OverlayNode [] nodequeue = new OverlayNode[net.active_nodes.size()];
        int tail = 0, head = 1;
        nodequeue[0] = root;

        while( tail != head ){
            OverlayNode parent = nodequeue[tail++];
            Enumeration e = parent.getLogicalNeighbor();
            while( e.hasMoreElements() ){
                OverlayNode child = (OverlayNode)e.nextElement();
                if( net.getLogicalNextHop(child, root) == parent ) {
                    nodequeue[head++] = child;
                    Point  p1 = scaleToPoint( parent.getAddress() );
                    Point  p2 = scaleToPoint( child.getAddress() );
                    if( outsidePanel(p1) && outsidePanel(p2) ) continue;
                    g.setColor(edge_color);
                    int xinterval = ( p1.x - p2.x > 0 ) ? (p1.x-p2.x) : (p2.x-p1.x);
                    int yinterval = ( p1.y - p2.y > 0 ) ? (p1.y-p2.y) : (p2.y-p1.y);
                    int width = 3;
                    if( xinterval > yinterval ){
                        for( int i=0; i<width; i++) g.drawLine( p1.x, p1.y-width/2+i, p2.x, p2.y-width/2+i);
                    }else{
                        for( int i=0; i<width; i++) g.drawLine( p1.x-width/2+i, p1.y, p2.x-width/2+i, p2.y);
                    }
                }
            }
        }
    }

    private OverlayNode selectedNode;

    /**
     * process the selection event of the popup menu items
     */
    public void actionPerformed(ActionEvent ae){

     
    }



  
    Point arrowStart;
    OverlayNode lineStart;
    Point linePrev;

    /**
     * Handle of mouse pressed event
     * Left button:
     * arrow mode, record the coordinates to move
     * node mode, add a node
     * line mode, see if it is a possible starting point
     * denode mode, see if a node is selected
     * deline mode, see if a line is selected
     * Right button:
     * popup the menu
     */
    public void mousePressed(MouseEvent me) {
        /* do not respond while in simulation mode */
        //if( the_gui.animated() ) return;
    	OverlayNode test = the_gui.getOverlay().findClosest(
							    scaleToNode(me.getPoint()),
							    (int)(GUI.ndDiameter/scale) );
		
		

    	if( test != null ){
    		SensorNode sn=(SensorNode)test.getProtocol();
    		if(sn!=null)
    			the_gui.printWarning(sn.getDetails());
    		else 
    			the_gui.printWarning( test.getAddress().getX() +
						 "," +
						 test.getAddress().getY());
		}
		
        int mods = me.getModifiers();
        
    }

    /**
     * Process mouse drag event. Currently, only two edit modes
     * utilize mouse drag, arrow and line modes
     */
    public void mouseDragged(MouseEvent me) {
        //if( the_gui.animated() ) return;
        int mods = me.getModifiers();
	    if ((mods & MouseEvent.BUTTON1_MASK) == 0 ) return; //not left button

        if( edit_mode == EDIT_ARROW ) {
            Point p = me.getPoint();
            this.setView( (int)(viewX - (p.x-arrowStart.x)/scale),
                          (int)(viewY - (p.y-arrowStart.y)/scale) );
            arrowStart = p;
            //XYAddress addr = scaleToNode( new Point( p.x - arrowStart.x, p.y - arrowStart.y ) );
            //this.setView( viewX - addr.getX(), viewY - addr.getY());
            repaint();
        }
       
    }


    public void mouseReleased(MouseEvent me) {
        //if( the_gui.animated() ) return;
	    int mods = me.getModifiers();

        Point p = me.getPoint();
    	OverlayNode test = the_gui.getOverlay().findClosest(
							    scaleToNode(p),
							    (int)(GUI.ndDiameter/scale) );

	   
    }


    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }

    public void mouseClicked(MouseEvent e) {

    }

    public void mouseMoved(MouseEvent e) {
    }

    void reset(){
        restore();
    }
	
	void setMobileMode(String mode){
		mobilityMode = mode;
	}
    /** @return the current edit mode */
    int getEditMode()  { return edit_mode; }
    /** set the edit mode */
    void setEditMode( int mode ) {
        switch (mode){
        case GUI_DisplayWindow.EDIT_ARROW:
            this.setCursor(new Cursor(Cursor.HAND_CURSOR) );
            break;
        case GUI_DisplayWindow.EDIT_NODE:
			break;
		case GUI_DisplayWindow.EDIT_MOBILE_NODE:
			break;
        case GUI_DisplayWindow.EDIT_DENODE:
           // this.setCursor( new Cursor(Cursor.CROSSHAIR_CURSOR ) );
            break;
		case GUI_DisplayWindow.EDIT_START:
           // this.setCursor( new Cursor(Cursor.CROSSHAIR_CURSOR ) );
            break;
        case GUI_DisplayWindow.EDIT_TREE:
            this.setCursor( new Cursor( Cursor.DEFAULT_CURSOR) );
            break;
        default:
            return;
        }
        edit_mode = mode;
        if( mode != EDIT_TREE ) multicastRoot = null;
    }

    /**
     * change of the view  point and scale
     */
    public void scaleBy( float factor ) {
        scale *= factor;
        the_gui.printWarning("scale:"+scale);
    }

    /**
     * restore the scale to the default value
     */
    public void restore( ) {
        scale = 1.0f;
        viewX = 0;
        viewY = 0;
        the_gui.printWarning("scale:"+scale + "; viewX:" + viewX + "; viewY:" + viewY);
    }

    /**
     * fit the display to the window
     */
    void setScale(float sc){
    	scale=sc;
    }
    void bestfit( ) {
    //scale the topology to fit into the display
        if( the_gui.getOverlay().getPhyNodes().size() <= 1 ) return;
        
        Enumeration nodes = the_gui.getOverlay().getPhyNodes().elements();

        int fxmax = Integer.MIN_VALUE;
        int fymax = Integer.MIN_VALUE;
        int fxmin = Integer.MAX_VALUE;
        int fymin = Integer.MAX_VALUE;

        while( nodes.hasMoreElements() ) {
            OverlayNode onode = (OverlayNode) nodes.nextElement();
            
            XYAddress addr = onode.getAddress();
            
            if( addr.getX() > fxmax ) fxmax = addr.getX();
            if( addr.getY() > fymax ) fymax = addr.getY();
            if( addr.getX() < fxmin ) fxmin = addr.getX();
            if( addr.getY() < fymin ) fymin = addr.getY();
        }

        Dimension dim = this.getSize();
        double dimy = dim.getHeight();
        double dimx = dim.getWidth();

        
        double scaleX = dimx/(fxmax - fxmin+2);
        double scaleY = dimy/(fymax - fymin+2);
        if( scaleX > scaleY ) setScale((float)scaleY);
        else setScale((float)scaleX);
        
        //adjust
        fxmin=fxmin-(int)((double)10/scale);
        fymin=fymin-(int)((double)10/scale);
        fxmax=fxmax+(int)((double)10/scale);
        fymax=fymax+(int)((double)10/scale);
        scaleX = dimx/(fxmax - fxmin+2);
        scaleY = dimy/(fymax - fymin+2);
        if( scaleX > scaleY ) setScale((float)scaleY);
        else setScale((float)scaleX);
        
        viewX = fxmin - 1;
        viewY = fymin - 1;
        
        
    }

    void setView( int x, int y ){
        viewX = x; viewY = y;
    }

    Point scaleToPoint( XYAddress addr ) {
        return new Point( (int)( (addr.getX() - viewX)*scale ),
                          (int)( (addr.getY() - viewY)*scale ) );
    }

    XYAddress scaleToNode( Point p ) {
        return new XYAddress( (int) ( p.x/scale + viewX ),
                              (int) ( p.y/scale + viewY ) );
    }
	
    
    
} // End of GUI_DisplayWindow class
	


