/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

import java.awt.*;

/**
 * the two dimensional logical coorinates used for Delaunay Triangulation
 */

class DTAddress {
    float x;
    float y;

    DTAddress( float tx, float ty){
    x = tx;
    y = ty;
    }
    public DTAddress(String LAs){
        //create the address from a string in the form of "x,y"
        int sep=LAs.indexOf(",");
        x = Integer.parseInt(LAs.substring(0, sep));
        y = Integer.parseInt(LAs.substring(sep+1));
    }

    float getX(){ return x;}
    float getY(){ return y;}
    void setX(float sx){ x = sx;}
    void setY(float sy){ y = sy;}

    /**
     * the distance between this node and the other node
     * @param node  the other node
     */
    float distance( DTAddress node ){
        float dx = node.getX() - x;
        float dy = node.getY() - y;
        return (float)(Math.sqrt( dx*dx + dy*dy) );
    }
    public final String toString()
    {
        StringBuffer s = new StringBuffer();
        s.append(x);
        s.append(",");
        s.append(y);
        return s.toString();
    }

}
