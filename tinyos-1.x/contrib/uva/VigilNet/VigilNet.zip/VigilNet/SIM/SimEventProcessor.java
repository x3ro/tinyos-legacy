/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

import java.util.*;

/**
 * The discrite-time simulator
 */
class SimEventProcessor
{
    /** current simulation time */
    float sim_time;
    /** the queue containing the simulation event */
    Vector the_queue;

    public SimEventProcessor()
    {
        sim_time = 0.0f;
        the_queue = new Vector();
    }

    /** @return those pending events */
    public Enumeration getPendingEvents() {
        return the_queue.elements();
    }


    /** insert an event into the simulator */
    public void insertEvent( SimEvent se)
    {	
    	
        if (se.getTime() < sim_time)
        {
            lotusDebug.error("ERROR: Event inserted for time " + se.getTime() );
            //lotusDebug.error(se.getTime());
            lotusDebug.error(" when clock was at " + sim_time );
            //lotusDebug.error(sim_time);
            lotusDebug.errorln(": Event Ignored.");
            return;
        }
		
        int i;
        for( i=0; i<the_queue.size(); i++){
            SimEvent event = (SimEvent) the_queue.elementAt(i);
            if( event.getTime() > se.getTime() ) break;
        }
        if( i == the_queue.size() ) the_queue.addElement(se);
        else the_queue.add( i, se );
    }

    /** @return true when the event queue is empty */
    public boolean queueIsEmpty()
    {
        if (the_queue.size() == 0 ) return true; else return false;
    }

    /** @return the current simulation time */
    public float getSimTime()
    {
        return sim_time;
    }


    /** @return the next pending event and advance the sim time */
    public SimEvent getNextEvent()
    {
        if( the_queue.size() ==  0 ) return null;
        SimEvent se = (SimEvent) the_queue.elementAt(0);
        the_queue.remove(0);
        sim_time = se.getTime(); //advance the time;
        return se;
    }

    /** @return the next event within the endTime
     *  If the return is null, advance the time to end time
     *  If the return is not-null, advance the time using getNextEvent
     */

    public SimEvent getNextEvent(float endTime ){

        if( the_queue.size() == 0 ) {
            sim_time = endTime;
            return null;
        }
        SimEvent se = (SimEvent) the_queue.elementAt(0);
        if( se.getTime() > endTime ) { sim_time = endTime; return null; }
        return getNextEvent();
    }

    /** reset the discrete-time simulator */
    public void reset()throws Exception{
        the_queue.clear();
        sim_time = .0f;
    }

}
