class MobiReflectiveLinear implements MobilityInterface
{
    private boolean MobilityEnabled;
    private float minX;
    private float maxX;
    private float minY;
    private float maxY;
    private float minZ;
    private float maxZ;
    private float speedX;
    private float speedY;
    private float speedZ;
    private float speed;
    
    MobiReflectiveLinear()
    {
        init();
    }

    MobiReflectiveLinear(float paramSpeed)
    {
        init();
        speed = paramSpeed;
        speedX = (float)(speed*2*(Math.random()-0.5));
        speedY = (float)(speed*2*(Math.random()-0.5));
        speedZ = (float)(speed*2*(Math.random()-0.5));
    }

    void init()
    {
        speed = 2;
        speedX = (float)(speed*2*(Math.random()-0.5));
        speedY = (float)(speed*2*(Math.random()-0.5));
        speedZ = (float)(speed*2*(Math.random()-0.5));
        minX = 0; maxX = 500;
        minY = 0; maxY = 500;
        minZ = 0; maxZ = 500;
        MobilityEnabled = true;
    }

    public void mobilityEnable()
    {
        MobilityEnabled = true;
    }

    public void mobilityDisable()
    {
        MobilityEnabled = false;
    }

    public Position move(float timeDifference, Position prev)
    {
        Position next;
        float x;    float y;    float z;

        if(MobilityEnabled)
        {
            x = prev.getX();
            y = prev.getY();
            z = prev.getZ();
            if(x < minX) x = minX;
            if(x > maxX) x = maxX;
            if(y < minY) y = minY;
            if(y > maxY) y = maxY;
            if(z < minZ) z = minZ;
            if(z > maxZ) z = maxZ;
            x += speedX * timeDifference;
            y += speedY * timeDifference;
            z += speedZ * timeDifference;
            if(x < minX) { x = minX + (minX - x); speedX = -speedX; }
            if(x > maxX) { x = maxX + (maxX - x); speedX = -speedX; }
            if(y < minY) { y = minY + (minY - y); speedY = -speedY; }
            if(y > maxY) { y = maxX + (maxY - y); speedY = -speedY; }
            if(z < minZ) { z = minZ + (minZ - z); speedZ = -speedZ; }
            if(z > maxZ) { z = maxZ + (maxZ - z); speedZ = -speedZ; }
            next = new Position(x,y,z);
        }
        else
        {
            next = new Position(prev);
        }
        return next;
    }
}

