/***************************************************************************/
/*       Lotos, an extensible overlay network simulator                    */
/*       MNG Group                                                         */
/*       University of Virginia                                            */
/*       July, 2002                                                        */
/***************************************************************************/

/**
 * This class implements a physical node. It is mainly used by the topology
 * adaptors to store the topology description  information
 */
class PhyNode {
    final float TRANSMISSION_RADIUS = 100;
    final float DEF_SPEED = 2;

    /** physical address, x */
    float x;
    /** physical address, y */
    float y;
    /** transmission and reception radius */
    float r;
    /**Mobile node moving velocity*/
    float speed;
    /**Mobility determinator for this node*/
    MobilityInterface mobility;

    PhyNode(int xc, int yc)
    {
        init();
        x=xc; y=yc;
    }

    PhyNode( float xc, float yc )
    {
        init();
        x = xc;
        y = yc;
    }

    PhyNode( int xc, int yc, int radius)
    {
        init();
        x=xc; y=yc; r=radius;
    }

    PhyNode( float xc, float yc, float radius )
    {
        init();
        x = xc;
        y = yc;
        r = radius;
    }

    void setSpeed(float paramSpeed)
    {
        speed = paramSpeed;
    }
    
    void init()
    {
        r=TRANSMISSION_RADIUS;
        speed=DEF_SPEED;
        mobility = null;
    }
    
    void initMobility(String mobilityMode)
    {

        if(mobilityMode=="Random Motion")
            mobility = new MobiRandomStep(speed);
        else if (mobilityMode=="Linear Motion")
            mobility = new MobiReflectiveLinear(speed);
        else{
            mobility = null;
        }
    }

    boolean isMobile() { return (mobility != null); }
    int GetX() { return (int)x;}
    int GetY() { return (int)y;}

    float GetXF() { return (x);}
    float GetYF() { return (y);}
    void SetXF( float xf ) { x = xf; }
    void SetYF( float yf ) { y = yf; }

    int GetRadius() { return (int)r;}
    float GetRadiusF() { return r;}
    void SetRadiusF( float radius ) { r = radius; }    
    
    boolean isNeighbor(PhyNode otherNode)
    {
        float distance =  distanceTo(otherNode);
        if((distance <= r))
            return true;
        else
            return false;
    }
    
    float distanceTo(PhyNode otherNode)
    {
        return (float)Math.sqrt(Math.pow(otherNode.GetXF()-x,2)+
                        Math.pow(otherNode.GetYF()-y,2)
                        );
    }

    public void move()
    {
        if(mobility != null)
        {
            Position prev = new Position(GetXF(),GetYF(),0);
            Position next = mobility.move(1,prev);
            SetXF(next.getX());
            SetYF(next.getY());
        }
    }
}

