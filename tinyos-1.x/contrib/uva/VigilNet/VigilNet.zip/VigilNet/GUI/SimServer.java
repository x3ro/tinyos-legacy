/**
 * <p>Title: SOWN Mote Field Setup</p>
 * <p>Description: Setup GUI sor SOWN Mote Field
 * called by Xetron Cardinal MissionGUI</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UVa</p>
 * @author Ting Yan, Tian He, etc.
 * @version 1.2
 */

import java.net.*;
import java.io.*;
import java.util.*;

/**
 * Title:   server simulator emulating SerialForwarder
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author  Ting Yan
 * @version 1.0
 */

public class SimServer {
  static BufferedReader fbr = null;
  static OutputStream os = null;
  static String str = null;
  static long startTime = 0;
  static boolean used = false;
  static int tick = 0;
  static Date start = null;

  static long readTime(String str) {
    String subTime = str.substring(0, str.indexOf((int) ' '));
    // System.out.println(Long.parseLong(subTime));
    return Long.parseLong(subTime);
  }

  static String getLine() {
    if (fbr == null) {
      //System.out.println("fbr null");
      return null;
    }
    //System.out.println("fbr not null");
    String str = null;
    try {
      str = fbr.readLine();
    } catch (IOException e) {}
    return str;
  }

  public static void main(String[] args) {
	if (args.length != 1) {
		System.err.println("Usage: java SimServer <logfile>");
		System.exit(1);
	}
    try {
      fbr = new BufferedReader(new FileReader(args[0]));
      str = fbr.readLine();
      //System.out.println(str.length());
      startTime = readTime(str);
      start = new Date();

      int port = 9000;
      ServerSocket srv = new ServerSocket(port);
      Socket socket = srv.accept();
      os = socket.getOutputStream();

      Timer tm = new Timer();
      tm.scheduleAtFixedRate(new TimerTask() {
      private boolean inTick(String str, Date currDate) {
        long packetTime = readTime(str);
        long passedTime = currDate.getTime() - start.getTime();
        if (passedTime > packetTime - startTime + 22000) {
          /*System.out.println(packetTime);
          System.out.println(startTime);
          System.out.println(currDate.getTime());
          System.out.println(start.getTime());
          System.out.println();*/
          return true;
        }
        else
          return false;
      }
      private void sendPacket(String str) {
        //System.out.println(str);
        /* byte[] bArr = new byte[36];
        for (int i = 0; i < 36; i++) {
          String sub = str.substring(i * 3, i * 3 + 2);
          int iVal = Integer.parseInt(sub, 16);
          //System.out.print(iVal);
          iVal = (iVal >= 128) ? (iVal - 256) : iVal;
          bArr[i] = (byte) iVal;
          //System.out.print(bArr[i]);
          //System.out.print(" ");
        }*/
        
        int firstSpace = str.indexOf((int) ' ');
        int byteCnt = (str.length() - firstSpace) / 3;
        int actualSize = 36; // magic number for deprecated net.tinyos.message.MoteIF.defaultPacketSize;
        byte[] bArr = new byte[actualSize];
        
        for (int i = 0; i < byteCnt; i++) {
        	String sub = str.substring(firstSpace + i * 3 + 1, firstSpace + i * 3 + 3);
        	int iVal = Integer.parseInt(sub, 16);
        	iVal = (iVal >= 128)? (iVal - 256) : iVal;
        	bArr[i] = (byte) iVal;
        	// System.out.print(sub + " ");
        }
        
        if (byteCnt < actualSize) 
        	for (int i = byteCnt; i < actualSize; i++)
        		bArr[i] = 0;
        
        bArr[34] = 1;
        bArr[0] = 0x7e;
        
        // System.out.println();

        //System.out.println();
        try {
          os.write(bArr);
          os.flush();
        } catch (IOException e) {
        	// e.printStackTrace();
        }
      }

      public void run() {
        Date currDate = new Date();
        if (used) {
          str = getLine();
          used = false;
          // System.out.println(str.length());
          if (str == null){
            cancel();
            // System.exit(0);
            return;
          }
        }
        while (inTick(str, currDate)) {
          sendPacket(str);
          used = true;
          str = getLine();
          // System.out.println(str.length());
          used = false;
          if (str == null) {
            cancel();
            System.exit(0);
            return;
          }
        }

      tick++;

      }}, 10000, 100);


      while (true) {;}
    } catch (IOException e) {
      e.printStackTrace();
    }
  }


}
