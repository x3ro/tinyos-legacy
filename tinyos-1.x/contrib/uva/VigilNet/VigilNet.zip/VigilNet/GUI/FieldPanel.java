/**
 * <p>Title: SOWN Mote Field Setup</p>
 * <p>Description: Setup GUI sor SOWN Mote Field
 * called by Xetron Cardinal MissionGUI</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UVa</p>
 * @author Ting Yan, Tian He, etc.
 * @version 1.2
 */

import javax.swing.*; //This is the final package name.
//import com.sun.java.swing.*; //Used by JDK 1.2 Beta 4 and all
//Swing releases before Swing 1.1 Beta 3.
import java.util.*;
import java.awt.*;
import java.io.*;


public class FieldPanel
    extends JPanel
    implements Runnable {

    boolean global = true;
    boolean showSpan = false;
    boolean filter = false;
    boolean serialStarted = true;

    Image image = null;

    int xSection = 1;

    // int ySection = 1;
    int south = Integer.MIN_VALUE;
    int west = Integer.MAX_VALUE;

	// for statistics
	int numSentry = 0;
	int numNodes = 0;
	int numTrackings = 0;

    java.util.Timer repaintTimer;

    public int numMovingStreams = 0;

    Vector nodesHolder = new Vector();
    Vector aggregateNodesHolder = new Vector();
    Vector movingStreamsHolder = new Vector();

    public static final long repaintInterval = 1000; // 1000 ms

    public boolean isMoving = false;

    class RepaintTask
        extends TimerTask {
        public void run() {
            if (isMoving) {
                repaint();
            }
        }
    }

    public FieldPanel() {
        repaintTimer = new java.util.Timer();
        repaintTimer.schedule(new RepaintTask(), 0, repaintInterval);
        image = Toolkit.getDefaultToolkit().getImage("compass.png");
    }

    int xMap(int xCoord) {
        double dX = (double) xCoord * 10.0 - (double) west * 10.0;
        // System.out.println("dX: " + dX);
        // if the grid size is 256, divide by 2.56
        // if the grid size is 10, multiple by 10.0
        // dX /= 2.0;
//	dX *= 5.0;
        double dOut = 0.0;
        if (global) {
            dOut = dX * 0.07 + 10.0;
            return (int) dOut;
        }
        else {
            // dOut = (dX - 1000.0 * xSection + 1000.0) * 0.35 + 10.0;
            dOut = dX * 0.07 * xSection + 10.0;
            return (int) dOut;

        }
    }

    int yMap(int yCoord) {
        double dY = - (double) yCoord * 10.0 + (double) south * 10.0;
        //System.out.println("dY: " + dY);
        // if the grid size is 256, divide by 2.56
        // if the grid size is 10, multiple by 10.0
        // dY /= 2.0;
//	dY *= 5.0;
        double dOut = 0.0;
        if (global) {
            dOut = dY * 0.07 + 10.0;
            // dOut = dY * 0.07 + 150.0;
            return (int) dOut;
        }
        else {
            dOut = dY * 0.07 * xSection + 10.0;
            // dOut = (dY - 1000.0 * ySection + 1000.0) * 0.35 + 10.0 + 35;
            return (int) dOut;
        }

    }

    protected void clickShow(int x, int y) {
        Node node = null;
        AggregateNode aNode = null;
        boolean foundANode = false;
        // boolean foundINode = false;

        int xm = 0;
        int ym = 0;

        for (int i = 0; i < aggregateNodesHolder.size(); i++) {
            aNode = (AggregateNode) (aggregateNodesHolder.elementAt(i));
            xm = xMap(aNode.loc.x);
            ym = yMap(aNode.loc.y);
            if (global) {
                if ( (xm - x > -2) && (xm - x < 2) && (ym - y > -2) &&
                    (ym - y < 2)) {
                    showAggregateNode(aNode);
                    break;
                }
            }
            else {
                if ( (xm - x > -3) && (xm - x < 4) && (ym - y > -3) &&
                    (ym - y < 4)) {
                    showAggregateNode(aNode);
                    break;
                }
            }
        }

        if (!foundANode) {
            for (int i = 0; i < nodesHolder.size(); i++) {
                node = (Node) (nodesHolder.elementAt(i));
                xm = xMap(node.loc.x);
                ym = yMap(node.loc.y);
                if (global) {
                    if ( (xm - x > -2) && (xm - x < 2) && (ym - y > -2) &&
                        (ym - y < 2)) {
                        showNode(node);
                        break;
                    }
                }
                else {
                    if ( (xm - x > -3) && (xm - x < 4) && (ym - y > -3) &&
                        (ym - y < 4)) {
                        showNode(node);
                        break;
                    }
                }
            }
        }

        repaint();
    }

    public void recordHopCounts(String fileName) {
        BufferedWriter hopCountOut = null;
        try {
            hopCountOut = new BufferedWriter(new FileWriter(fileName), 1024);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        if (hopCountOut != null) {
            try {
                // to be deleted
                /*String str = "HopCountFile";
                        hopCountOut.write(str, 0, str.length());
                        hopCountOut.flush();
                        hopCountOut.close();*/

                for (int k = 0; k < nodesHolder.size(); k++) {
                    Node node = (Node) (nodesHolder.elementAt(k));
                    int hc = 0;
                    boolean found = false;
                    if (node.state == Constants.sBase) {
                        hc = 0;
                        found = true;
                    }
                    else {
                        int parent = node.parentID;
                        for (int i = 0; i < 100; i++) {
                            boolean parentFound = false;
                            for (int j = 0; j < nodesHolder.size(); j++) {
                                Node tempNode = (Node)
                                    (nodesHolder.elementAt(j));
                                if (tempNode.nodeID == parent) {
                                    parentFound = true;
                                    parent = tempNode.parentID;
                                    hc++;
                                    if (tempNode.state == Constants.sBase) {
                                        found = true;
                                    }
                                    break;
                                }
                            }
                            if (!parentFound) {
                                hc = 0;
                                break;
                            }
                            if (found) {
                                break;
                            }

                        }
                    }

                    String stringToWrite = "Node: " +
                        Integer.toString(node.nodeID) +
                        " Hop#: " + Integer.toString(hc);
                    hopCountOut.write(stringToWrite, 0, stringToWrite.length());
                    hopCountOut.newLine();
                }
                hopCountOut.flush();
                hopCountOut.close();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private void showNode(Node node) {
        int hc = 0;
        boolean found = false;
        if (node.state == Constants.sBase) {
            hc = 0;
            found = true;
        }
        else {
            int parent = node.parentID;
            for (int i = 0; i < 100; i++) {
                boolean parentFound = false;
                for (int j = 0; j < nodesHolder.size(); j++) {
                    Node tempNode = (Node) (nodesHolder.elementAt(j));
                    if (tempNode.nodeID == parent) {
                        parentFound = true;
                        parent = tempNode.parentID;
                        hc++;
                        if (tempNode.state == Constants.sBase) {
                            found = true;
                        }
                        break;
                    }
                }
                if (!parentFound) {
                    hc = 0;
                    break;
                }
                if (found) {
                    break;
                }

            }
        }
        if (Constants.DebugSwitch)
        dynamicHtmlTextArea.setText("<html><font face=\"Courier New\" size=-1>Node&nbsp;--&nbsp;"
                                    + "&nbsp;NodeID:" + int2Str(node.nodeID, 3)
                                    + "&nbsp;X:" + int2Str(node.loc.x, 4)
                                    + "&nbsp;Y:" + int2Str(node.loc.y, 4)
                                    + "&nbsp;Sentry:" + int2Str(node.sentryID, 4)
                                    + "&nbsp;Parent:" + int2Str(node.parentID, 4)
                                    + "<br>&nbsp;Sentry#:" + int2Str(node.numSentries, 1)
                                    + "&nbsp;Covered#:" + int2Str(node.numNbrs, 2)
                                    + "&nbsp;Voltage:" + int2Str(node.voltage, 5)
                                    + "&nbsp;State:" + int2Str(node.state, 1)
                                    + "&nbsp;Sensor:" + int2Str(node.sensorStatus, 1)
                                    + "&nbsp;Time:" + long2Str(node.iTime, 10)
                                    + "&nbsp;HopCount:"+ int2Str(hc, 2)
                                    + "</font>");
        else
        dynamicHtmlTextArea.setText("<html><font face=\"Courier New\" size=-1>Node&nbsp;--&nbsp;"
                                    + "&nbsp;NodeID:" + int2Str(node.nodeID, 3)
                                    + "&nbsp;X:" + int2Str(node.loc.x, 4)
                                    + "&nbsp;Y:" + int2Str(node.loc.y, 4)
                                    + "&nbsp;Sentry:" + int2Str(node.sentryID, 4)
                                    + "&nbsp;Parent:" + int2Str(node.parentID, 4)
                                    + "<br>&nbsp;Sentry#:" + int2Str(node.numSentries, 1)
                                    + "&nbsp;Covered#:" + int2Str(node.numNbrs, 2)
                                    + "&nbsp;Voltage:" + int2Str(node.voltage, 5)
                                    + "&nbsp;State:" + int2Str(node.state, 1)
                                    + "&nbsp;Sensor:" + int2Str(node.sensorStatus, 1)
                                    /* + "&nbsp;Time:" + long2Str(node.iTime, 10) */
                                    + "&nbsp;HopCount:"+ int2Str(hc, 2)
                                    + "</font>");
        dynamicLabel.setText(dynamicHtmlTextArea.getText());

    }

    private void showAggregateNode(AggregateNode aNode) {
        dynamicHtmlTextArea.setText("<html><font face=\"Courier New\" size=-1>ANode -- "
                                    + " NID:" + aNode.nodeID
                                    + " X:" + aNode.loc.x
                                    + " Y:" + aNode.loc.y
                                    + " Parent:" + aNode.parentID
                                    + " Str#:" + aNode.numSentries
                                    + " N#:" + aNode.numNodes
                                    + " V:" + aNode.voltage
                                    + "</font>");
        dynamicLabel.setText(dynamicHtmlTextArea.getText());

    }

    JTextArea statusHtmlTextArea = new JTextArea();
    JTextArea dynamicHtmlTextArea = new JTextArea();

    private JLabel statusLabel = null;
    private JLabel dynamicLabel = null;
    private JLabel nodesLabel = null;
    private JLabel detDelayLabel = null;
    private JLabel clsDelayLabel = null;
    private JLabel velDelayLabel = null;
    

    double co = 1.0;

    //Move a target according to all the points
    public void doMove(MovingStream movingStream) {
        statusHtmlTextArea.setText(sTitle[10]);
        statusLabel.setText(statusHtmlTextArea.getText());

        MovingObject mObj = movingStream.mObj;
        //mObj.setColor(colors[0]);
        //mObj.setStartAndEndLocation(p1, p2);
        mObj.setStream(movingStream);

        //speed control
        mObj.speedControl();

        Graphics g = getGraphics();
        // System.out.println(g == this.getGraphics());

        mObj.move(g, this);

        // System.out.println(g == getGraphics());

    }

    //move all the trace
    public void moveAll() {

        for (int i = 0; i < movingStreamsHolder.size(); i++) {
            doMove( (MovingStream) (movingStreamsHolder.elementAt(i)));
            //points = ((Vector)(streamsHolder.elementAt(streamID)));
        }

    }

    //draw grid
    private void paintGrid(Graphics g, double inter) {
        Color c = new Color(243, 233, 211);
        int screenWid = getWidth();
        int screenHei = getHeight();
        g.setColor(c);
        //g.drawString("(0,0)", 0, 13);

        for (double i = 10; i < screenWid; i += inter) {
            g.drawLine( (int) i, 0, (int) i, screenHei - 1);
        }
        //g.drawLine(screenWid-1, 0, screenWid-1, screenHei-1);

        for (double j = 10; j < screenHei; j += inter) {
            g.drawLine(0, (int) j, screenWid - 1, (int) j);
        }

    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (global) {
            paintGrid(g, 35.0);
        }
        else {
            paintGrid(g, 3.50 * xSection);

        }

        g.drawImage(image, 650, 11, this);

        for (int i = 0; i < nodesHolder.size(); i++) {
            Node node = (Node) (nodesHolder.elementAt(i));
            g.setColor(getNodeColor(node));
            Point p = new Point(xMap(node.loc.x), yMap(node.loc.y));
            paintPoint(g, node.getNodeID(), p);
            if (showSpan) {
                boolean found = false;
                Point pEnd = null;
                for (int j = 0; j < nodesHolder.size(); j++) {
                    if (i == j) {
                        continue;
                    }
                    Node anotherNode = (Node) (nodesHolder.elementAt(j));
                    if (node.parentID == anotherNode.nodeID) {
                        found = true;
                        pEnd = anotherNode.loc;
                        break;
                    }
                }
                if (found) {
                    Color old = g.getColor();
                    g.setColor(Color.black);
                    showSpanningTree(node.loc, pEnd, g);
                    g.setColor(old);
                    /* System.out.println(p);
                               System.out.println(pEnd); */
                }
            }

        }

        for (int i = 0; i < aggregateNodesHolder.size(); i++) {
            AggregateNode aNode = (AggregateNode)
                (aggregateNodesHolder.elementAt(i));
            g.setColor(Color.yellow);
            paintRandomPoints(g, aNode.subNodes);
            g.setColor(new Color(255, 0, 0));
            Point p = new Point(xMap(aNode.loc.x), yMap(aNode.loc.y));
            paintPoint(g, aNode.getAggregateNodeID(), p);
        }
    }

    private void showSpanningTree(Point start, Point end, Graphics g) {
        drawArrow(xMap(start.x), yMap(start.y), xMap(end.x), yMap(end.y), g);
    }

    private void drawArrow(int x1, int y1, int x2, int y2, Graphics g) {
        g.drawPolygon(getArrow(x1, y1, x2, y2, 10, 5, 0.5));
    }

    private Polygon getArrow(int x1, int y1, int x2, int y2, int headsize,
                             int difference, double factor) {

        int[] crosslinebase = getArrowHeadLine(x1, y1, x2, y2, headsize);
        int[] headbase = getArrowHeadLine(x1, y1, x2, y2, headsize
                                          - difference);
        int[] crossline = getArrowHeadCrossLine(crosslinebase[0],
                                                crosslinebase[1],
                                                x2, y2, factor);

        Polygon head = new Polygon();

        head.addPoint(headbase[0], headbase[1]);
        head.addPoint(crossline[0], crossline[1]);
        head.addPoint(x2, y2);
        head.addPoint(crossline[2], crossline[3]);
        head.addPoint(headbase[0], headbase[1]);
        head.addPoint(x1, y1);

        return head;
    }

    private int[] getArrowHeadLine(int xsource, int ysource, int xdest,
                                   int ydest,
                                   int distance) {
        int[] arrowhead = new int[2];
        int headsize = distance;

        double stretchfactor = 0;
        stretchfactor = 1 -
            (headsize /
             (Math.sqrt( ( (xdest - xsource) * (xdest - xsource)) +
                        ( (ydest - ysource) * (ydest - ysource)))));

        arrowhead[0] = (int) (stretchfactor * (xdest - xsource)) + xsource;
        arrowhead[1] = (int) (stretchfactor * (ydest - ysource)) + ysource;

        return arrowhead;
    }

    private int[] getArrowHeadCrossLine(int x1, int x2, int b1, int b2,
                                        double factor) {
        int[] crossline = new int[4];

        int x_dest = (int) ( ( (b1 - x1) * factor) + x1);
        int y_dest = (int) ( ( (b2 - x2) * factor) + x2);

        crossline[0] = (int) ( (x1 + x2 - y_dest));
        crossline[1] = (int) ( (x2 + x_dest - x1));
        crossline[2] = crossline[0] + (x1 - crossline[0]) * 2;
        crossline[3] = crossline[1] + (x2 - crossline[1]) * 2;
        return crossline;
    }

    private void paintRandomPoints(Graphics g, Vector subNodes) {
        for (int i = 0; i < subNodes.size(); i++) {
            Point point = (Point) subNodes.elementAt(i);
            int x = xMap(point.x);
            int y = yMap(point.y);
            if (global) {
                g.fillRect(x, y, 2, 2);
            }
            else {
                g.fillRect(x - 1, y - 1, 4, 4);
            }
        }
    }

    private void paintPoint(Graphics g, int nodeID, Point point) {
        if (global) {
            g.fillRect(point.x - 1, point.y - 1, 3, 3);
        }
        else {
            g.fillRect(point.x - 3, point.y - 3, 6, 6);
            g.drawString( (new Integer(nodeID)).toString(), point.x + 4,
                         point.y + 4);
        }
    }

    private Color getNodeColor(Node node) {
        if (node.state == Constants.sSentry) {
            //sentry node
            return (new Color(255, 0, 0));
        }

        if (node.state == Constants.sSentrySleep) {
            //sentry node
            return (new Color(255, 200, 200));
        }

        if (node.state == Constants.sNonSentry) {
            //non-sentry node
            return (new Color(0, 0, 255));
        }
        if (node.state == Constants.sNonSentrySleep) {
            //the node is asleep
            return (new Color(100, 100, 100));
        }
        if (node.state == Constants.sBase) {
            //the node is asleep
            return (Color.blue);
        }
        return (new Color(100, 100, 100));
    }

    void setStatusLabel(JLabel statusLabel) {
        this.statusLabel = statusLabel;
    }

    void setDynamicLabel(JLabel dynamicLabel) {
        this.dynamicLabel = dynamicLabel;
    }
    
    void setOtherLabels(JLabel nodesLabel, JLabel detDelayLabel, JLabel clsDelayLabel, JLabel velDelayLabel) {
    	this.nodesLabel = nodesLabel;
    	this.detDelayLabel = detDelayLabel;
    	this.clsDelayLabel = clsDelayLabel;
    	this.velDelayLabel = velDelayLabel;
    }
    

    synchronized void receivedTrackingMsg(int tEventID,
                                          int tEventType,
                                          int tReportType, 
                                          int tLeaderID, int tXVelocity,
                                          int tYVelocity,
                                          int tXCoord,
                                          int tYCoord, long tTimestamp,
                                          int tConfidenceLevel,
                                          /*int tMagnetNumber, int tMotionNumber,
                                          int tAcousticNumber*/
                                          int tDelays, int tTimeDiff) {
        // System.out.println(tEventType);
        int objectIndex = foundAnyObject(tEventID, tEventType);
        if (objectIndex == -1) {
            objectIndex = addMovingStream(tEventID, tEventType);
        }
        // TODO
        // 1. add to object
        // 2. do move
        insertPoint(objectIndex, tXCoord, tYCoord, tEventType);
        doMove( (MovingStream) (movingStreamsHolder.elementAt(objectIndex)));
    }

    synchronized public void insertPoint(int objectIndex, int tXCoord,
                                         int tYCoord, int tEventType) {
        Point point = new Point(tXCoord, tYCoord);
        MovingStream movingStream = ( (MovingStream) movingStreamsHolder.
                                     elementAt(
            objectIndex));
        movingStream.Points.addElement(point);
        movingStream.setType(tEventType);

    }

    synchronized public int addMovingStream(int tEventID, int tEventType) {
        MovingStream movingStream = new MovingStream(this, Color.black,
            tEventID, tEventType);
        // System.out.println(tEventType);
        movingStreamsHolder.add(movingStream);
        return (numMovingStreams++);
    }

    private int foundAnyObject(int eventID, int eventType) {
        int index = -1;
        for (int i = 0; i < movingStreamsHolder.size(); i++) {
            MovingStream movingStream =
                (MovingStream) (movingStreamsHolder.elementAt(i));
            if ( (movingStream.eventID == eventID)) { //&&
                // (movingStream.eventType == eventType)) {
                index = i;
                break;
            }

        }
        return index;
    }

	public String int2Str(int i, int size) {
		String subStr = Integer.toString(i);
		if (subStr.length() >= size) {
		  return subStr;
		}
		else {
	      int leng = subStr.length();
	      for (int j = 0; j < size - leng; j++)
	        subStr = subStr.concat("&nbsp;");
	      return subStr;
		}
	}

	public String long2Str(long l, int size) {
		String subStr = Long.toString(l);
		if (subStr.length() >= size) {
		  return subStr;
		}
		else {
	      int leng = subStr.length();
	      for (int j = 0; j < size - leng; j++)
	        subStr = subStr.concat("&nbsp;");
	      return subStr;
		}
	}


    void printTrackingMsg(int tEventID, int tEventType, int tReportType, 
                          int tLeaderID, int tXVelocity, int tYVelocity,
                          int tXCoord,
                          int tYCoord, long tTimestamp, int tConfidenceLevel,
                          int tDelays, int tTimeDiff/*, int tGroupSize*/) {
        numTrackings ++;
		// dynamicHtmlTextArea.
		int absVelocity = (int) Math.sqrt(tXVelocity * tXVelocity + 
								tYVelocity * tYVelocity) * 1000 / 447;
		if (Constants.DebugSwitch)		                          	
        	dynamicHtmlTextArea.setText(
        		"<html><font face=\"Courier New\" size=-1>Tracking&nbsp;--&nbsp;"
                                    + "&nbsp;EventID:" + int2Str(tEventID, 3)
                                    + "&nbsp;EventType:" + int2Str(tEventType, 1)
                                    + "&nbsp;RptType:" + int2Str(tReportType, 1)
                                    + "&nbsp;LeaderID:" + int2Str(tLeaderID, 3)
                                    + "&nbsp;X:" + int2Str(tXCoord, 4)
                                    + "&nbsp;Y:" + int2Str(tYCoord, 4)
                                    + "&nbsp;XVel:" + int2Str((tXVelocity * 1000 / 447), 4)
                                    + "&nbsp;YVel:" + int2Str((tYVelocity * 1000 / 447), 4)
                                    + "&nbsp;AbsVel:" + int2Str(absVelocity, 4)
                                    + "<br>&nbsp;TimeStamp:" + toDateString(tTimestamp) 
                                    + "&nbsp;Confidence:" + int2Str(tConfidenceLevel, 2)
                                    /*+ "&nbsp;Reserve1:" + int2Str(tMagnetNumber, 2)
                                    + "&nbsp;Reserve2:" + int2Str(tMotionNumber, 2)
                                    + "&nbsp;TimeDiff:" + int2Str(tAcousticNumber, 2)*/
                                    + "&nbsp;TimeDelay:" + int2Str(tTimeDiff, 2)
                                    // + "&nbsp;GroupSize:" + int2Str(tGroupSize, 2)
                                    + "</font>");
        else
        	dynamicHtmlTextArea.setText(
        		"<html><font face=\"Courier New\" size=-1>Tracking&nbsp;--&nbsp;"
                                    + "&nbsp;EventID:" + int2Str(tEventID, 3)
                                    + "&nbsp;EventType:" + int2Str(tEventType, 1)
                                    + "&nbsp;RptType:" + int2Str(tReportType, 1)
                                    + "&nbsp;X:" + int2Str(tXCoord, 4)
                                    + "&nbsp;Y:" + int2Str(tYCoord, 4)
                                    + "&nbsp;XVel:" + int2Str((tXVelocity * 1000 / 447), 4)
                                    + "&nbsp;YVel:" + int2Str((tYVelocity * 1000 / 447), 4)
                                    + "&nbsp;AbsVel:" + int2Str(absVelocity, 4)
                                    + "<br>&nbsp;TimeStamp:" + toDateString(tTimestamp) 
                                    + "&nbsp;Confidence:" + int2Str(tConfidenceLevel, 2)
                                    // + "&nbsp;Delays:" + int2Str(tDelays, 6)
                                    + "&nbsp;TimeDiff:" + int2Str(tTimeDiff, 2)
                                    + "&nbsp;NumHits:" + int2Str(numTrackings, 4)
                                    + "</font>");
        
        /* System.out.println("<html><font face=\"Courier New\" size=-1>Tracking&nbsp;--&nbsp;"
                                    + "&nbsp;EID:" + int2Str(tEventID, 3)
                                    + "&nbsp;ET:" + int2Str(tEventType, 1)
                                    + "&nbsp;LID:" + int2Str(tLeaderID, 3)
                                    + "&nbsp;X:" + int2Str(tXCoord, 4)
                                    + "&nbsp;Y:" + int2Str(tYCoord, 4)
                                    + "&nbsp;XVel:" + int2Str((tXVelocity * 1000 / 447), 4)
                                    + "&nbsp;YVel:" + int2Str((tYVelocity * 1000 / 447), 4)
                                    + "&nbsp;TS:" + long2Str(tTimestamp, 6)
                                    + "&nbsp;Conf:" + int2Str(tConfidenceLevel, 2)
                                    + "&nbsp;PVeh:" + int2Str(tMagnetNumber, 2)
                                    + "&nbsp;PPsn:" + int2Str(tMotionNumber, 2)
                                    + "&nbsp;Flt:" + int2Str(tAcousticNumber, 1)
                                    + "&nbsp;TD#:" + int2Str(tTimeDiff, 2)
                                    + "&nbsp;G:" + int2Str(tGroupSize, 2)
                                    + "</font>");*/
        dynamicLabel.setText(dynamicHtmlTextArea.getText());
        
        if (tDelays != 0 && tReportType == 1) {
			detDelayLabel.setText("<html><font face=\"Courier New\" size=-1 color=green> EID " + int2Str(tEventID, 2) + " DetDelay " + int2Str(tDelays, 3) + "</font>");
        }
        else if (tDelays != 0 && tReportType == 2) {
			clsDelayLabel.setText("<html><font face=\"Courier New\" size=-1 color=green> EID " + int2Str(tEventID, 2) + " ClsDelay " + int2Str(tDelays, 3) + "</font>");
        }
        else if (tDelays != 0 && tReportType == 3) {
			velDelayLabel.setText("<html><font face=\"Courier New\" size=-1 color=green> EID " + int2Str(tEventID, 2) + " VelDelay " + int2Str(tDelays, 3) + "</font>");
        }


    }

    void receivedIndividualNodeMsg(int iNodeID, int iXCoord, int iYCoord,
                                   int iSentryID, int iParentID,
                                   int iNumSentries,
                                   int iNumNbrs, int iVoltage, int iState,
                                   int iSensorStatus, long iTime) {
        if (iXCoord < west) {
            west = iXCoord;
        }
        if (iYCoord > south) {
            south = iYCoord;
        }
        Node nd = null;
        nd = lookupINode(iNodeID);
        if (nd != null) {
            nd.update(iSentryID, iParentID, iNumSentries, iNumNbrs, iVoltage,
                      iState, iSensorStatus, iTime);
        }
        else {
            Node node = new Node(iNodeID, iXCoord, iYCoord, iSentryID,
                                 iParentID,
                                 iNumSentries, iNumNbrs, iVoltage, iState,
                                 iSensorStatus, iTime);
            nodesHolder.addElement(node);
        }
        repaint();
    }

    private Node lookupINode(int iNodeID) {
        Node nd;
        for (int i = 0; i < nodesHolder.size(); i++) {
            nd = (Node) (nodesHolder.elementAt(i));
            if (nd.getNodeID() == iNodeID) {
                return nd;
            }
        }
        return null;
    }

    void printIndividualNodeMsg(int iNodeID, int iXCoord, int iYCoord,
                                int iSentryID, int iParentID, int iNumSentries,
                                int iNumNbrs, int iVoltage, int iState,
                                int iSensorStatus, long iTime) {
        numNodes ++;
        if (iState == Constants.sSentry || iState == Constants.sSentrySleep)
        	numSentry++;
        
        if (Constants.DebugSwitch)
        dynamicHtmlTextArea.setText("<html><font face=\"Courier New\" size=-1>Node&nbsp;--&nbsp;"
                                    + "&nbsp;NodeID:" + int2Str(iNodeID, 3)
                                    + "&nbsp;X:" + int2Str(iXCoord, 4)
                                    + "&nbsp;Y:" + int2Str(iYCoord, 4)
                                    + "&nbsp;Sentry:" + int2Str(iSentryID, 4)
                                    + "&nbsp;Parent:" + int2Str(iParentID, 4)
                                    + "<br>&nbsp;Sentry#:" + int2Str(iNumSentries, 1)
                                    + "&nbsp;Covered#:" + int2Str(iNumNbrs, 2)
                                    + "&nbsp;Voltage:" + int2Str(iVoltage, 5)
                                    + "&nbsp;State:" + int2Str(iState, 1)
                                    + "&nbsp;Sensor:" + int2Str(iSensorStatus, 1)
                                    + "&nbsp;Time:" + long2Str(iTime, 10)
                                    + "</font>");
        else
        dynamicHtmlTextArea.setText("<html><font face=\"Courier New\" size=-1>Node&nbsp;--&nbsp;"
                                    + "&nbsp;NodeID:" + int2Str(iNodeID, 3)
                                    + "&nbsp;X:" + int2Str(iXCoord, 4)
                                    + "&nbsp;Y:" + int2Str(iYCoord, 4)
                                    + "&nbsp;Sentry:" + int2Str(iSentryID, 4)
                                    + "&nbsp;Parent:" + int2Str(iParentID, 4)
                                    + "<br>&nbsp;Sentry#:" + int2Str(iNumSentries, 1)
                                    + "&nbsp;Covered#:" + int2Str(iNumNbrs, 2)
                                    + "&nbsp;Voltage:" + int2Str(iVoltage, 5)
                                    + "&nbsp;State:" + int2Str(iState, 1)
                                    + "&nbsp;Sensor:" + int2Str(iSensorStatus, 1)
                                    // + "&nbsp;NumNodes:" + int2Str(numNodes, 2)
                                    // + "&nbsp;SentryPerCentage:" + int2Str(numSentry * 100 / numNodes, 2)
                                    /* + "&nbsp;Time:" + long2Str(iTime, 10) */
                                    + "</font>");
        dynamicLabel.setText(dynamicHtmlTextArea.getText());
		nodesLabel.setText("<html><font face=\"Courier New\" size=-1 color=green>" + int2Str(numNodes, 3) + " nodes " + int2Str(numSentry * 100 / numNodes, 3) +"% sentries</font>");
    }

    public void clearDynamic() {
        dynamicHtmlTextArea.setText("<html><font size=+0></font>");
        dynamicLabel.setText(dynamicHtmlTextArea.getText());
    }

    void receivedAggregateNodeMsg(int aNodeID, int aXCoord, int aYCoord,
                                  int aParentID, int aNumSentries,
                                  int aNumNodes, long aVoltage) {
        if (aXCoord < west) {
            west = aXCoord;
        }
        if (aYCoord > south) {
            south = aYCoord;
        }

        AggregateNode nd = null;
        nd = lookupANode(aNodeID);
        if (nd != null) {
            nd.update(aParentID, aNumSentries, aVoltage);
        }
        else {
            AggregateNode aNode = new AggregateNode(aNodeID, aXCoord, aYCoord,
                aParentID, aNumSentries,
                aNumNodes, aVoltage);
            aggregateNodesHolder.addElement(aNode);
        }
        repaint();
    }

    private AggregateNode lookupANode(int aNodeID) {
        AggregateNode nd;
        for (int i = 0; i < aggregateNodesHolder.size(); i++) {
            nd = (AggregateNode) (aggregateNodesHolder.elementAt(i));
            if (nd.getAggregateNodeID() == aNodeID) {
                return nd;
            }
        }
        return null;
    }

    void printAggregateNodeMsg(int aNodeID, int aXCoord, int aYCoord,
                               int aParentID, int aNumSentries,
                               int aNumNodes, long aVoltage) {
        dynamicHtmlTextArea.setText("<html><font face=\"Courier New\" size=-1>aNode -- "
                                    + "&nbsp;NID:" + aNodeID
                                    + "&nbsp;X:" + aXCoord
                                    + "&nbsp;Y:" + aYCoord
                                    + "&nbsp;Parent:" + aParentID
                                    + "&nbsp;Str#:" + aNumSentries
                                    + "&nbsp;N#:" + aNumNodes
                                    + "&nbsp;V:" + aVoltage
                                    + "</font>");
        dynamicLabel.setText(dynamicHtmlTextArea.getText());

    }

    void printNetworkConfiguration(int nNetworkRound,
                                   int nNetworkPhase,
                                   int nBaseID,
                                   long nLatitude,
                                   long nLongitude,
                                   long nNetworkTime) {
        if (nNetworkPhase >= 0 || nNetworkPhase < 11) {
            statusHtmlTextArea.setText(sTitle[nNetworkPhase]);
            statusLabel.setText(statusHtmlTextArea.getText());
            Date currentData = new Date();
            long drift = currentData.getTime()/1000 - nNetworkTime;
            dynamicHtmlTextArea.setText("<html><font face=\"Courier New\" size=-1>" + "&nbsp;Round No." +
                                        nNetworkRound + "&nbsp;    Basemote Time: "
                                        + new Date(nNetworkTime*1000)+" Time Drift: "+drift+"<br>"
                                        + "&nbsp;TripWireID: " + nBaseID
                                        + "&nbsp;Latitude: " + nLatitude
                                        + "&nbsp;Longtitue: " + nLongitude
                                        + "</font>");
            dynamicLabel.setText(dynamicHtmlTextArea.getText());
        }

        repaint();

    }

    public void run() {
        repaint();
    }

    public void clear() {

		numSentry = 0;
		numNodes = 0;
		numTrackings = 0;


        Vector points = new Vector();

	    south = Integer.MIN_VALUE;
	    west = Integer.MAX_VALUE;

        // delete moving streams
        for (int i = 0; i < movingStreamsHolder.size(); i++) {
            MovingStream ms = (MovingStream) (movingStreamsHolder.elementAt(i));
            if (ms != null) {
                if (ms.mObj != null) {
                    ms.mObj.repaintValue = 0;
                    if (ms.mObj.holdingTimer != null) {
                        ms.mObj.holdingTimer.cancel();
                    }
                    ms.mObj.isHolding = false;
                }

                points = (Vector) ms.Points;
                points.clear();
            }

        }
        movingStreamsHolder.clear();

        nodesHolder.clear();

        aggregateNodesHolder.clear();
        numMovingStreams = 0;

        clearDynamic();

		nodesLabel.setText("<html><font face=\"Courier New\" size=-1 color=green>--- nodes ---% sentries</font>");
		detDelayLabel.setText("<html><font face=\"Courier New\" size=-1 color=green> EID -- DetDelay ---</font>");
		clsDelayLabel.setText("<html><font face=\"Courier New\" size=-1 color=green> EID -- ClsDelay ---</font>");
		velDelayLabel.setText("<html><font face=\"Courier New\" size=-1 color=green> EID -- VelDelay ---</font>");


        repaint();
    }

    String[] sTitle = {
        "<html><font size=+0 color=red>STATUS: CHAOS</font>",
        "<html><font size=+0 color=red>STATUS: INITIALIZATION</font>",
        "<html><font size=+0 color=red>STATUS: TIME SYNCHRONIZATION</font>",
        "<html><font size=+0 color=red>STATUS: LOCALIZATION</font>",
        "<html><font size=+0 color=red>STATUS: SYMMETRY DETECTION</font>",
        "<html><font size=+0 color=red>STATUS: BACKBONE CREATION</font>",
        "<html><font size=+0 color=red>STATUS: BACKBONE COMMIT</font>",
        "<html><font size=+0 color=red>STATUS: SENTRY SELECTION</font>",
        "<html><font size=+0 color=red>STATUS: REPORT STATUS</font>",
        "<html><font size=+0 color=red>STATUS: SENSOR CALIBRATION</font>",
        "<html><font size=+0 color=red>STATUS: TRACKING</font>"
    };

	String toDateString(long i) {
		Date dt = new Date(1000l * i);
		return dt.toString();
	}


}
