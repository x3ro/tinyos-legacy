/**
 * <p>Title: SOWN Mote Field Setup</p>
 * <p>Description: Setup GUI sor SOWN Mote Field
 * called by Xetron Cardinal MissionGUI</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UVa</p>
 * @author Ting Yan, Tian He, etc.
 * @version 1.2
 */

public class MyMessage
    extends net.tinyos.message.Message {
    MyMessage(byte[] b) {
        super(b);
    }

    void setUIElement(int offset, int length, long val) {
        super.setUIntElement(offset, length, val);
    }
}
