/**
 * <p>Title: SOWN Mote Field Setup</p>
 * <p>Description: Setup GUI sor SOWN Mote Field
 * called by Xetron Cardinal MissionGUI</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UVa</p>
 * @author Ting Yan, Tian He, etc.
 * @version 1.2
 */


// constants used in all classes
public class Constants {
	
	// for internal debugging
	public static final boolean DebugSwitch = false;
	
    // SerialForward Server Information - port number and IP
    public static final int serverPort = 9000;
    public static final String serverIP = "127.0.0.1"; // localhost

    // packet information
    public static final int packetSize = 36;
    public static final int macHeaderSize = 5;
    public static final int flagPosition = macHeaderSize;
    public static final int recordTypePosition = macHeaderSize + 1;

    //public static final int sourceIDPosition = macHeaderSize + 2;
    public static final int messageIDPosition = macHeaderSize + 2;
    public static final int dataPosition = 8;

    // sending packets
    public static final int sendPacketSize = 34;
    public static final int AM_TYPE = 55;
    public static final int groupID = 125;
    public static final short TOS_BCAST_ADDR = (short) 0xffff;
    public static final byte BYTE_COUNT = (byte) 29;
    public static final byte FLAG = (byte) 3;
    public static final int GPS_AM_TYPE = 157;

    // tracking notification
    // public static final int tCmdIDPosition = dataPosition;
    public static final int tEventIDPosition = dataPosition;
    public static final int tEventTypePosition = dataPosition + 1;
    public static final int tReportTypePosition = dataPosition + 2;
    public static final int tXCoordPosition = dataPosition + 3;
    public static final int tYCoordPosition = dataPosition + 5;
    public static final int tXVelocityPosition = dataPosition + 7;
    public static final int tYVelocityPosition = dataPosition + 9;
    public static final int tTimestampPosition = dataPosition + 11;
    public static final int tConfidenceLevelPosition = dataPosition + 15;
    public static final int tDelaysPosition = dataPosition + 16;
    // public static final int tMotionNumberPosition = dataPosition + 17;
    public static final int tTimeDiffPosition = dataPosition + 18;

    public static final int tLeaderIDDebugPosition = dataPosition + 2;
    public static final int tXCoordDebugPosition = dataPosition + 4;
    public static final int tYCoordDebugPosition = dataPosition + 6;
    public static final int tXVelocityDebugPosition = dataPosition + 8;
    public static final int tYVelocityDebugPosition = dataPosition + 10;
    public static final int tTimestampDebugPosition = dataPosition + 12;
    public static final int tConfidenceLevelDebugPosition = dataPosition + 16;
    public static final int tMagnetNumberDebugPosition = dataPosition + 17;
    public static final int tMotionNumberDebugPosition = dataPosition + 18;
    public static final int tAcousticNumberDebugPosition = dataPosition + 19;
    public static final int tTimeDiffDebugPosition = dataPosition + 20;
    public static final int tGroupSizeDebugPosition = dataPosition + 22;


    // individual node status notification
    public static final int iNodeIDPosition = dataPosition;
    public static final int iXCoordPosition = dataPosition + 2;
    public static final int iYCoordPosition = dataPosition + 4;
    public static final int iSentryIDPosition = dataPosition + 6;
    public static final int iParentIDPosition = dataPosition + 8;
    public static final int iNumSentriesPosition = dataPosition + 10;
    public static final int iNumNbrsPosition = dataPosition + 11;
    public static final int iVoltagePosition = dataPosition + 12;
    public static final int iStatePosition = dataPosition + 14;
    public static final int iSensorStatusPosition = dataPosition + 15;
    public static final int iTimePosition = dataPosition + 16;

    // aggregate node status notification
    public static final int aNodeIDPosition = dataPosition;
    public static final int aXCoordPosition = dataPosition + 2;
    public static final int aYCoordPosition = dataPosition + 4;
    public static final int aParentIDPosition = dataPosition + 6;
    public static final int aNumSentriesPosition = dataPosition + 8;
    public static final int aNumNodesPosition = dataPosition + 10;
    public static final int aVoltagePosition = dataPosition + 12;

    // network configuration notification
    /* public static final int nNetworkRoundPosition = dataPosition;
    public static final int nNetworkPhasePosition = dataPosition + 1;
    public static final int nBaseIDPosition = dataPosition + 2; */
    public static final int nBaseIDPosition = dataPosition;
    public static final int nNetworkPhasePosition = dataPosition + 2;
    public static final int nNetworkRoundPosition = dataPosition + 3;
    public static final int nLatitudePosition = dataPosition + 4;
    public static final int nLongitudePosition = dataPosition + 8;
    public static final int nNetworkTimePosition = dataPosition + 12;

    /* public static final int nOriginOfReferencePosition = dataPosition + 1;
       public static final int nNetworkTimePosition = dataPosition + 14;
       public static final int nRotationPeriodPosition = dataPosition + 18; */

    // event types
    public static final int eUnknown = 0;
    public static final int eRelay = 1;
    public static final int eSmallVehicle = 2;
    public static final int eLargeVehicle = 3;
    public static final int eUnarmedPerson = 4;
    public static final int eArmedPerson = 5;

    // size of the field
    public static final int fieldLength = 10000;
    public static final int fieldWidth = 1000;
    public static final int sentrySize = 320;

    // node states
    public static final int sSentry = 0;
    public static final int sSentrySleep = 1;
    public static final int sNonSentry = 2;
    public static final int sNonSentrySleep = 3;
    public static final int sBase = 4;

    public static final long Default_Clock = 0;
    public static final int Default_Delay = 0;
    public static final int Default_GridX = 10;
    // public static final int Default_SDPower = 255;
    public static final int Default_SentrySendPower = 20;
    public static final int Default_PowerMode = 4;
    public static final int Default_SDThreshold = 70;
    public static final int Default_PMTimeout = 100;
    // public static final int Default_SamplingInterval = 20;
    // public static final int Default_RefreshInterval = 500;
    public static final int Default_PIRThreshold = 100;
    // public static final int Default_DOA = 1;
    public static final int Default_PhaseDelay = 20;
    public static final int Default_ReportPeriod = 5;
    public static final int Default_PMPhaseCount = 1000;
    // public static final int Default_Range = 30;
    public static final int Default_SyncDelay = 30;
    public static final int Default_SDBeaconCount = 5;
    public static final int Default_GPSRefPointLon = -282637920;
    public static final int Default_GPSRefPointLat = 136914660;
  	public static final int Default_GPSSendPower = 10;
  	public static final int Default_GPSSendPeriod = 3;
    public static final int Default_UpperBound = 35;
    public static final int Default_DeltaRSSI = 5;
    public static final int Default_LatitudeDegree = 38;
    public static final int Default_LongitudeDegree = 78;
    public static final int Default_LatMinuteInt = 1;
    public static final double Default_LatMinuteDec = 1.983;
    public static final int Default_LongMinuteInt = 30;
    public static final double Default_LongMinuteDec = 30.673;
	public static final int Default_MagThreshold = 20;
	public static final int Default_AcousticThreshold = 10;
	public static final int Default_ShutdownThreshold = 70;
	public static final int Default_FlowRate = 3;
	public static final int Default_DetectionThreshold = 3;
	
    public static final long Min_Clock = 0;
    public static final int Min_Delay = 0;
    public static final int Min_GridX = 1;
    // public static final int Min_SDPower = 0;
    public static final int Min_SentrySendPower = 0;
    public static final int Min_PowerMode = 0;
    public static final int Min_SDThreshold = 0;
    public static final int Min_PMTimeout = 1;
    // public static final int Min_SamplingInterval = 10;
    // public static final int Min_RefreshInterval = 300;
    public static final int Min_PIRThreshold = 0;
    // public static final int Min_DOA = 0;
    public static final int Min_PhaseDelay = 10;
    public static final int Min_ReportPeriod = 5;
    public static final int Min_PMPhaseCount = 1;
    // public static final int Min_Range = 0;
    public static final int Min_SyncDelay = 20;
    public static final int Min_SDBeaconCount = 4;
    public static final int Min_GPSRefPointLon = -648000000;
    public static final int Min_GPSRefPointLat = -324000000;
    public static final int Min_GPSSendPower = 0;
    public static final int Min_GPSSendPeriod = 0;
    public static final int Min_UpperBound = 0;
    public static final int Min_DeltaRSSI = 0;
    public static final int Min_LatitudeDegree = 0;
    public static final int Min_LongitudeDegree = 0;
    public static final int Min_MinuteInt = 0;
    public static final double Min_MinuteDec = 0.0;
	public static final int Min_MagThreshold = 1;
	public static final int Min_AcousticThreshold = 1;
	public static final int Min_ShutdownThreshold = 0;
	public static final int Min_FlowRate = 0;
	public static final int Min_DetectionThreshold = 1;

    public static final long Max_Clock = 4294967295L;
    public static final int Max_Delay = 65535;
    public static final int Max_GridX = 255;
    // public static final int Max_SDPower = 255;
    public static final int Max_SentrySendPower = 255;
    public static final int Max_PowerMode = 6;
    public static final int Max_SDThreshold = 100;
    public static final int Max_PMTimeout = 255;
    // public static final int Max_SamplingInterval = 40;
    // public static final int Max_RefreshInterval = 1000;
    public static final int Max_PIRThreshold = 255;
    // public static final int Max_DOA = 5;
    public static final int Max_PhaseDelay = 255;
    public static final int Max_ReportPeriod = 10;
    public static final int Max_PMPhaseCount = 65535;
    // public static final int Max_Range = 255;
    public static final int Max_SyncDelay = 255;
    public static final int Max_SDBeaconCount = 20;
    public static final int Max_GPSRefPointLon = 648000000;
    public static final int Max_GPSRefPointLat = 324000000;
    public static final int Max_GPSSendPower = 255;
    public static final int Max_GPSSendPeriod = 65535;
    public static final int Max_UpperBound = 500;
    public static final int Max_DeltaRSSI = 500;
    public static final int Max_LatitudeDegree = 90;
    public static final int Max_LongitudeDegree = 180;
    public static final int Max_MinuteInt = 59;
    public static final double Max_MinuteDec = 59.999;
	public static final int Max_MagThreshold = 255;
	public static final int Max_AcousticThreshold = 255;
	public static final int Max_ShutdownThreshold = 100;
	public static final int Max_FlowRate = 255;
	public static final int Max_DetectionThreshold = 5;

	public static final int Default_ScheduleBits = 0xffff;
	public static final int Default_SkipBits = 0x1840;

}
