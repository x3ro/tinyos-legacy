/**
 * <p>Title: SOWN Mote Field Setup</p>
 * <p>Description: Setup GUI sor SOWN Mote Field
 * called by Xetron Cardinal MissionGUI</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UVa</p>
 * @author Ting Yan, Tian He, etc.
 * @version 1.2
 */

import java.util.*;
import java.awt.*;

public class MovingStream {
    Vector Points = null;
    MovingObject mObj = null;
    int eventID;
    int eventType;
    MovingStream(FieldPanel fp, Color c, int eventID, int eventType) {
        this.eventID = eventID;
        this.eventType = eventType;
        mObj = new MovingObject(c);
        mObj.setPanel(fp);
        mObj.setType(eventType);
        // System.out.println(eventType);
        Points = new Vector(100);
    }

    void setType(int tEventType) {
        if (mObj != null) {
            mObj.setType(tEventType);
        }
    }

}
