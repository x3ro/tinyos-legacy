/**
 * <p>Title: SOWN Mote Field Setup</p>
 * <p>Description: Setup GUI sor SOWN Mote Field
 * called by Xetron Cardinal MissionGUI</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UVa</p>
 * @author Ting Yan, Tian He, etc.
 * @version 1.2
 */

import java.awt.*;
import java.util.*;

public class MovingObject
    extends Frame
    implements Runnable {

    java.util.Timer movingTimer = null;
    java.util.Timer holdingTimer = null;
    static FieldPanel panel;
    private static final long movingInterval = 50; //50 millis
    private static final long holdingInterval = 100; //50 millis
    private static final Image imgPerson = Toolkit.getDefaultToolkit().getImage("Person.gif");
    private static final Image imgSoldier = Toolkit.getDefaultToolkit().getImage("Soldier.gif");
    private static final Image imgCar = Toolkit.getDefaultToolkit().getImage("Car.gif");
    private static final Image imgTank = Toolkit.getDefaultToolkit().getImage("Tank.gif");
    private static final Image imgUnknown = Toolkit.getDefaultToolkit().getImage("Unknown.gif");

    public void setType(int eventType) {
        this.eventType = eventType;
    }

    int repaintValue = 0; //every refresh increase 1
    final int repainThreshold = 55; //when repaintValue reach this, repaint

    //Properties for a moving object
    int eventID = 0;
    int eventType = 0;
    int count = 0;

    Point startLoc; //start position
    Point endLoc; //end position after moving
    Point curLoc;
    Point preLoc;
    private Color color;

    public Color getColor() {
        return color;
    }

    boolean isHolding;
    boolean isMoving;

    final double minVelocityX = 20.;
    final double minVelocityY = 20.;

    double velocityX = 20.; //everytime add 5 on x_axis
    double velocityY = 20.; //everytime add 5 on y_axis at most

    //draw a rect as a moving object
    int width;
    int height;

    //background color
    Color backColor;

    //Graphics graphics;

    //to control moving event
    MovingStream movingStream;
    int numPoints;
    int curPoint;

    class movingTask
        extends TimerTask {
        public void run() {
            //System.out.println("Time's up!");
            refresh();
        }
    }

    // holding a target for a while after it reachs the end point
    class holdingTask
        extends TimerTask {
        public void run() {
            //Draw the object at current location
            drawObjectAtCurPos();
        }
    }

    public void run() {
        super.repaint();
    }

    //construct function with background color
    MovingObject(Color back) {
        startLoc = new Point();
        endLoc = new Point();
        curLoc = new Point();
        preLoc = new Point();

        curPoint = 0;
        color = Color.black;
        isHolding = false;
        isMoving = false;

        width = 15; //default
        height = 15; //default
        backColor = back;

        count = 0;

    }

    //speed control
    public void speedControl() {
        if (curPoint >= movingStream.Points.size()) {
            velocityX = minVelocityX;
            velocityY = minVelocityY;
        }
        else if (curPoint <= movingStream.Points.size() - 2) {
            velocityX = 2 * velocityX;
            velocityY = 2 * velocityY;
        }
    }

    //set the Panel which contain the moving object
    public void setPanel(FieldPanel pane) {
        panel = pane;
    }

    public void setStartAndEndLocation(Point p1, Point p2) {
        startLoc = new Point(p1);
        endLoc = new Point(p2);
    }

    //set the trace of the stream so that the moving obj can find out
    //  the coming position
    public void setStream(MovingStream movingStream) {
        this.movingStream = movingStream;
    }

    public void setColor(Color c) {
        color = c;
    }

    //store Graphics instance
    /* private void setGraphics(Graphics g) {
      graphics = g;
       }*/

    //use this function to move an object
    public void move(Graphics g, FieldPanel pane) {
        // System.out.println(g == panel.getGraphics());
        // System.out.print("moving");
        if (movingStream != null || movingStream.Points != null) {
            numPoints = movingStream.Points.size();
            /*if (numPoints < 2)
                     return; //no position for moving*/

            if (isMoving) {
                return;
            }

            if (isHolding) {
                isHolding = false;
                repaintValue = 0;
                if (holdingTimer != null) {
                    holdingTimer.cancel();
                }
            }

            isMoving = true;

            // if first move, set current position 1
            // otherwise just leave it unchange
            // if (curPoint == 0)
            // curPoint = 1; //current start point

            if (curPoint == 0 && movingStream.Points.size() == 1) {
                setStartAndEndLocation( ( (Point) (movingStream.Points.
                    elementAt(0))),
                                       ( (Point) (movingStream.Points.elementAt(
                    0))));
            }
            else if (curPoint >= movingStream.Points.size()) {
                setStartAndEndLocation( ( (Point) (movingStream.Points.
                    elementAt(
                    numPoints - 1))),
                                       ( (Point) (movingStream.Points.elementAt(
                    numPoints - 1))));
            }
            else {
                setStartAndEndLocation( ( (Point) (movingStream.Points.
                    elementAt(
                    curPoint - 1))), ( (Point) (
                    movingStream.Points.elementAt(curPoint))));
            }
            curLoc = startLoc;
            preLoc = curLoc;
            //repainThreshold = (int)(width/velocityX);
            repaintValue = 0;
            // setGraphics(g); //store Graphics instance
            // setPanel(pane); //store the Panel
            drawObject(g, curLoc);
            // System.out.println(g == pane.getGraphics());
            // System.out.println("draw");

            // System.out.println("move...");

            getNextPoint(curLoc);
            //drawObject(g, curLoc, color);

            if (movingTimer != null) {
                movingTimer.cancel();

            }
            movingTimer = new java.util.Timer();
            movingTimer.schedule(new movingTask(), 0, movingInterval);
        }
    }

    private void refresh() {

        //System.out.println("refresh");
        //drawObject(graphics, preLoc, backColor); //erase previous one
        // erase(panel.getGraphics(), preLoc);
        preLoc = curLoc;
        getNextPoint(curLoc);
        drawObject(panel.getGraphics(), curLoc, color);

        panel.isMoving = true; //control repaint
        isMoving = true;

        if (curLoc.x == endLoc.x && curLoc.y == endLoc.y) {
            //moving is divided into many phrases
            //one phrase ends, start next phrase
            //till to the last point
            curPoint++;

            speedControl();
            if (curPoint >= movingStream.Points.size()) {
                isHolding = true;
                movingTimer.cancel();
                isMoving = false;
                panel.isMoving = false;
                if (holdingTimer != null) {
                    holdingTimer.cancel();
                }
                holdingTimer = new java.util.Timer();
                holdingTimer.schedule(new holdingTask(), 0, holdingInterval);
                panel.repaint();

            }
            else {
                setStartAndEndLocation( ( (Point) (movingStream.Points.
                    elementAt(
                    curPoint - 1))), ( (Point) (
                    movingStream.Points.elementAt(curPoint))));
            }
        }

    }

    //for holding task
    public void drawObjectAtCurPos() {
        repaintValue++;
        if (repaintValue < repainThreshold) {
            drawObject(panel.getGraphics(), curLoc, color);
        }
        else {
            repaintValue = 0;
            holdingTimer.cancel();
            isHolding = false;
            panel.repaint();
        }
    }

    //get the next point the moving object will move to
    private void getNextPoint(Point next) {
        //double velocityX = 5.; //everytime add 5 on x_axis
        //double velocityY = 5.; //everytime add 5 on y_axis at most
        double slope;
        Point p1 = new Point(curLoc);
        Point p2 = new Point(endLoc);

        int deltx = Math.abs(p2.x - p1.x);
        int delty = Math.abs(p2.y - p1.y);

        if (deltx >= delty && deltx > velocityX) {
            slope = ( (double) (delty)) / ( (double) (deltx));
            if (p2.y > p1.y) {
                p1.y = p1.y + (int) (slope * velocityX);
            }
            else if (p2.y < p1.y) {
                p1.y = p1.y - (int) (slope * velocityX);
            }
            else {
                ;
            }
            //p1.y = (int)( ( (double) (p2.y - p1.y) /
            // ( (1.) * (p2.x - p1.x))) * velocityX) + p1.y;
            if (p2.x >= p1.x) {
                p1.x = p1.x + (int) velocityX;
            }
            else {
                p1.x = p1.x - (int) velocityX;
            }
        }
        else if (deltx < delty && delty > velocityY) {
            slope = ( (double) (deltx)) / ( (double) (delty));
            if (p2.x > p1.x) {
                p1.x = p1.x + (int) (slope * velocityY);
            }
            else if (p2.x < p1.x) {
                p1.x = p1.x - (int) (slope * velocityY);
            }
            else {
                ;
            }
            //p1.x = (int)(((double) (p2.x - p1.x) /
            //  ( (1.) * (p2.y - p1.y))) * velocityY) + p1.x;
            if (p2.y >= p1.y) {
                p1.y = p1.y + (int) velocityY;
            }
            else {
                p1.y = p1.y - (int) velocityY;
            }
        }
        else {
            //the start and end points are too close
            p1.x = p2.x;
            p1.y = p2.y;
        }
        // add here to eliminate the trace
        next.x = p1.x;
        next.y = p1.y;

    }

    //erase the moving target at point with background color
    /* private void erase(Graphics g, Point point) {
        //oldColor = g.getColor(); //save old color
        if (SOWNMoteFieldGUI.tp.getSelectedIndex() == 0) {

            g.setColor(backColor);
            int sizeFactor = 2;
            //System.out.println(color);
            if (!panel.global) {
                sizeFactor = 4;

            }
            int x = panel.xMap(point.x);
            int y = panel.yMap(point.y);

            if (eventType == Constants.eSmallVehicle) {
                g.fillOval(x - sizeFactor * 4, y - sizeFactor * 4,
                           8 * sizeFactor, 8 * sizeFactor);
                // System.out.println(x + " " + y);
            }
            else if (eventType == Constants.eLargeVehicle) {
                g.fillOval(x - sizeFactor * 6, y - sizeFactor * 6,
                           12 * sizeFactor, 12 * sizeFactor);
            }
            else if (eventType == Constants.eUnarmedPerson) {
                g.fillRect(x - sizeFactor * 4, y - sizeFactor * 4,
                           8 * sizeFactor, 8 * sizeFactor);
            }
            else if (eventType == Constants.eArmedPerson) {
                g.fillRect(x - sizeFactor * 6, y - sizeFactor * 6,
                           12 * sizeFactor, 12 * sizeFactor);
            }
            //System.out.println(g == panel.getGraphics());
        }
        //g.setColor(oldColor); //restore old color
    }*/

    //draw moving target at point
    synchronized private void drawObject(Graphics g, Point point) {
        // System.out.println(eventType);
        if (SOWNMoteFieldGUI.tp.getSelectedIndex() == 0) {
            Color oldColor = g.getColor();
            g.setColor(color);
            int sizeFactor = 2;
            //System.out.println(color);
            if (!panel.global) {
                sizeFactor = 4;

            }
            int x = panel.xMap(point.x);
            int y = panel.yMap(point.y);

            if (eventType == Constants.eSmallVehicle) {
       	        g.drawImage(imgCar, x-16, y-16, this);

                /* g.fillOval(x - sizeFactor * 4, y - sizeFactor * 4,
                           8 * sizeFactor, 8 * sizeFactor);*/
                // System.out.println(x + " " + y);
            }
            else if (eventType == Constants.eLargeVehicle) {
            	g.drawImage(imgTank, x-16, y-16, this);
                /* g.fillOval(x - sizeFactor * 6, y - sizeFactor * 6,
                           12 * sizeFactor, 12 * sizeFactor);*/
            }
            else if (eventType == Constants.eUnarmedPerson) {
            	g.drawImage(imgPerson, x-24, y-24, 48, 48, this);
                /* g.fillRect(x - sizeFactor * 4, y - sizeFactor * 4,
                           8 * sizeFactor, 8 * sizeFactor);*/
            }
            else if (eventType == Constants.eArmedPerson) {
            	g.drawImage(imgSoldier, x-16, y-16, this);
                /* g.fillRect(x - sizeFactor * 6, y - sizeFactor * 6,
                           12 * sizeFactor, 12 * sizeFactor);*/
            }
            else if (eventType == Constants.eUnknown) {
            	g.drawImage(imgUnknown, x-16, y-16, this);
            }
            //System.out.println(g == panel.getGraphics());

            /* if (eventType == Constants.eSmallVehicle) {
                g.fillOval(x - sizeFactor * 4, y - sizeFactor * 4,
                           8 * sizeFactor, 8 * sizeFactor);
                // System.out.println(x + " " + y);
            }
            else if (eventType == Constants.eLargeVehicle) {
                g.fillOval(x - sizeFactor * 6, y - sizeFactor * 6,
                           12 * sizeFactor, 12 * sizeFactor);
            }
            else if (eventType == Constants.eUnarmedPerson) {
                g.fillRect(x - sizeFactor * 4, y - sizeFactor * 4,
                           8 * sizeFactor, 8 * sizeFactor);
            }
            else if (eventType == Constants.eArmedPerson) {
                g.fillRect(x - sizeFactor * 6, y - sizeFactor * 6,
                           12 * sizeFactor, 12 * sizeFactor);
            }*/

            // System.out.println(g == panel.getGraphics());

            g.setColor(oldColor);
        }
    }

    //draw moving target at point with color c
    synchronized private void drawObject(Graphics g, Point point, Color c) {
        if (SOWNMoteFieldGUI.tp.getSelectedIndex() == 0) {

            //System.out.println(color);
            Color oldColor;
            oldColor = g.getColor(); //save old color

            g.setColor(color);

            int sizeFactor = 2;
            //System.out.println(color);
            if (!panel.global) {
                sizeFactor = 4;

            }
            int x = panel.xMap(point.x);
            int y = panel.yMap(point.y);

            if (eventType == Constants.eSmallVehicle) {
       	        g.drawImage(imgCar, x-16, y-16, this);

                /* g.fillOval(x - sizeFactor * 4, y - sizeFactor * 4,
                           8 * sizeFactor, 8 * sizeFactor);*/
                // System.out.println(x + " " + y);
            }
            else if (eventType == Constants.eLargeVehicle) {
            	g.drawImage(imgTank, x-16, y-16, this);
                /* g.fillOval(x - sizeFactor * 6, y - sizeFactor * 6,
                           12 * sizeFactor, 12 * sizeFactor);*/
            }
            else if (eventType == Constants.eUnarmedPerson) {
            	g.drawImage(imgPerson, x-24, y-24, 48, 48, this);
                /* g.fillRect(x - sizeFactor * 4, y - sizeFactor * 4,
                           8 * sizeFactor, 8 * sizeFactor);*/
            }
            else if (eventType == Constants.eArmedPerson) {
            	g.drawImage(imgSoldier, x-16, y-16, this);
                /* g.fillRect(x - sizeFactor * 6, y - sizeFactor * 6,
                           12 * sizeFactor, 12 * sizeFactor);*/
            }
            else if (eventType == Constants.eUnknown) {
            	g.drawImage(imgUnknown, x-16, y-16, this);
            }
            
            //System.out.println(g == panel.getGraphics());

            g.setColor(oldColor); //restore old color
        }
    }
}
