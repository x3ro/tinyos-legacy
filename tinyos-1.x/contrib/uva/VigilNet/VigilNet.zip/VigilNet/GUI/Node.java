/**
 * <p>Title: SOWN Mote Field Setup</p>
 * <p>Description: Setup GUI sor SOWN Mote Field
 * called by Xetron Cardinal MissionGUI</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UVa</p>
 * @author Ting Yan, Tian He, etc.
 * @version 1.2
 */
import java.awt.*;

public class Node {
    int nodeID;
    Point loc;
    int sentryID;
    int parentID;
    int numSentries;
    int numNbrs;
    int voltage;
    int state;
    int sensorStatus;
    long iTime;

    public Node(int nodeID, int xCoord, int yCoord, int sentryID, int parentID,
                int numSentries, int numNbrs, int voltage, int state,
                int sensorStatus, long iTime) {

        this.nodeID = nodeID;
        this.loc = new Point(xCoord, yCoord);
        this.sentryID = sentryID;
        this.parentID = parentID;
        this.numSentries = numSentries;
        this.numNbrs = numNbrs;
        this.voltage = voltage;
        this.state = state;
        this.sensorStatus = sensorStatus;
        this.iTime = iTime;

    }

    public void update(int sentryID, int parentID, int numSentries, int numNbrs,
                       int voltage, int state, int sensorStatus, long iTime) {
        this.sentryID = sentryID;
        this.parentID = parentID;
        this.numSentries = numSentries;
        this.numNbrs = numNbrs;
        this.voltage = voltage;
        this.state = state;
        this.sensorStatus = sensorStatus;
        this.iTime = iTime;

    }

    public int getNodeID() {
        return nodeID;
    }
}
