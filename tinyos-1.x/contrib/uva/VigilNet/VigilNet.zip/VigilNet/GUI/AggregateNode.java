/**
 * <p>Title: SOWN Mote Field Setup</p>
 * <p>Description: Setup GUI sor SOWN Mote Field
 * called by Xetron Cardinal MissionGUI</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UVa</p>
 * @author Ting Yan, Tian He, etc.
 * @version 1.2
 */

import java.awt.*;
import java.util.*;

public class AggregateNode {
    // aggregate node information
    int nodeID;
    Point loc;
    int parentID;
    int numSentries;
    int numNodes;
    long voltage;

    static Random rand = new Random();

    Vector subNodes = new Vector();

    public int getAggregateNodeID() {
        return nodeID;
    }

    public void update(int parentID, int numSentries, long voltage) {
        this.parentID = parentID;
        this.numSentries = numSentries;
        this.voltage = voltage;
    }

    public AggregateNode(int nodeID, int xCoord, int yCoord, int parentID,
                         int numSentries, int numNodes, long voltage) {
        this.nodeID = nodeID;
        loc = new Point(xCoord, yCoord);
        this.parentID = parentID;
        this.numSentries = numSentries;
        this.numNodes = numNodes;
        this.voltage = voltage;
        for (int i = 0; i < numNodes; i++) {
            int x = 0;
            int y = 0;
            boolean foundx = false, foundy = false;
            while (!foundx) {
                x = xCoord + rand.nextInt() %
                    Constants.sentrySize; // - Constants.sentrySize / 2;
                if (x >= 0 && x < Constants.fieldLength) {
                    foundx = true;
                }
            }
            while (!foundy) {
                y = yCoord + rand.nextInt() %
                    Constants.sentrySize; // - Constants.sentrySize / 2;
                if (y >= 0 && y < Constants.fieldWidth) {
                    foundy = true;
                }
            }
            Point p = new Point(x, y);
            // System.out.println(x + " " + y);
            subNodes.addElement(p);
        }
    }

}
