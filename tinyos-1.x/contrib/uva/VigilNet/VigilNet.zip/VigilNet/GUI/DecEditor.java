/**
 * <p>Title: SOWN Mote Field Setup</p>
 * <p>Description: Setup GUI sor SOWN Mote Field
 * called by Xetron Cardinal MissionGUI</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UVa</p>
 * @author Ting Yan, Tian He, etc.
 * @version 1.2
 */

import javax.swing.*; //This is the final package name.
//import com.sun.java.swing.*; //Used by JDK 1.2 Beta 4 and all
//Swing releases before Swing 1.1 Beta 3.
import javax.swing.text.NumberFormatter;
import javax.swing.text.DefaultFormatterFactory;
import java.awt.event.*;
import java.awt.*;
import java.text.NumberFormat;
import java.text.DecimalFormat;

class DecEditor
    extends JFormattedTextField {

    NumberFormat decFormat;
    private Double minimum, maximum;
    private boolean DEBUG = false;

    public DecEditor(double min, double max, double defaultValue) {
        // super(new JFormattedTextField());
        // ftf = (JFormattedTextField)getComponent();
        minimum = new Double(min);
        maximum = new Double(max);

        //Set up the editor for the integer cells.
        // integerFormat = NumberFormat.getIntegerInstance();
        NumberFormatter decFormatter = new NumberFormatter(new DecimalFormat("#0.000"));
        decFormatter.setMinimum(minimum);
        decFormatter.setMaximum(maximum);

        setFormatterFactory(
            new DefaultFormatterFactory(decFormatter));
        setValue(new Double(defaultValue));
        // setHorizontalAlignment(JTextField.TRAILING);
        setFocusLostBehavior(JFormattedTextField.PERSIST);
        addFocusListener(new MyFocusListener());
    }

    class MyFocusListener
        implements FocusListener {
        public void focusGained(FocusEvent e) {
        }

        public void focusLost(FocusEvent e) {
            if (!isEditValid()) { //The text is invalid.
                if (userSaysRevert()) { //reverted
                    postActionEvent(); //inform the editor
                    grabFocus();
                }
                else {
                    grabFocus();
                }
            }
            else {
                try { //The text is valid,
                    commitEdit(); //so use it.
                    postActionEvent(); //stop editing
                }
                catch (java.text.ParseException exc) {}
            }

        }

    }

    /**
     * Lets the user know that the text they entered is
     * bad. Returns true if the user elects to revert to
     * the last good value.  Otherwise, returns false,
     * indicating that the user wants to continue editing.
     */
    protected boolean userSaysRevert() {
        Toolkit.getDefaultToolkit().beep();
        selectAll();
        Object[] options = {
            "Edit",
            "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(this),
            "The value must be an integer between "
            + minimum + " and "
            + maximum + ".\n"
            + "You can either continue editing "
            + "or revert to the last valid value.",
            "Invalid Text Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);

        if (answer == 1) { //Revert!
            setValue(getValue());
            return true;
        }
        return false;
    }
}
