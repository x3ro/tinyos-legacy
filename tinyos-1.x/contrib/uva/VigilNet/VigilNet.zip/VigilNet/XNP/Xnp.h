// $Id: Xnp.h,v 1.1.1.1 2004/07/13 21:42:45 th7c Exp $

#include <avr/eeprom.h> 

enum {
  AM_XnpMsg_ID = 47,
  EEPROM_ID = 47
};

void xnp_reboot() {
  int (*ptr)() = 0;
  ptr();
}
