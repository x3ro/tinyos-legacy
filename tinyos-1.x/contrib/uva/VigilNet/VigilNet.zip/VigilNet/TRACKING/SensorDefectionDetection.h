//Author: Liqian Luo
#ifndef __SENSORDEFECTIONDETECTION_H__
#define __SENSORDEFECTIONDETECTION_H__
#include "../INCLUDE/configuration.h"
typedef enum {
  MAG,
  PIR, 
  ACOUSTIC,
} sensorType_t;

enum {
  SENSOR_NUMBER = 3,

};
#endif
