#ifndef __STRUCTURES_H__
#define __STRUCTURES_H__
#include "SystemParameters.h"

typedef struct {
  uint16_t state1;
} state_t;

typedef struct {
  uint16_t ET_PHOSENSOR;
  uint8_t number;
} struct_conditions;

typedef struct {
  Pair_int16_t ET_POSITION;
  uint8_t confidence[TARGET_TYPE_NUMBER];
  uint8_t sensorState;
} Attributes;

typedef struct {
  Pair_int16_t aggregatePosition;
  uint8_t aggregateConfidence[TARGET_TYPE_NUMBER];
  uint8_t degree;
} AggrAttributes;

typedef struct {
  uint16_t leaderID;
  uint16_t groupID;
  uint8_t groupAge;
  //<--1
  uint8_t groupConfidence[TARGET_TYPE_NUMBER];
  //1-->
} GMInfo;

typedef struct {
  GMInfo GMInformation;
  uint16_t nodeID;
  Attributes attributes;
} AttrReport;

typedef struct {
  uint16_t groupID;
  uint16_t nodeID;
  AggrAttributes aggrAttributes;
} AggrReport;

typedef struct {
  char data[RCREPORT_LENGTH];
} RCReport;

typedef struct {
  GMInfo GMInformation; 
//  uint16_t objectID;
//<--1
//  uint16_t leaderID;
//1-->
  Pair_int16_t position;
  uint32_t timeStamp;
  uint8_t degreeOfAggregation;
  uint8_t aggregateConfidence[TARGET_TYPE_NUMBER];
} baseStation_reportPosition_struct; //19byte

typedef struct {
  uint16_t objectID;
  uint16_t leaderID;
  Pair_int16_t position;
  uint8_t degreeOfAggregation;
  uint8_t degreeOfMag;
  uint8_t degreeOfPIR;
  uint8_t degreeOfAccoustic;
} PC_reportPosition_struct;

#endif
