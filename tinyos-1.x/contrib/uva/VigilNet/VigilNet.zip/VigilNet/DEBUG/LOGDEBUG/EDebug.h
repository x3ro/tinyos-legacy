enum {
   MY_AREA = 2 //unique("ByteEEPROM"),
};
