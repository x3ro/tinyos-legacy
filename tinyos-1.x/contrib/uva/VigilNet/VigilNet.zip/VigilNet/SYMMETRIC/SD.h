/* "Copyright (c) 2000-2004 University of Virginia.  
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF VIRGINIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * VIRGINIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF VIRGINIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF VIRGINIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 */

// Authors: Gary Zhou,Tian He 
//$Id: SD.h,v 1.1.1.1 2004/07/13 21:42:43 th7c Exp $

#ifndef __SD_H__
#define __SD_H__

enum{
	SD_PAYLOAD_SIZE	= 18,
	MAX_NEIGHBOR 		= 40, // if nodes are put very close, there maybe error due to the size of the NT
   MAX_SD_BUFFER_SIZE = (MAX_NEIGHBOR+8)/9,
	AM_SD_BEACON_MSG 	= 60	
};

typedef struct{
	uint16_t 	senderID;
	uint8_t   TotalSize; /* totoal number of ID in this round */
	uint8_t   size;	 /* totoal number of ID in this outging packet */
} SD_HEADER;

typedef struct{
	SD_HEADER 	header;
	uint8_t 	data[SD_PAYLOAD_SIZE]; // the first uint8_t is the # of following IDs; Then all the following IDs.
} SD_PACKET;

typedef struct{
	uint16_t	neighborID[MAX_NEIGHBOR]; // 0xffff means that it's undefined
	uint8_t		symmChannel[MAX_NEIGHBOR];
	uint8_t		asymmChannel[MAX_NEIGHBOR];
	uint8_t		noChannel[MAX_NEIGHBOR];
	uint8_t		currStatus[MAX_NEIGHBOR];
	uint8_t     aliveLastTime[MAX_NEIGHBOR];	
	/*
		0 --- 	noChannel;
		1 ---	asymmChannel;
		2 ---	symmeChannel;
	*/  
} NEIGHBOR_TABLE;

#endif


