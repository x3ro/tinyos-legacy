/* "Copyright (c) 2000-2004 University of Virginia. 
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF VIRGINIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * VIRGINIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF VIRGINIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF VIRGINIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 */

// Author: Radu Stoleru
// Date: 3/26/2004

#ifndef __LOCALIZATION_H__
#define __LOCALIZATION_H__

typedef enum {
  FAKE,
  REAL
} LocalizationType;

typedef enum {
  UNINITIALIZED,
  INITIALIZED
} LocalizationStatus;

typedef enum {
  //  READ_LOCATION,
  // READ_CONFIG,
  READ_FLASH,
  WAIT_FOR_GPS_BEACON,
  INITIALIZATION_ENDS,
} InitializationType;

typedef enum {
  ON_AT_DEPLOYMENT,
  ON_ALL_THE_TIME
} DeploymentType;

typedef enum {
  GPS_BUFFER_SIZE                 = 4,
  MAX_NUM_REPORTS_PER_GPS         = 8,
  MULT_FACTOR                     = 10,
  DEFAULT_UPPER_BOUND             = 35,
  DEFAULT_DELTA_RSSI              = 5,
  DEFAULT_DEPLOYMENT_TYPE         = ON_AT_DEPLOYMENT,
  WAIT_FOR_GPS_BEACON_DURATION    = 5000,
  LOCAL_FLASH_POOL                = unique("ByteEEPROM")
} Constants;

typedef  int16_t LocalCoord;

// 8 bytes, 1000s of a second
typedef  struct {
  int32_t 	latitude;
  int32_t       longitude;
} GpsCoord;

// 11 bytes
typedef  struct {
  uint8_t   latDegree;
  float     latMinute;   //decimal minutes
  uint8_t   lonDegree;
  float     lonMinute;   //decimal minutes
  uint8_t   NSEWind;
} NMEAGpsCoord;

// 7 bytes
typedef struct {
  bool isValid;
  LocalCoord x;
  LocalCoord y;
  uint16_t  signalStrength;
} GpsReading;

// Messaging Data Structures
typedef enum {
  INIT_LOCALIZATION        = 0,  // payload shown below InitLocalizationPacket
  INIT_GPS                 = 1,  // payload shown below InitGpsPacket
  RESET                    = 2,  // just a command. Empty payload.
  HELP_REQUEST             = 3,  // just a command. Empty payload.
  HELP_REPLY               = 4,  // payload shown below InitLocalizationPacket
  SET_CONFIG               = 11, // payload shown below InitConfigPacket
  RESET_CONFIG             = 12, // just a command. Empty payload.

  // debugging packet types
  DUMP_STATE               = 5,  // Debugging packet
  DUMP_STATE_REP           = 6,  // debugging packet
  DUMP_INIT_GPS_BUFFER     = 7,  // Debugging packet
  DUMP_INIT_GPS_BUFFER_REP = 8,  // Debugging packet

} GpsPacketType;

// 23 bytes
typedef struct GpsPacket {
  uint16_t        sender;
  uint8_t         type;
  char            payload[20];
} GpsPacket;

typedef struct {
  GpsCoord referencePoint;
  LocalCoord x;
  LocalCoord y;
} InitLocalizationPacket;

typedef struct {
  GpsCoord referencePoint;
  uint8_t sendingPower;
  uint16_t sendingPeriod; // in 0.1sec.
} InitGpsPacket;

typedef struct {
  LocalCoord x;
  LocalCoord y;	
  bool isValid;
  uint8_t bufferNumber;  
  uint16_t signalStrength;  
} InitGpsBufferPacket;  

typedef struct {
  uint8_t deploymentType;
  uint16_t upperBoundRSSI;
  uint16_t deltaRSSI;
} InitConfigPacket;

#endif
