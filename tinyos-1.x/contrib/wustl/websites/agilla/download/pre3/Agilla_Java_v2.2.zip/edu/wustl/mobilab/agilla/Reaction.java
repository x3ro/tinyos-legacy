/**
 * Reaction.java
 *
 * @author Created by Omnicore CodeGuide
 */

package edu.wustl.mobilab.agilla;

public class Reaction
{
	public static final int ONCE = 0;
	public static final int ONCE_PER_TUPLE = 1;
	
	int type;
	Tuple t;
	ReactionListener l;
	
	public Reaction(int type, Tuple t, ReactionListener l) {
		this.type = type;
		this.t = t;
		this.l = l;
	}
	
	public boolean equals(Object o) {
		if (o instanceof Reaction) {
			Reaction r = (Reaction)o;
			return r.type == type && r.t.equals(t) && r.l.equals(l);
		} else
			return false;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer("REACTION: " + type);
		sb.append(t.toString());
		sb.append(l.toString());
		return sb.toString();
	}
}

