/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis 
 * By Chien-Liang Fok.
 * 
 * Washington University states that Agilla is free software; 
 * you can redistribute it and/or modify it under the terms of 
 * the current version of the GNU Lesser General Public License 
 * as published by the Free Software Foundation.
 * 
 * Agilla is distributed in the hope that it will be useful, but 
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF 
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO 
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO 
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF 
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER 
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS 
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS", 
 * OR OTHER HARMFUL CODE.  
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR 
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF 
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to 
 * indemnify, defend, and hold harmless WU, its employees, officers and 
 * agents from any and all claims, costs, or liabilities, including 
 * attorneys fees and court costs at both the trial and appellate levels 
 * for any loss, damage, or injury caused by your actions or actions of 
 * your officers, servants, agents or third parties acting on behalf or 
 * under authorization from you, as a result of using Agilla. 
 *
 * See the GNU Lesser General Public License for more details, which can 
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
/**
 * @author Chien-Liang Fok
 */
package edu.wustl.mobilab.agilla;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import edu.wustl.mobilab.agilla.variables.*;

public class GridSizeDialog extends JDialog implements
	java.io.Serializable, AgillaConstants
{
	private JTextField 					xSize, ySize;
	private JButton 					doneButton, cancelButton;
	
	public GridSizeDialog(final AgentInjector owner)
	{
		super(owner, "Grid Size Configuration", true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		JPanel instrPanel = new JPanel();
		instrPanel.add(new JLabel("Enter grid size:"));
		
		xSize = new JTextField(Integer.toString(AgillaLocation.NUM_COLUMNS), 5);
		ySize = new JTextField(Integer.toString(AgillaLocation.NUM_ROWS), 5);
		
		JPanel gridPanel = new JPanel();
		gridPanel.setLayout(new GridLayout(2,2));
		gridPanel.add(new JLabel("X length:"));
		gridPanel.add(xSize);
		gridPanel.add(new JLabel("Y length:"));
		gridPanel.add(ySize);
		
		doneButton = new JButton("OK");
		doneButton.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						try {
							AgillaLocation.NUM_COLUMNS = Integer.valueOf(xSize.getText()).intValue();
							AgillaLocation.NUM_ROWS = Integer.valueOf(ySize.getText()).intValue();
							owner.updateLocBox();
							setVisible(false);
							dispose();
						} catch(Exception ecp) {
							ecp.printStackTrace();
						}
						
					}
				});
		
		cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
						dispose();
					}
				});
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		buttonPanel.add(doneButton);
		buttonPanel.add(cancelButton);
		
		getContentPane().add(instrPanel, BorderLayout.NORTH);
		getContentPane().add(gridPanel, BorderLayout.CENTER);
		getContentPane().add(buttonPanel,BorderLayout.SOUTH);
		pack();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = this.getSize();
		if (frameSize.height > screenSize.height)
		{
			frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width)
		{
			frameSize.width = screenSize.width;
		}
		setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
		setVisible(true);
	}
	
	
}
