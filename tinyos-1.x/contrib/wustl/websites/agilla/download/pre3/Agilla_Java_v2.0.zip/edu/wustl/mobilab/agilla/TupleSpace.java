// $Id: TupleSpace.java,v 1.6.2.1 2005/05/10 22:41:59 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
package edu.wustl.mobilab.agilla;

import java.util.*;
import java.io.*;
import edu.wustl.mobilab.agilla.messages.*;
import edu.wustl.mobilab.agilla.variables.*;
/**
 * Interfaces with the tuplespace on the basestation mote.
 * CURRENTLY ASSUMES SINGLE-THREADED OPERATION!!!
 *
 * @author Chien-Liang Fok
 */
public class TupleSpace implements AgillaConstants, MessageListenerJ {
	public static final int REMOVE = 0;
	public static final int NOREMOVE = 1;
	
	private SNInterface sni;
	private AgillaTSResMsgJ results;
	private TimeoutTimer timer;
	private Vector ts;
	private Object blocked = new Object(), waiting = new Object();
	
	public TupleSpace(SNInterface sni) {
		this.sni = sni;
		ts = new Vector();
		sni.registerListener(new AgillaTSResMsgJ(), this);
		sni.registerListener(new AgillaTSReqMsgJ(), this);
		//sni.registerListener(new AgillaTSModMsgJ(), this);
	}
	
	
	//------------------------------------------------------------------------
	// BEGIN LOCAL TS OPERATIONS
	public void out(Tuple t) {
		ts.add(t);
		synchronized(blocked) {
			blocked.notifyAll();
		}
	}
	
	public Tuple inp(Tuple template) {
		for (int i = 0; i < ts.size(); i++) {
			Tuple tuple = (Tuple)ts.get(i);
			Debugger.dbg("||----> Tuplespace.inp", "Comparing:\n" + template + "\nwith:\n" + tuple);
			if (template.matches(tuple)) {
				Debugger.dbg("||----> Tuplespace.inp", "Match!");
				ts.remove(i);
				return tuple;
			}
		}
		return null;
	}
	
	public Tuple rdp(Tuple template) {
		for (int i = 0; i < ts.size(); i++) {
			Tuple tuple = (Tuple)ts.get(i);
			if (template.matches(tuple))
				return tuple;
		}
		return null;
	}
	
	
	/**
	 * Returns a tuple matching the specified template.  If no match is found,
	 * block until one is found. If more than one match is found, choose and
	 * return one randomly.  The tuple is removed from the tuple space.
	 */
	public Tuple in(Tuple template) {
		Debugger.dbg("TupleSpace.in", "||----> Performing an in() operation.");
		Tuple result = inp(template);
		if (result != null) {
			return result;
		} else {
			while(true) {
				synchronized(blocked) {
					try {
						Debugger.dbg("||----> Tuplespace.in", "BLOCKED while doing an in().");
						blocked.wait();
						Debugger.dbg("||----> Tuplespace.in", "UNBLOCKED while doing an in().");
					} catch(Exception e) {
						e.printStackTrace();
					}
					Debugger.dbg("||----> Tuplespace.in", "Trying to find a match.");
					result = inp(template);
					if (result != null)
						return result;
				}
			}
		}
	}
	
	/**
	 * Returns a tuple matching the specified template.  If no match is found,
	 * block until one is found. If more than one match is found, choose and
	 * return one randomly.  The tuple is kept in the tuple space.
	 */
	public Tuple rd(Tuple template) {
		Debugger.dbg("TupleSpace.rd", "Performing an rd() operation.");
		Tuple result = rdp(template);
		if (result != null)
			return result;
		else {
			while(true) {
				synchronized(blocked) {
					try {
						Debugger.dbg("Tuplespace.rd", "Blocking while doing an rd().");
						blocked.wait();
					} catch(Exception e) {
						e.printStackTrace();
					}
					result = rdp(template);
					if (result != null)
						return result;
				}
			}
		}
	}
	//------------------------------------------------------------------------
	
	//net.tinyos.oscope.oscilloscope oscope = null;
	//net.tinyos.oscope.OscopeMsg oscopeMsg;
	
	/*public void showOscope() {
	 try {
	 net.tinyos.oscope.oscilloscope.main(new String[] {});
	 oscope = net.tinyos.oscope.oscilloscope.app;
	 oscopeMsg = new net.tinyos.oscope.OscopeMsg();
	 oscopeMsg.set_sourceMoteID(1);
	 oscopeMsg.set_channel(0);
	 } catch(IOException e) {
	 e.printStackTrace();
	 }
	 //
	 }*/
	
	//private int numMsgsRcvd = 0;
	private void processRequest(AgillaTSReqMsgJ reqMsg) {
		/*if (oscope != null) {
		 if (reqMsg.getOp() == AgillaOpcodes.OProut) {
		 Tuple t = reqMsg.getTuple();
		 AgillaReading reading = (AgillaReading)t.getField(0);
		 AgillaValue value = (AgillaValue)t.getField(1);
		 oscopeMsg.set_lastSampleNumber(value.getValue());
		 oscopeMsg.setElement_data(numMsgsRcvd, reading.getReading());
		 numMsgsRcvd++;
		 if (numMsgsRcvd == 10) {
		 System.out.println("Received 10 messages, passing it to graph panel");
		 oscope.getPanel().oscopeReceived(0,oscopeMsg);
		 numMsgsRcvd = 0;
		 } else
		 System.out.println("received " + numMsgsRcvd + " messages");
		 
		 } else
		 System.out.println("operation was not rout");
		 } else
		 System.out.println("oscope is null");
		 */
		switch(reqMsg.getOp()) {
			case AgillaOpcodes.OProut:
				Tuple t = reqMsg.getTuple();
				System.out.println("OUTing tuple: "  + t);
				out(t);
				try {
					sni.send(new AgillaTSResMsgJ(reqMsg.getReplyLoc(),
												 reqMsg.getOp(),
												 SUCCESS,
												 reqMsg.getTuple()));
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
				break;
			case AgillaOpcodes.OPrrdp:
			case AgillaOpcodes.OPrinp:
				Tuple template = reqMsg.getTuple();
				Tuple result = null;
				if (reqMsg.getOp() == AgillaOpcodes.OPrinp)
					result = inp(template);
				else
					result = rdp(template);
				AgillaTSResMsgJ resMsg = null;
				if (result == null) {
					resMsg = new AgillaTSResMsgJ(reqMsg.getReplyLoc(),
												 reqMsg.getOp(),
												 FAIL,
												 null);
				} else {
					resMsg = new AgillaTSResMsgJ(reqMsg.getReplyLoc(),
												 reqMsg.getOp(),
												 SUCCESS,
												 result);
				}
				try {
					sni.send(resMsg);
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
				break;
			default:
				System.out.println("TupleSpace: Invalid Request " + reqMsg);
				resMsg = new AgillaTSResMsgJ(reqMsg.getReplyLoc(),
											 reqMsg.getOp(),
											 FAIL,
											 null);
				try {
					sni.send(resMsg);
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
		}
	}
	
	public void messageReceived(int to, MessageJ m) {
		try {
			if (m.getType() == AM_AGILLATSRESMSG) {
				if (Debugger.debug)
					System.out.println("TupleSpace.messageReceived: Got a results message.");
				results = (AgillaTSResMsgJ)m;
				synchronized(waiting) {
					if (timer != null) timer.kill();
					waiting.notifyAll();
				}
			} else if (m.getType() == AM_AGILLATSREQMSG) {
				AgillaTSReqMsgJ reqMsg = (AgillaTSReqMsgJ)m;
				//System.out.println("Received a TS Request Msg:\n" + reqMsg);
				processRequest(reqMsg);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Inserts a tuple into the tuple space.  This may unblock a
	 * blocked operation.
	 */
	public boolean rout(Tuple t, AgillaLocation dest) {
		AgillaTSReqMsgJ request = new AgillaTSReqMsgJ(
			dest,
			new AgillaLocation(UART_X, UART_Y),
			AgillaOpcodes.OProut, t);
		try {
			sni.send(request);
		} catch(IOException e) {
			e.printStackTrace();
			return false;
		}
		if (Debugger.debug)
			System.out.println("TupleSpace.rout: Request sent, awaiting reply.");
		synchronized(waiting) {
			if (results == null){
				timer = new TimeoutTimer(waiting, AGILLA_RTS_TIMEOUT);
				try {
					waiting.wait();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (Debugger.debug)
			if (results != null)
				System.out.println("TupleSpace.rout: Reply received, success = " + results.isSuccess());
			else
				System.out.println("TupleSpace.rout: Operation timed out");
		if (results != null)
			return results.isSuccess();
		else
			return false;
	}
	
	
	
	private Tuple doMonoOp(Tuple template, AgillaLocation dest, int type) {
		AgillaTSReqMsgJ request;
		if (type == REMOVE)
			request = new AgillaTSReqMsgJ(
				dest,
				new AgillaLocation(UART_X, UART_Y),
				AgillaOpcodes.OPrinp,
				template);
		else
			request = new AgillaTSReqMsgJ(
				dest,
				new AgillaLocation(UART_X, UART_Y),
				AgillaOpcodes.OPrrdp,
				template);
		
		System.out.println("||----> Tuplespace doMonoOp: request = " + request
							   + ", dest = " + dest);
		
		try {
			System.out.println("||----> Tuplespace doMonoOp: Sent inp or rdp request.");
			sni.send(request);
		} catch(IOException e) {
			e.printStackTrace();
			return null;
		}
		
		
		synchronized(waiting) {
			if (results == null){
				timer = new TimeoutTimer(waiting, AGILLA_RTS_TIMEOUT);
				try {
					System.out.println("||----> Tuplespace doMonoOp: Waiting for results.");
					waiting.wait();
					timer.kill();
				} catch(Exception e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("||----> Tuplespace doMonoOp: Got results b/f waiting.");
			}
		}
		
		if (results != null && results.isSuccess()) {
			System.out.println("||----> Tuplespace doMonoOp: Got results.");
			Tuple rTuple =  results.getTuple();
			results = null;
			return rTuple;
		} else {
			System.out.println("||----> Tuplespace doMonoOp: results is null or results not success.");
			return null;
		}
	}
	
	/**
	 * Returns a tuple matching the specified template.  If no match is found
	 * return null.  If more than one match is found, choose and return one
	 * randomly.  The tuple is removed from the tuple space.
	 */
	public Tuple rinp(Tuple template, AgillaLocation dest) {
		return doMonoOp(template, dest, REMOVE);
	}
	
	/**
	 * Returns a tuple matching the specified template.  If no match is found
	 * return null.  If more than one match is found, choose and return one
	 * randomly.  The tuple is kept in the tuple space.
	 */
	public Tuple rrdp(Tuple template, AgillaLocation dest) {
		return doMonoOp(template, dest, NOREMOVE);
	}
	
//	private Tuple[] doMacroOp(Tuple template, int type) {
//		Vector result = new Vector();
//		synchronized(ts) {
//			for (int i = 0; i < ts.size(); i++) {
//				Tuple t = (Tuple)ts.get(i);
//				if (template.matches(t)) {
//					if (type == REMOVE) {
//						ts.remove(i);
//						result.add(t);
//					} else
//						result.add(t.deepClone());
//				}
//			}
//		}
//		Tuple[] tuples = new Tuple[result.size()];
//		for (int i = 0; i < tuples.length; i++) {
//			tuples[i] = (Tuple)result.get(i);
//		}
//		return tuples;
//	}
	
	/**
	 * Returns all tuples matching the specified template.  The tuples are
	 * removed from the tuple space.
	 */
//	public Tuple[] inpg(Tuple template) {
//		return doMacroOp(template, REMOVE);
//	}
	
	/**
	 * Returns all tuples matching the specified template.  The tuples are
	 * removed from the tuple space.
	 */
//	public Tuple[] rdpg(Tuple template) {
//		return doMacroOp(template, NOREMOVE);
//	}
	
	/**
	 * Remove a tuples beloning to the specified agent.
	 */
//	public void flush(AgentID aID) {
//		synchronized(ts) {
//			for (int i = 0; i < ts.size(); i++) {
//				Tuple t = (Tuple)ts.get(i);
//				if (t.isOwnedBy(aID)) {
//					ts.remove(i);
//					i--;
//				}
//			}
//		}
//	}
	
	/**
	 * Returns the number of tuples that match the specified template.
	 */
//	public int tcount(Tuple template) {
//		int result = 0;
//		synchronized(ts) {
//			for (int i = 0; i < ts.size(); i++) {
//				Tuple t = (Tuple)ts.get(i);
//				if (template.matches(t)) {
//					result++;
//				}
//			}
//		}
//		return result;
//	}
}

