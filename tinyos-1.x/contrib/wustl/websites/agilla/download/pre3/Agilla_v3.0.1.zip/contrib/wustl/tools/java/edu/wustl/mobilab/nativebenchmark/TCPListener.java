package edu.wustl.mobilab.nativebenchmark;

public interface TCPListener {
	public void messageReceived(Object o);
}
