// $Id: ProgramTokenizer.java,v 1.4 2005/03/28 23:09:47 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
// $Id: ProgramTokenizer.java,v 1.4 2005/03/28 23:09:47 liang Exp $

/*									tab:4
 * "Copyright (c) 2000-2003 The Regents of the University  of California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 * Copyright (c) 2002-2003 Intel Corporation
 * All rights reserved.
 *
 * This file is distributed under the terms in the attached INTEL-LICENSE
 * file. If you do not find these files, copies can be found by writing to
 * Intel Research Berkeley, 2150 Shattuck Avenue, Suite 1300, Berkeley, CA,
 * 94704.  Attention:  Intel License Inquiry.
 */
/* Authors:	Phil Levis <pal@cs.berkeley.edu>
 * Date:        Aug 8 2002
 * Desc:        Assembly program tokenizer for TinyOS VMs.
 *
 */

/**
 * @author Phil Levis <pal@cs.berkeley.edu>
 */


package edu.wustl.mobilab.agilla;

import java.io.*;
import java.util.*;
import javax.swing.*;

/**
 * This class reads in an ASCII assembly program and tokenizes it into
 * individual instructions. If an instruction has an embedded operand,
 * that operand can be fetched with <tt>argument()</tt>.
 *
 */

public class ProgramTokenizer implements AgillaConstants, InstructionAnalyzer {

	/**
	 *  Maps a string label to its equivalent program counter (PC).
	 * */
	private Hashtable labelTable = new Hashtable();

	/**
	 * The program.
	 */
    private Vector progVec = new Vector();

	/**
	 *  Holds the instructions with labels that need to be assigned a PC.
	 */
	private Vector missingLabels = new Vector();
	private int currPos = 0, pc = 0;
	private AgillaAssembler assembler;

    public ProgramTokenizer(Reader reader, AgillaAssembler assembler) throws IOException {
		this.assembler = assembler;
		StreamTokenizer tokenizer = new StreamTokenizer(reader);
		tokenizer.resetSyntax();
		tokenizer.slashSlashComments(true);
		tokenizer.slashStarComments(true);
		tokenizer.wordChars('A', 'Z');
		tokenizer.wordChars('a', 'z');
		tokenizer.wordChars('_', '_');
		tokenizer.whitespaceChars(0, 32); //Unreadable chars and whitespace
		tokenizer.whitespaceChars(127, 127); //DEL
		tokenizer.parseNumbers();
		tokenizer.eolIsSignificant(true);
		tokenizer.commentChar('%');
		parseProgram(tokenizer);
    }

	private boolean nxtTokenIsInstr(StreamTokenizer tokenizer) throws java.io.IOException {
		int ttype = tokenizer.nextToken();
		if (ttype == StreamTokenizer.TT_WORD) {
			if (assembler.isInstruction(tokenizer.sval)) {
				tokenizer.pushBack();
				return true;
			}
		}
		return false;
	}

	private void parseProgram(StreamTokenizer tokenizer) throws java.io.IOException {
		int ttype;
		boolean acceptLabel = true;  // a label can only be accepted at the beginning of a line

		while ((ttype = tokenizer.nextToken()) != StreamTokenizer.TT_EOF){

			if (ttype == StreamTokenizer.TT_WORD) {
				if (assembler.isInstruction(tokenizer.sval))
					parseInstruction(tokenizer);
				else {
					String sval = tokenizer.sval;
					//System.out.println("sval = " + sval + ", acceptLabel = " + acceptLabel);
					if (acceptLabel && nxtTokenIsInstr(tokenizer)) {
						//System.out.println("Saving label " + sval + " as pc = " + pc);
						labelTable.put(sval, new Integer(pc));
					} else
						throw new IOException("Syntax Error on line " + tokenizer.lineno() + ", acceptLabel = " + acceptLabel);
				}
			}
			acceptLabel = ttype == StreamTokenizer.TT_EOL;
		}
		getMissingLabels();
	}

	private void getMissingLabels() throws java.io.IOException {
		Integer value;
		for (int i = 0; i < missingLabels.size(); i++) {
			Instruction instr = (Instruction)missingLabels.get(i);
			value = (Integer)labelTable.get(instr.label);
			if (value != null) {
				int argi = value.intValue();

				// size check
				if (instr.opcode.equals("rjumpc") || instr.opcode.equals("rjump")) {
					argi -= instr.pc;
					if (argi > 15 || argi < -15) {
						JOptionPane.showMessageDialog(null, "rJump or rjumpc out of bounds (" + instr.label + "=" + argi + "), pc = " + instr.pc, "Error", JOptionPane.ERROR_MESSAGE);
						throw new IOException("rJump out of bounds.");
					}
				} else if (instr.opcode.equals("pushc")) {
					if (argi < 0 || argi > 63) {
						JOptionPane.showMessageDialog(null, "Pushc out of bounds (" + instr.label + "=" + argi + "), pc = " + instr.pc, "Error", JOptionPane.ERROR_MESSAGE);
						throw new IOException("pushc out of bounds.");
					}
				} else if (instr.opcode.equals("pushcl")) {
					if (argi >= 65536) {
						JOptionPane.showMessageDialog(null, "Pushcl out of bounds (" + instr.label + "=" + argi + "), pc = " + instr.pc, "Error", JOptionPane.ERROR_MESSAGE);
						throw new IOException("pushl out of bounds.");
					}
				}

				// save the argument
				if (!instr.opcode.equals("pushcl")) {
					byte arg = (byte)argi;
					arg &= getArgMask(instr.opcode);
					instr.arg = new Argument(arg, (byte)0);
				} else {
					byte b1 = (byte)(argi >> 8);
					byte b2 = (byte)argi;
					instr.arg = new Argument(b1, b2);
				}
			} else
				throw new IOException("Unknown label: " + instr.label + ", pc = " + instr.pc);
		}
	}

	/**
	 *  Takes the next instruction and its arguments and creates an Instruction
	 * object that encapsulates them.  Inserts them into the program vector.
	 */
	private void parseInstruction(StreamTokenizer tokenizer) throws java.io.IOException {
		String opcode = tokenizer.sval;
		Instruction instr = new Instruction(opcode, tokenizer.lineno(), pc++);

		//System.out.println("Parsing Instruction: " + tokenizer.sval);

		if (opcode.equals("pushn")) {
			tokenizer.nextToken();
			if (tokenizer.ttype == StreamTokenizer.TT_WORD)
				instr.arg = string2byte(tokenizer.sval);
			else
				instr.arg = string2byte(""+tokenizer.nval);
			pc += 2;
		} else if (hasEmbeddedOperand(opcode)) {
			if (opcode.equals("pushrt")) {
				//System.out.println("opcode is pushrt");
				if (tokenizer.nextToken() != StreamTokenizer.TT_WORD) {
					throw new IOException("Illegal pushrt operand.");
				}
				String arg = tokenizer.sval;
				if (arg.toLowerCase().equals("photo")) {
					instr.arg = new Argument((byte)1, (byte)0);
				} else if (arg.toLowerCase().equals("temp") || arg.toLowerCase().equals("temperature")) {
					instr.arg = new Argument((byte)2, (byte)0);
				} else if (arg.toLowerCase().equals("mic") || arg.toLowerCase().equals("microphone")) {
					instr.arg = new Argument((byte)3, (byte)0);
				} else if (arg.toLowerCase().equals("magx") || arg.toLowerCase().equals("magnometerx")) {
					instr.arg = new Argument((byte)4, (byte)0);
				} else if (arg.toLowerCase().equals("magy") || arg.toLowerCase().equals("magnometery")) {
					instr.arg = new Argument((byte)5, (byte)0);
				} else if (arg.toLowerCase().equals("accelx") || arg.toLowerCase().equals("accelerometerx")) {
					instr.arg = new Argument((byte)6, (byte)0);
				} else if (arg.toLowerCase().equals("accely") || arg.toLowerCase().equals("accelerometery")) {
					instr.arg = new Argument((byte)7, (byte)0);
				} else
					throw new IOException("Illegal pushrt operand: " + arg);

			} else if (opcode.equals("pusht")) {
				//System.out.println("opcode is pusht");
				if (tokenizer.nextToken() != StreamTokenizer.TT_WORD) {
					throw new IOException("Illegal pusht operand.");
				}
				String arg = tokenizer.sval;

				if (arg.toLowerCase().equals("any")) {
					instr.arg = new Argument((byte)OP_PUSHT_ARG_ANY, (byte)0);
				} else if (arg.toLowerCase().equals("agentid")) {
					instr.arg = new Argument((byte)OP_PUSHT_ARG_AGENTID, (byte)0);
				} else if (arg.toLowerCase().equals("string")) {
					instr.arg = new Argument((byte)OP_PUSHT_ARG_STRING, (byte)0);
				} else if (arg.toLowerCase().equals("type")) {
					instr.arg = new Argument((byte)OP_PUSHT_ARG_TYPE, (byte)0);
				} else if (arg.toLowerCase().equals("value")) {
					instr.arg = new Argument((byte)OP_PUSHT_ARG_VALUE, (byte)0);
				} else if (arg.toLowerCase().equals("location")) {
					instr.arg = new Argument((byte)OP_PUSHT_ARG_LOCATION, (byte)0);
				} else
					throw new IOException("ERROR: Invalid pusht operand: " + arg);

			} else if (opcode.equals("pushcl")) {
				pc += 2;
				int ttype = tokenizer.nextToken();
				if (ttype == StreamTokenizer.TT_NUMBER) {
					int arg = (int)tokenizer.nval;
					//System.out.println("pushcl arg = " + arg + ", byte 1 = " + (byte)(arg & 0xff)
					//			  + ", byte 2 = " + (byte)(arg >> 8 & 0xff));
					instr.arg = new Argument((byte)(arg >> 8 & 0xff), (byte)(arg & 0xff));
				} else if (ttype == StreamTokenizer.TT_WORD) {
					instr.label = tokenizer.sval;
					missingLabels.add(instr);
				}

			} else if (opcode.equals("pushloc")) {
				pc += 2;
				int ttype;
				byte arg1, arg2;

				ttype = tokenizer.nextToken();
				if (ttype == StreamTokenizer.TT_NUMBER)
					arg1 = (byte)((int)tokenizer.nval & 0xff);
				else if (ttype == StreamTokenizer.TT_WORD) {
					if (tokenizer.sval.toLowerCase().equals("uart_x"))
						arg1 = UART_X;
					else
						throw new IOException("ERROR: Invalid pushloc operand1.");
				} else throw new IOException("ERROR: Invalid pushloc operand1.");

				ttype = tokenizer.nextToken();
				if (ttype == StreamTokenizer.TT_NUMBER)
					arg2 = (byte)((int)tokenizer.nval & 0xff);
				else if (ttype == StreamTokenizer.TT_WORD) {
					if (tokenizer.sval.toLowerCase().equals("uart_y"))
						arg2 = UART_Y;
					else
						throw new IOException("ERROR: Invalid pushloc operand2.");
				} else throw new IOException("ERROR: Invalid pushloc operand2.");

				instr.arg = new Argument(arg1, arg2);
			}
			else {

				int ttype = tokenizer.nextToken();
				if (ttype == StreamTokenizer.TT_NUMBER) {
					int arg = (int)tokenizer.nval;
					//System.out.println("opcode = " + opcode + " arg = " + arg + " argMask = " + getArgMask(opcode));
					if (arg > getArgMask(opcode)) {
						throw new IOException("ERROR: operand " + arg + " too large, max is " + getArgMask(opcode));
					} else {
						arg &= getArgMask(opcode);
						instr.arg = new Argument((byte)arg, (byte)0);
					}
				} else if (ttype == StreamTokenizer.TT_WORD) {
					String arg = tokenizer.sval;
					if (opcode.equals("pushc")) {
						//System.out.println("opcode is pushc, arg = " + arg);

						if (arg.toLowerCase().equals("photo") || arg.toLowerCase().equals("light")) {
							instr.arg = new Argument((byte)AGILLA_STYPE_PHOTO, (byte)0);

						} else if (arg.toLowerCase().equals("temp") || arg.toLowerCase().equals("temperature")) {
							instr.arg = new Argument((byte)AGILLA_STYPE_TEMP, (byte)0);
							//System.out.println("argument is temperature");
						} else if (arg.toLowerCase().equals("mic") || arg.toLowerCase().equals("microphone"))
							instr.arg = new Argument((byte)AGILLA_STYPE_MIC, (byte)0);

						else if (arg.toLowerCase().equals("magnometerx") || arg.toLowerCase().equals("magx"))
							instr.arg = new Argument((byte)AGILLA_STYPE_MAGX, (byte)0);

						else  if (arg.toLowerCase().equals("magnometery") || arg.toLowerCase().equals("magy"))
							instr.arg = new Argument((byte)AGILLA_STYPE_MAGY, (byte)0);

						else  if (arg.toLowerCase().equals("accelerometerx") || arg.toLowerCase().equals("accelx"))
							instr.arg = new Argument((byte)AGILLA_STYPE_ACCELX, (byte)0);

						else  if (arg.toLowerCase().equals("accelerometery") || arg.toLowerCase().equals("accely"))
							instr.arg = new Argument((byte)AGILLA_STYPE_ACCELY, (byte)0);

						else {
							instr.label = tokenizer.sval;
							missingLabels.add(instr);
						}
					} else {
						instr.label = tokenizer.sval;
						missingLabels.add(instr);
					}
				}
			}
//			if (instr.arg != null)
//				System.out.println("\tOperand: " + instr.arg);
//			else
//				System.out.println("\tlabel: " + instr.label);
		}
		progVec.add(instr);
	}

	public boolean hasEmbeddedOperand(String instr) {
		return (isEclass(instr) ||
					instr.equals("rjumpc") ||
					instr.equals("rjump") ||
					instr.equals("getvar") ||
					instr.equals("setvar") ||
					instr.equals("pushc")  ||
					instr.equals("pushrt") ||
					instr.equals("pusht"));
	}

	public byte getArgMask(String instr) {
		if (instr.equals("rjumpc") || instr.equals("rjump")) {
			return 0x1f;
		} else if (instr.equals("getvar") || instr.equals("setvar")) {
			return 0x0f;
		} else
			return 0x3f;  // pushc
	}

	public boolean isEclass(String instr) {
		return instr.equals("pushn") || instr.equals("pushcl") ||
			instr.equals("pushloc");
	}

	private int char2int(char c) throws IOException {
		if (c == 'a') return 1;
		if (c == 'b') return 2;
		if (c == 'c') return 3;
		if (c == 'd') return 4;
		if (c == 'e') return 5;
		if (c == 'f') return 6;
		if (c == 'g') return 7;
		if (c == 'h') return 8;
		if (c == 'i') return 9;
		if (c == 'j') return 10;
		if (c == 'k') return 11;
		if (c == 'l') return 12;
		if (c == 'm') return 13;
		if (c == 'n') return 14;
		if (c == 'o') return 15;
		if (c == 'p') return 16;
		if (c == 'q') return 17;
		if (c == 'r') return 18;
		if (c == 's') return 19;
		if (c == 't') return 20;
		if (c == 'u') return 21;
		if (c == 'v') return 22;
		if (c == 'w') return 23;
		if (c == 'x') return 24;
		if (c == 'y') return 25;
		if (c == 'z') return 26;

		if (c == '0') return 27;
		if (c == '1') return 28;
		if (c == '2') return 29;
		if (c == '3') return 30;
		if (c == '4') return 31;
		if (c == '5') return 32;
		if (c == '6') return 33;
		if (c == '7') return 34;
		if (c == '8') return 35;
		if (c == '9') return 36;

		throw new IOException("Invalid character: " + c);
	}

	private Argument string2byte(String s) throws IOException {
		char c1 = s.charAt(0);
		if ((char2int(c1) >> 5) > 0)
			throw new IOException("First character (" + c1 + ") is invalid, only [a-z] are valid");
		char c2 = s.charAt(1);
		if ((char2int(c2) >> 5) > 0)
			throw new IOException("Second character (" + c2 + ") is invalid, only [a-z] are valid");
		char c3 = s.charAt(2);

		Integer intValue = new Integer(char2int(c1) << 11 | char2int(c2) << 6 | char2int(c3));

		//System.out.println("String2byte: " + s + " = " + intValue);
		return new Argument((byte)((intValue.shortValue() >> 8) & 0xff),
								(byte)(intValue.shortValue() & 0xff));
	}

	public void reset() {
		currPos = 0;
	}

	public String nextInstruction() throws IOException {
		return ((Instruction)progVec.get(currPos++)).opcode;
	}

	public int getLineNo() throws IOException {
		return ((Instruction)progVec.get(currPos-1)).lineno;
	}

	public boolean hasMoreInstructions() throws IOException{
		return currPos < progVec.size();
	}

	public Argument argument() {
		return ((Instruction)progVec.get(currPos-1)).arg;
	}

	private class Instruction {
		String opcode;
		int pc, lineno;
		String label;
		Argument arg;

		public Instruction(String opcode, int lineno, int pc) {
			this.opcode = opcode;
			this.pc = pc;
			this.lineno = lineno;
		}

		public String toString() {
			return lineno + ": " + opcode + " " + label + " " + pc + " " + arg;
		}
	}
}
