// $Id: SNInterface.java,v 1.4 2005/03/21 21:17:03 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
package edu.wustl.mobilab.agilla;
import edu.wustl.mobilab.agilla.messages.*;
import edu.wustl.mobilab.agilla.variables.*;
import net.tinyos.message.*;
import java.util.*;

/**
 * Provides a higher level abstraction to the sensor network than that provided
 * by TinyOS.
 *
 * @author Chien-Liang Fok
 */
public class SNInterface implements AgillaConstants, MessageListener {
	private MoteIF moteIF;
	
	/**
	 * Maps AM number -> vector of listeners.
	 */
	private Hashtable lTable;
	
	public SNInterface() {
		lTable = new Hashtable();
	}
	
	public void setMoteIF(MoteIF moteIF) {
		this.moteIF = moteIF;
		moteIF.registerListener(new AgillaErrorMsg(), this);
		moteIF.registerListener(new AgillaCodeMsg(), this);
		moteIF.registerListener(new AgillaStateMsg(), this);
		moteIF.registerListener(new AgillaHeapMsg(), this);
		moteIF.registerListener(new AgillaOpStackMsg(), this);
		moteIF.registerListener(new AgillaResetMsg(), this);
		moteIF.registerListener(new AgillaAckStateMsg(), this);
		moteIF.registerListener(new AgillaAckCodeMsg(), this);
		moteIF.registerListener(new AgillaAckHeapMsg(), this);
		moteIF.registerListener(new AgillaAckOpStackMsg(), this);
		moteIF.registerListener(new AgillaAckRxnMsg(), this);
		moteIF.registerListener(new AgillaTSReqMsg(), this);
		moteIF.registerListener(new AgillaTSResMsg(), this);
		//moteIF.registerListener(new AgillaTSModMsg(), this);
		moteIF.registerListener(new AgillaExpMsg(), this);
		//moteIF.registerListener(new AgillaStartExpMsg(), this);
		
		//moteIF.registerListener(new AgillaCodeUsedMsg(), this);
		//moteIF.registerListener(new AgillaNxtBlockPtrMsg(), this);
	}
	
	public void disconnect() {
		if (moteIF != null) {
			moteIF.deregisterListener(new AgillaErrorMsg(), this);
			moteIF.deregisterListener(new AgillaCodeMsg(), this);
			moteIF.deregisterListener(new AgillaStateMsg(), this);
			moteIF.deregisterListener(new AgillaHeapMsg(), this);
			moteIF.deregisterListener(new AgillaOpStackMsg(), this);
			moteIF.deregisterListener(new AgillaResetMsg(), this);
			moteIF.deregisterListener(new AgillaAckStateMsg(), this);
			moteIF.deregisterListener(new AgillaAckCodeMsg(), this);
			moteIF.deregisterListener(new AgillaAckHeapMsg(), this);
			moteIF.deregisterListener(new AgillaAckOpStackMsg(), this);
			moteIF.deregisterListener(new AgillaAckRxnMsg(), this);
			moteIF.deregisterListener(new AgillaTSReqMsg(), this);
			moteIF.deregisterListener(new AgillaTSResMsg(), this);
			//moteIF.deregisterListener(new AgillaTSModMsg(), this);
			moteIF.deregisterListener(new AgillaExpMsg(), this);
			//moteIF.deregisterListener(new AgillaStartExpMsg(), this);
			
			//moteIF.deregisterListener(new AgillaCodeUsedMsg(), this);
			//moteIF.deregisterListener(new AgillaNxtBlockPtrMsg(), this);
			
			moteIF = null;
		}
	}
	
	public void registerListener(MessageJ msg, MessageListenerJ listener) {
		Integer key = new Integer(msg.getType());
		if (!lTable.containsKey(key)) {
			lTable.put(key, new Vector());
		}
		
		Vector list = (Vector)lTable.get(key);
		if (!list.contains(listener))
			list.add(listener);
	}
	
	public void deregisterListener(MessageJ msg, MessageListenerJ listener) {
		Integer key = new Integer(msg.getType());
		Vector list = (Vector)lTable.get(key);
		if (list != null)
			list.remove(listener);
	}
	
	/**
	 *  Sends a message to the base station mote.
	 */
	public void send(MessageJ msg) throws java.io.IOException {
		if (moteIF != null) {
			//System.out.println("SNInterface: send: sending " + msg.toTOSMsg());
			moteIF.send(TOS_BASE_ADDRESS, msg.toTOSMsg());
		}
	}
	
	/**
	 * Method messageReceived
	 *
	 * @param    to                  an int
	 * @param    m                   a  Message
	 *
	 */
	public void messageReceived(int to, Message m) {
		MessageJ msgJ = null;
		
		switch(m.amType()) {
			case AM_AGILLAERRORMSG:
				msgJ = new AgillaErrorMsgJ((AgillaErrorMsg)m);
				break;
			case AM_AGILLARESETMSG:
				msgJ = new AgillaResetMsgJ((AgillaResetMsg)m);
				break;
			case AM_AGILLASTATEMSG:
				msgJ = new AgillaStateMsgJ((AgillaStateMsg)m);
				break;
			case AM_AGILLACODEMSG:
				msgJ = new AgillaCodeMsgJ((AgillaCodeMsg)m);
				AgillaCodeMsg codeMsg = (AgillaCodeMsg)m;
				if (codeMsg.get_id_id() == 0xffff) {
					String print = "CODE MSG: Index(" + codeMsg.get_msgNum() + ")";
					for (int i = 0; i < codeMsg.totalSize_code(); i++) {
						print += " " + codeMsg.getElement_code(i);
					}
					System.out.println(print);
				}
				break;
			case AM_AGILLAHEAPMSG:
				msgJ = new AgillaHeapMsgJ((AgillaHeapMsg)m);
				break;
			case AM_AGILLAOPSTACKMSG:
				msgJ = new AgillaOpStackMsgJ((AgillaOpStackMsg)m);
				break;
			case AM_AGILLAACKSTATEMSG:
				msgJ = new AgillaAckStateMsgJ((AgillaAckStateMsg)m);
				break;
			case AM_AGILLAACKCODEMSG:
				msgJ = new AgillaAckCodeMsgJ((AgillaAckCodeMsg)m);
				break;
			case AM_AGILLAACKHEAPMSG:
				msgJ = new AgillaAckHeapMsgJ((AgillaAckHeapMsg)m);
				break;
			case AM_AGILLAACKOPSTACKMSG:
				msgJ = new AgillaAckOpStackMsgJ((AgillaAckOpStackMsg)m);
				break;
			case AM_AGILLAACKRXNMSG:
				msgJ = new AgillaAckRxnMsgJ((AgillaAckRxnMsg)m);
				break;
			case AM_AGILLATSREQMSG:
				msgJ = new AgillaTSReqMsgJ((AgillaTSReqMsg)m);
				break;
			case AM_AGILLATSRESMSG:
				msgJ = new AgillaTSResMsgJ((AgillaTSResMsg)m);
				break;
			//case AM_AGILLATSMODMSG:
				//msgJ = new AgillaTSModMsgJ();
				//break;
			case AM_AGILLAEXPMSG:
				AgillaExpMsg expMsg = (AgillaExpMsg)m;
				if (expMsg.get_round() == 0)
					System.out.println("\n");
				System.out.println((expMsg.get_round()+1) + "\t" +  expMsg.get_results());
				/*for (int i = 0; i < 7; i++) {
				 if (expMsg.getElement_round(i) == 0)
				 System.out.println("\n");
				 System.out.println((expMsg.getElement_round(i)+1) + "\t" +  expMsg.getElement_results(i));
				 }*/
				break;
			/*case AM_AGILLASTARTEXPMSG:
				System.out.println("Experimental agent lost!");
				break;
					case AM_AGILLACODEUSEDMSG:
				AgillaCodeUsedMsg usedMsg = (AgillaCodeUsedMsg)m;
				
				String output = "CODE USED MSG: ";
				for (int i = 0; i < usedMsg.totalSize_used(); i++) {
					output += " " + usedMsg.getElement_used(i);
				}
				System.out.println(output);
				break;
			case AM_AGILLANXTBLOCKPTRMSG:
				AgillaNxtBlockPtrMsg nbMsg = (AgillaNxtBlockPtrMsg)m;
				output = "NEXT BLOCK MSG: ";
				for (int i = 0; i < nbMsg.totalSize_nbPtr(); i++) {
					output += " " + nbMsg.getElement_nbPtr(i);
				}
				System.out.println(output);
					 break;*/
		}
		
		
		if (Debugger.printAllMsgs)
			System.out.println("\nSNInterface: Message sent to " + to + ":\n" + msgJ.toString() + "\n\n");
		
		if (to == TOS_LOCAL_ADDRESS) {
			Vector listeners = (Vector)lTable.get(new Integer(m.amType()));
			if (listeners != null) {
				for (int i = 0; i < listeners.size(); i++) {
					MessageListenerJ mlj = (MessageListenerJ)listeners.get(i);
					mlj.messageReceived(to, msgJ);
				}
			}
		}
	}
	
}

