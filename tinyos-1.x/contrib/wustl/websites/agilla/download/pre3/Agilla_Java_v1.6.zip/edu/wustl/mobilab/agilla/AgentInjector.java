// $Id: AgentInjector.java,v 1.6 2005/03/24 22:59:28 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
/*									tab:4
 * "Copyright (c) 2000-2003 The Regents of the University  of California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 * Copyright (c) 2002-2003 Intel Corporation
 * All rights reserved.
 *
 * This file is distributed under the terms in the attached INTEL-LICENSE
 * file. If you do not find these files, copies can be found by writing to
 * Intel Research Berkeley, 2150 Shattuck Avenue, Suite 1300, Berkeley, CA,
 * 94704.  Attention:  Intel License Inquiry.
 */
/* Authors:	Phil Levis <pal@cs.berkeley.edu>,
 Chien-Liang Fok <liang@cse.wustl.edu>
 * Date:        Aug 21 2002
 * Desc:        Main window for Agilla agent injector.
 *
 */

/**
 * @author Phil Levis <pal@cs.berkeley.edu>
 * @author Chien-Liang Fok <liang@cse.wustl.edu>
 */


package edu.wustl.mobilab.agilla;
import edu.wustl.mobilab.agilla.variables.*;


import java.awt.*;
import java.awt.event.*;
import java.awt.font.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;

import net.tinyos.message.*;
import net.tinyos.packet.*;
import net.tinyos.util.*;

import edu.wustl.mobilab.agilla.rmi.agentInjector.*;
import edu.wustl.mobilab.agilla.messages.*;

public class AgentInjector extends JFrame implements AgillaConstants {

	private static final String rmiDisabledString = "<html><font face=\"Arial\" size=\"3\"><b>RMI Injector:</b> <font color=\"red\">Disabled</font>";
	private static final String rmiEnabledString = "<html><font face=\"Arial\" size=\"3\"><b>RMI Injector:</b> <font color=\"green\">Enabled</font> Registered as: ";
	private static final String rmiClientEnabledString = "<html><font face=\"Arial\" size=\"3\"><b>RMI client:</b> <font color=\"green\">Enabled</font> connected to ";

	private static final String sfDisabledString = "<html><font face=\"Arial\" size=\"3\"><b>Serial Forwarder:</b> <font color=\"red\">Disconnected</font>";
	private static final String sfEnabledString = "<html><font face=\"Arial\" size=\"3\"><b>Serial Forwarder:</b> <font color=\"green\">Connected to ";

	//private String initDir = "C:\\tinyos\\cygwin\\opt\\tinyos-1.x\\myApps\\Agilla\\Examples";
	private String initDir = "..\\..\\myApps\\Agilla\\Examples";

    private JMenuBar    menuBar;
    private JLabel      rmiStatusLabel;
	private JLabel      sfStatusLabel;
    private JTextArea   programArea;
	private JTextField xPos, yPos, loc;

    private AgillaAssembler assembler = new AgillaAssembler();
	private MoteIF     moteIF = null;
	private Injector   injector = null;

	//private int aIDCounter = 0;
	private String defaultProgram ="";
	private String filename;
	private File progFile;

	private AgentInjector owner;

	private String source;
	private PhoenixSource psource;

	private AgentInjectorServerSide injectorServer=null; //dani added null, //this allows RMI remote connections


    private AgentInjector(String source, boolean connect, int col, int row, boolean debug) throws Exception {
		super("Agilla Agent Injector");
		owner = this;
		this.source = source;
		AgillaLocation.NUM_COLUMNS = col;
		AgillaLocation.NUM_ROWS = row;
		Debugger.debug = debug;

		injector = new Injector(source);

		createGUI(connect, injector.useRMI());


		//File f = new File("C:\\tinyos\\cygwin\\opt\\tinyos-1.x\\myApps\\Agilla\\Examples\\3Blink.ma");
		//openProgram(f);

		this.addWindowListener(new java.awt.event.WindowAdapter(){
					public void windowClosed(java.awt.event.WindowEvent e) {
						disconnect();
						if (injectorServer!=null) injectorServer.unbind();
					}
				});

		if (connect && !injector.useRMI()) connect();
    }

	private void connect() {
		try {
			if (source.equals("tossim-serial"))
				moteIF = new MoteIF(PrintStreamMessenger.err);
			else {
				psource = BuildSource.makePhoenix(BuildSource.makeArgsSerial(source),
												  net.tinyos.util.PrintStreamMessenger.err);
				moteIF = new MoteIF(psource);
			}
			injector.setMoteIF(moteIF);
			sfStatusLabel.setText(sfEnabledString + source);
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Could not connect to " + source + ".", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void disconnect() {
		psource.shutdown();
		injector.disconnect();
		sfStatusLabel.setText(sfDisabledString);
	}

	private void createGUI(boolean connect, boolean useRMI) {
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		menuBar = new JMenuBar();
		menuBar.setFont(TinyLook.defaultFont());

		JMenu fileMenu = new JMenu();
		fileMenu.setText("File");
		JMenuItem openItem = new JMenuItem("Open", KeyEvent.VK_O);
		openItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
		openItem.addActionListener(new ProgramOpener(this));
		openItem.setFont(TinyLook.defaultFont());

		JMenuItem closeItem = new JMenuItem("Close", KeyEvent.VK_C);
		closeItem.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						programArea.setText(defaultProgram);
						filename = null;
						progFile = null;
						updateTitle();
					}
				});
		closeItem.setFont(TinyLook.defaultFont());

		JMenuItem saveItem = new JMenuItem("Save", KeyEvent.VK_S);
		saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
		saveItem.addActionListener(new ProgramSaver(this));
		saveItem.setActionCommand("Save");
		saveItem.setFont(TinyLook.defaultFont());

		JMenuItem saveAsItem = new JMenuItem("Save As", KeyEvent.VK_A);
		saveAsItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK | ActionEvent.SHIFT_MASK));
		saveAsItem.addActionListener(new ProgramSaver(this));
		saveAsItem.setActionCommand("Save As");
		saveAsItem.setFont(TinyLook.defaultFont());

		JMenuItem quitItem = new JMenuItem("Quit", KeyEvent.VK_Q);
		quitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
		quitItem.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						System.exit(0);
					}
				});
		quitItem.setFont(TinyLook.defaultFont());
		fileMenu.add(openItem);
		fileMenu.add(closeItem);
		fileMenu.add(saveItem);
		fileMenu.add(saveAsItem);
		fileMenu.add(quitItem);
		menuBar.add(fileMenu);


		JMenu snMenu = new JMenu("WSN");
		if (!useRMI) {
			final JCheckBoxMenuItem snConnectMI = new JCheckBoxMenuItem("Connect", connect);
			snConnectMI.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							if (snConnectMI.isSelected())
								connect();
							else
								disconnect();
						}
					});
			snConnectMI.setFont(TinyLook.defaultFont());
			snMenu.add(snConnectMI);
			JMenuItem resetItem = new JMenuItem("Reset All", KeyEvent.VK_R);
			resetItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.CTRL_MASK));
			resetItem.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent evt) {
							injector.reset(TOS_BCAST_ADDRESS);
						}
					});
			resetItem.setFont(TinyLook.defaultFont());
			snMenu.add(resetItem);

			JMenuItem resetMoteItem = new JMenuItem("Reset Mote (s)", KeyEvent.VK_R);
			resetMoteItem.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent evt) {
							String addrString = JOptionPane.showInputDialog("Please enter mote address(es) - use comma-separated values");
							try {
								if (addrString.indexOf(",") != -1) {
									StringTokenizer st = new StringTokenizer(addrString, ",");
									while (st.hasMoreTokens()) {
										int addr = Integer.valueOf(st.nextToken()).intValue();
										System.out.println("Resetting mote " + addr + ".");
										injector.reset(addr);
										synchronized(this) {
											wait(500);
										}
									}
								} else {
									int addr = Integer.valueOf(addrString).intValue();
									injector.reset(addr);
								}
							} catch(Exception e) {
								e.printStackTrace();
								JOptionPane.showMessageDialog(null, "Problems resetting agent " + addrString,
															  "Error", JOptionPane.ERROR_MESSAGE);
							}
						}
					});
			resetMoteItem.setFont(TinyLook.defaultFont());
			snMenu.add(resetMoteItem);
		}

		JMenuItem gridSizeItem = new JMenuItem("Grid Size", KeyEvent.VK_G);
		gridSizeItem.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						new GridSizeDialog(owner);
					}
				});
		gridSizeItem.setFont(TinyLook.defaultFont());
		snMenu.add(gridSizeItem);
		menuBar.add(snMenu);

		JMenu limoneMenu = new JMenu("Limone");
		JMenuItem loadAgentMI = new JMenuItem("Load Limone Agent", KeyEvent.VK_L);
		loadAgentMI.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, ActionEvent.CTRL_MASK));
		loadAgentMI.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						// implement!!
						JOptionPane.showMessageDialog(null, "Not implemented yet.",
													  "Error", JOptionPane.ERROR_MESSAGE);
					}
				});
		loadAgentMI.setFont(TinyLook.defaultFont());
		limoneMenu.add(loadAgentMI);
		menuBar.add(limoneMenu);


		JMenuItem expItem = new JMenuItem("Start Experiment", KeyEvent.VK_S);
		expItem.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						if (moteIF != null) {
							try {
								String inputValue = JOptionPane.showInputDialog("Please enter number of hops.");
								int numHops = Integer.valueOf(inputValue).intValue();
								inputValue = JOptionPane.showInputDialog("Please enter number of resets.");
								int numResets = Integer.valueOf(inputValue).intValue();
								AgillaStartExpMsg smsg = new AgillaStartExpMsg();
								smsg.set_numHops((short)numHops);
								smsg.set_numResets((short)numResets);
								moteIF.send(0, smsg);
							} catch(IOException ioe) {
								ioe.printStackTrace();
							}
						}
					}
				});
		expItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.CTRL_MASK));
		JMenu expMenu = new JMenu("Experiments");
		expMenu.add(expItem);

		JMenuItem showOscope = new JMenuItem("Show Oscope", KeyEvent.VK_O);
		showOscope.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						new edu.wustl.mobilab.agilla.clients.oscope.oscilloscope(injector.getTS());
					}
				});
		expMenu.add(showOscope);
		menuBar.add(expMenu);

		JMenu dbMenu = new JMenu();
		dbMenu.setText("Debug");

		JMenuItem dbItem = new JMenuItem("Print Debug Code", KeyEvent.VK_P);
		dbItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
		dbItem.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						ProgramTokenizer tok = null;
						try {
							String program = programArea.getText();
							if (program.equals("")) return;
							StringReader reader = new StringReader(program);
							tok = new ProgramTokenizer(reader, assembler);
							assembler.printDebugCode(tok, filename);
						} catch(Exception e) {
							int lineno = 0;
							try {
								lineno = tok.getLineNo();
							} catch(IOException ie) {
								ie.printStackTrace();
							}
							JOptionPane.showMessageDialog(null, "Problems on line " + lineno,
														  "Error", JOptionPane.ERROR_MESSAGE);
							System.out.println("Problems on line " + lineno);
							e.printStackTrace();
						}
					}
				});
		dbItem.setFont(TinyLook.defaultFont());
		dbMenu.add(dbItem);

		JMenuItem dbPrintDivItem = new JMenuItem("Print Divider", KeyEvent.VK_D);
		dbPrintDivItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.ALT_MASK));
		dbPrintDivItem.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						System.out.println("--------------------------------------------------------------------------------");
						System.out.println("--------------------------------------------------------------------------------");
					}
				});
		dbPrintDivItem.setFont(TinyLook.defaultFont());
		dbMenu.add(dbPrintDivItem);

		final JCheckBoxMenuItem printAllMsgsMI = new JCheckBoxMenuItem("Print All Received Msgs", false);
		printAllMsgsMI.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Debugger.printAllMsgs = printAllMsgsMI.isSelected();
					}
				});
		printAllMsgsMI.setFont(TinyLook.defaultFont());
		dbMenu.add(printAllMsgsMI);

		final JCheckBoxMenuItem debugModeMI = new JCheckBoxMenuItem("Debug Mode", Debugger.debug);
		debugModeMI.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Debugger.debug = debugModeMI.isSelected();
					}
				});
		debugModeMI.setFont(TinyLook.defaultFont());
		dbMenu.add(debugModeMI);
		menuBar.add(dbMenu);

		//dani
		if (!useRMI) {
			JMenu remoteMenu = new JMenu();
			remoteMenu.setText("Remote");
			final JCheckBoxMenuItem enableRMI = new JCheckBoxMenuItem("Enable", false);
			enableRMI.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							if (enableRMI.isSelected()) {
								if(moteIF!=null) {
									try{
										injectorServer = new AgentInjectorServerSide(injector);
										rmiStatusLabel.setText(rmiEnabledString + injectorServer.getBoundName());
									}
									catch(Exception injexception) {
										System.out.println("injector exception !: ");
										System.out.println("   Did you start the rmiregistry?");
										System.out.println("   Did you include the -D options when calling java?");
										System.out.println("   Did you have the java.policy file at the /opt/tinyos-1.x/tools/java (or from wherever path the agilla injector is started) ?");
										injexception.printStackTrace();
										JOptionPane.showMessageDialog(null, "Problems starting RMI. Check stub, policy, and rmi server.", "Error", JOptionPane.ERROR_MESSAGE);
										enableRMI.setSelected(false);
									}
								}
								else {
									System.out.println("Working on local mode (moteIF==null), so RMI cannot be enabled");
									enableRMI.setSelected(false);
								}

							}
							else {
								if (injectorServer!=null) {
									injectorServer.unbind();
									rmiStatusLabel.setText(rmiDisabledString);
								}
							}
						}
					});
			enableRMI.setFont(TinyLook.defaultFont());
			remoteMenu.add(enableRMI);
			menuBar.add(remoteMenu);//dani
		}

		//enddani

		this.setJMenuBar(menuBar);

		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(createStatusPanel(useRMI), BorderLayout.NORTH);
		getContentPane().add(createProgramPanel(), BorderLayout.CENTER);
		getContentPane().add(createLowerPanel(), BorderLayout.SOUTH);

		pack();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = this.getSize();
		if (frameSize.height > screenSize.height)
			frameSize.height = screenSize.height;
		if (frameSize.width > screenSize.width)
			frameSize.width = screenSize.width;
		setLocation((screenSize.width - frameSize.width) / 2,
						(screenSize.height - frameSize.height) / 2);
		show();
	}

	private JPanel createStatusPanel(boolean useRMI) {
		JPanel sPanel = new JPanel();
		if (!useRMI) {
			rmiStatusLabel = new JLabel(rmiDisabledString);
			sfStatusLabel = new JLabel(sfDisabledString);

			JPanel rmiPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
			rmiPanel.add(rmiStatusLabel);

			JPanel sfPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			sfPanel.add(sfStatusLabel);
			sPanel.setLayout(new GridLayout(1,2));
			sPanel.add(rmiStatusLabel);
			sPanel.add(sfPanel);
		} else {
			rmiStatusLabel = new JLabel("");
			JLabel rmiClientStatusLabel = new JLabel(rmiClientEnabledString + injector.getRMIHost());
			sPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
			sPanel.add(rmiClientStatusLabel);
		}

		return sPanel;
	}

	private void updateTitle() {
		if (filename != null)
			setTitle("Agilla Agent Injector - " + filename);
		else
			setTitle("Agilla Agent Injector");
	}

	private JPanel createProgramPanel() {
		JPanel panel = new JPanel();

		programArea = new JTextArea(25, 75);
		programArea.setText(defaultProgram);
		programArea.setFont(TinyLook.constFont().deriveFont((float)13.0));
		programArea.setBorder(new EtchedBorder());

		JScrollPane scroller = new JScrollPane(programArea,
											   ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
											   ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		panel.setLayout(new BorderLayout());
		panel.add(scroller, BorderLayout.CENTER);
		return panel;
	}

	public void clearLocBox() {
		xPos.setText("0");
		yPos.setText("0");
		loc.setText("0");
	}

	public void updateLocBox() {

		short x = 0, y = 0;
		if (xPos.getText().length() != 0 && yPos.getText().length() != 0) {
			try {
				x = (short)Integer.valueOf(xPos.getText()).intValue();
				y = (short)Integer.valueOf(yPos.getText()).intValue();
				AgillaLocation locv = new AgillaLocation(x,y);
				System.out.println("location = " + locv);
				loc.setText(String.valueOf(locv.getAddr()));
			} catch(NumberFormatException e) {
				e.printStackTrace();
			}
		 }
	}

	private JPanel createLowerPanel() {
		xPos = new JTextField("0", 4);
		yPos = new JTextField("0", 4);
		loc = new JTextField("0", 4);

		xPos.addKeyListener(new KeyAdapter() {
					public void keyReleased(KeyEvent e) {
						updateLocBox();
					}
				});
		yPos.addKeyListener(new KeyAdapter() {
					public void keyReleased(KeyEvent e) {
						updateLocBox();
					}
				});
		loc.addKeyListener(new KeyAdapter() {
					public void keyReleased(KeyEvent e) {
						int addr = Integer.valueOf(loc.getText()).intValue();
						AgillaLocation locv = new AgillaLocation(addr);
						xPos.setText(String.valueOf(locv.getx()));
						yPos.setText(String.valueOf(locv.gety()));
					}
				});

		JPanel locPanel = new JPanel();
		locPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		locPanel.add(new JLabel("Destination x: "));
		locPanel.add(xPos);
		locPanel.add(new JLabel(" y: "));
		locPanel.add(yPos);
		locPanel.add(new JLabel("  TOS Address: "));
		locPanel.add(loc);

		InjectButton injectButton = new InjectButton(this);
		injectButton.setFont(TinyLook.boldFont().deriveFont((float)14.0));
		injectButton.setAlignmentX(CENTER_ALIGNMENT);

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BorderLayout());
		buttonPanel.add(injectButton, BorderLayout.CENTER);
		buttonPanel.setBorder(new EmptyBorder(5,5,5,5));

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(2,1));
		panel.add(locPanel);
		panel.add(injectButton);

		return panel;
	}

	private void inject() throws IOException, InvalidInstructionException  {
		short x = 0,y = 0;

		try {
			x = (short)Integer.valueOf(xPos.getText()).intValue();
			y = (short)Integer.valueOf(yPos.getText()).intValue();
		} catch(NumberFormatException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Invalid destination location.",
										  "Error", JOptionPane.ERROR_MESSAGE);
		}

		AgillaLocation dest = new AgillaLocation(x,y);

		if (!injector.useRMI() && moteIF == null)
			JOptionPane.showMessageDialog(null, "Cannot inject agent while running in local mode.",
										  "Error", JOptionPane.ERROR_MESSAGE);
		else {
			String program = programArea.getText();
			if (program.equals("")) {
				JOptionPane.showMessageDialog(null, "Agent must have at least one instruction.",
											  "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			StringReader reader = new StringReader(program);
			ProgramTokenizer tok = new ProgramTokenizer(reader, assembler);
			byte[] code = assembler.toByteCodes(tok);

			injector.inject(dest, new Agent(new AgillaAgentID(), code));
		}
	}

	private void openProgram(File f) {
		progFile = f;
		filename = progFile.getName();
		updateTitle();

		try {
			FileReader fr = new FileReader(progFile);
			BufferedReader br = new BufferedReader(fr);

			String prog = "";
			String curr;

			while ((curr = br.readLine()) != null) {
				prog += curr + "\n";
			}
			br.close();
			fr.close();

			programArea.setText(prog);
		} catch(Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

	private class ProgramOpener implements ActionListener {
		Component parent;

		public ProgramOpener(Component parent) {
			this.parent = parent;
		}

		public void actionPerformed(java.awt.event.ActionEvent evt) {
			String dir = initDir;
			File usrDir = new File(dir);
			if (!usrDir.exists())
				usrDir = new File(System.getProperties().getProperty("user.dir"));

			JFileChooser fileChooser = new JFileChooser(usrDir);
			fileChooser.setDialogTitle("Open Agent");
			fileChooser.setDialogType(JFileChooser.OPEN_DIALOG);
			fileChooser.setMultiSelectionEnabled(false);

			int returnVal = fileChooser.showOpenDialog(parent);

			if (returnVal == JFileChooser.APPROVE_OPTION) {
				openProgram(fileChooser.getSelectedFile());
			}
		}
	}

	private class ProgramSaver implements ActionListener {
		Component parent;

		public ProgramSaver(Component parent) {
			this.parent = parent;
		}

		public void actionPerformed(java.awt.event.ActionEvent evt) {
			String program = programArea.getText();
			File file = null;

			if (evt.getActionCommand().equals("Save As")) {
				String dir = initDir;
				File usrDir = new File(dir);
				if (!usrDir.exists())
					usrDir = new File(System.getProperties().getProperty("user.dir"));

				JFileChooser fileChooser = new JFileChooser(usrDir);
				fileChooser.setDialogTitle("Save Agent");
				fileChooser.setDialogType(JFileChooser.SAVE_DIALOG);
				fileChooser.setMultiSelectionEnabled(false);

				if (fileChooser.showSaveDialog(parent) == JFileChooser.APPROVE_OPTION) {
					try {
						file = fileChooser.getSelectedFile();
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
			} else
				file = progFile;

			if (file != null) {
				if (file.canWrite()) {
					filename = file.getName();
					updateTitle();

					try {
						FileWriter fr = new FileWriter(file, false);
						BufferedWriter br = new BufferedWriter(fr);

						br.write(program);
						br.flush();
						br.close();
						fr.close();
					} catch(Exception e) {
						e.printStackTrace();
						JOptionPane.showMessageDialog(null, "Cannot write to file.", "Error", JOptionPane.ERROR_MESSAGE);
					}
				} else
					JOptionPane.showMessageDialog(null, "Cannot write to file.", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private class InjectButton extends JButton {
		public InjectButton(AgentInjector inject) {
			super("Inject Agent!!");
			addActionListener(new InjectListener(inject));
			setAlignmentX(CENTER_ALIGNMENT);
		}

		private class InjectListener implements ActionListener {
			private AgentInjector injector;

			public InjectListener(AgentInjector injector) {
				this.injector = injector;
			}

			public void actionPerformed(ActionEvent e) {
				try {
					injector.inject();
				}
				catch (IOException exception) {
					System.err.println("ERROR: Couldn't inject packet: " + exception);
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				catch (InvalidInstructionException exception) {
					System.err.println("Invalid instruction: " + exception.getMessage());
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				catch (Exception exception) {
					exception.printStackTrace();
					JOptionPane.showMessageDialog(null, exception.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}

	public static void main(String[] args) {
		try {
			int index = 0, col = AgillaLocation.NUM_COLUMNS, row = AgillaLocation.NUM_ROWS;
			String source = "COM4:mica2"; //"sf@localhost:9001";
			boolean connect = true, debug = false;

			while (index < args.length) {
				String arg = args[index];
				if (arg.equals("-h") || arg.equals("--help")) {
					usage();
					System.exit(0);
				}
				else if (arg.equals("-comm")) {
					index++;
					source = args[index];
				}
				else if (arg.equals("-col")) {
					col = Integer.valueOf(args[++index]).intValue();
				}
				else if (arg.equals("-row")) {
					row = Integer.valueOf(args[++index]).intValue();
				}
				else if (arg.equals("-nc"))
					connect = false;
				else if (arg.equals("-d"))
					debug = true;
				else {
					usage();
					System.exit(1);
				}
				index++;
			}
			new AgentInjector(source, connect, col, row, debug);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void usage() {
		System.err.println("usage: Agilla [-h|--help|-comm <source>|-nc|-d]");
		System.err.println("\t-comm <source> where <source> is COMx:[platform] or tossim-serial or RMI:address, default COM4:mica2");
		System.err.println("\t-nc do not connect to serial forwarder");
		System.err.println("\t-d for debug mode");
	}



}
