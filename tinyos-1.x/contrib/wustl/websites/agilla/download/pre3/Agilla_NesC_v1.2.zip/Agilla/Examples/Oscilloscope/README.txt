This is an example application that uses mobile agents to
collect light readings for display on an oscilloscope GUI.

Run it by injecting the Oscilloscope agent onto a node in
the sensor network, and loading the Oscilloscope java agent
using the AgentInjector.