Test the blocking IN operation.  First inject IN.ma onto a node, then
inject OUT.ma onto the same node.  If the green LED lights up, it worked.