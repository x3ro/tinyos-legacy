// $Id: TupleSpace.h,v 1.8 2005/05/03 22:43:10 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */

#include "Agilla.h"

#ifndef AGILLA_TS_TUPLESPACE_H_INCLUDED
#define AGILLA_TS_TUPLESPACE_H_INCLUDED

typedef enum {
  AGILLA_TS_SIZE           = 100,    // size of RAM tuple space in bytes
  AGILLA_TS_EEPROM_SIZE    = 524288, // size of EEPROM tuple space in bytes

  AGILLA_MAX_TUPLE_SIZE    = 25,      // the max number of field bytes in a tuple, a
                                      // tuple's actual size is this + 2
  AGILLA_OUT_Q_SIZE        = 3,       // the max number of pending OUT operations
  AGILLA_RTS_TIMEOUT       = 1024,//512,     // remote op timeout in binary milliseconds
  AGILLA_RTS_MAX_NUM_TRIES = 4,//2,   // the max number of times a request is sent
  AGILLA_TS_BOUNCEQ_SIZE   = 3,
  REACTION_MGR_BUFFER_SIZE = 5       // the max number of reactions
} TupleSpaceIConstants;

typedef enum {
  AGILLA_TUPLE_RESET      = 0x00,
  AGILLA_TUPLE_SYSTEM     = 0x01,
} AgillaTupleFlags;

//typedef enum {
//  BUSY = 0x02,
//} TupleSpaceReturnConstant;

// Tuple string constants
#define AGILLA_TUPLE_STRING_AGENT  2628  // "aid"
#define AGILLA_TUPLE_STRING_HOST   16964 // "hid"
#define AGILLA_TUPLE_STRING_PHOTO  39184 // "sdp"
#define AGILLA_TUPLE_STRING_TEMP   39188 // "sdt"
#define AGILLA_TUPLE_STRING_MIC    39181 // "sdm"
#define AGILLA_TUPLE_STRING_MAGX   39192 // "sdx"
#define AGILLA_TUPLE_STRING_MAGY   39193 // "sdy"
#define AGILLA_TUPLE_STRING_ACCELX 39169 // "sda"
#define AGILLA_TUPLE_STRING_ACCELY 39170 // "sdb"

typedef struct AgillaTuple {
  uint8_t flags;
  uint8_t size;    // number of fields
  uint8_t data[AGILLA_MAX_TUPLE_SIZE]; // [type], [var], ...
} AgillaTuple; // 27 bytes

typedef struct Reaction {
  AgillaAgentID id;
  uint16_t pc;
  AgillaTuple template;
} Reaction;

//------------------------------------------------------------------------------
// Active message port numbers
enum {
  AM_AGILLATSREQMSG     = 0x30,
  AM_AGILLATSRESMSG     = 0x31,
  //AM_AGILLATSMODMSG     = 0x32,
  AM_AGILLATSGRESMSG    = 0x33,
};

//------------------------------------------------------------------------------
// Tuple Space operation request/response messages

//typedef struct AgillaTSModMsg {
//  uint8_t dummy;
//} AgillaTSModMsg;

typedef struct AgillaTSReqMsg {
  AgillaLocation destLoc; 
  AgillaLocation replyLoc;
  uint8_t op;
  AgillaTuple tuple; // template
} AgillaTSReqMsg; // 36 bytes

typedef struct AgillaTSResMsg {
  AgillaLocation destLoc;
  uint8_t op;
  bool success;
  AgillaTuple tuple;  // the info.flags field is set by the sender
} AgillaTSResMsg;

/* This message contains the location of the
   neighbor with a matching tuple.  It is used
   to return the results of a rrdpg request. */
typedef struct AgillaTSGResMsg {
  AgillaLocation sourceLoc;
} AgillaTSGResMsg;


// If sent from base station to mote, register reaction.
// If sent from mote to base station, reaction fired.
//typedef struct AgillaBSRxnMsg {
//  Reaction rxn;
//} AgillaBSRxnMsg;
#endif

