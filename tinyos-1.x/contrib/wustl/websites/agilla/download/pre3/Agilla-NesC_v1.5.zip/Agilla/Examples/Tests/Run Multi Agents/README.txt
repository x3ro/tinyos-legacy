Tests whether multiple agents can run on a single mote.

Usage: Inject all three agents on the same mote and see
if all three LEDs blink.