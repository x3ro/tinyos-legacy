There are three agents that test reactions.

Out.ma:			Places a tuple into the tuple space and toggles 
			the yellow LED.

Register.ma 		Registers a reaction and toggles the red LED.  When 
			the reaction fires, it turns on the green LED.

Register-then-move.ma	Registers a reaction, then moves to mote (1,1). When 
			the reaction fires, it turns on the green LED.

There are many tests to run using these agents:

  1) Inject Out.ma onto node (0,0), then inject Register.ma onto the 
     same node.  See if the Register agent immediately reacts to the
     tuple OUTed by OUT.ma

  2) First inject Register.ma onto (0,0), then Out.ma onto the 
     same node.  See whether Register.ma reacts to the tuple after
     Out.ma inserts a tuple into the local tuple space.

  3) To test whether reactions follow an agent as it migrates, 
     inject Register-then-move.ma onto (0,0), then inject Out.ma onto
     (1,1), see if the first agent's reaction fires.


  4) Repeat 3) except inject Out.ma first.


  5) To test whether reactions are transferred across clone operations,
     inject Register-then-clone.ma onto (0,0), then inject Out.ma onto 
     (1,1), and see if the first agent's reaction fires.


  6) Repeast 5) except inject Out.ma first.

