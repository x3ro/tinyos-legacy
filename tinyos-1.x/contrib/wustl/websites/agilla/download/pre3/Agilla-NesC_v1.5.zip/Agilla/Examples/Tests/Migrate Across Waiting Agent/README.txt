This tests whether an agent can migrate across a node containing
an agent in a wait state.  First inject Wait.ma onto node (0,0).
The inject Migrate.ma into node (0,0).  If both nodes at (0,0) 
and (1,1) turn on their red LED, the test is successful.