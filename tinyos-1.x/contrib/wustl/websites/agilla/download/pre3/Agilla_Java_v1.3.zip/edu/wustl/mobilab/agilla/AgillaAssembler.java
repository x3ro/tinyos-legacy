// $Id: AgillaAssembler.java,v 1.1 2005/01/27 22:31:16 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */

/*									tab:4
 * "Copyright (c) 2000-2003 The Regents of the University  of California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 * Copyright (c) 2002-2003 Intel Corporation
 * All rights reserved.
 *
 * This file is distributed under the terms in the attached INTEL-LICENSE
 * file. If you do not find these files, copies can be found by writing to
 * Intel Research Berkeley, 2150 Shattuck Avenue, Suite 1300, Berkeley, CA,
 * 94704.  Attention:  Intel License Inquiry.
 */
/* Authors:	Phil Levis <pal@cs.berkeley.edu>
 * Date:        Aug 8 2002
 * Desc:        Assembler for Bombilla VM.
 *
 */

/**
 * @author Phil Levis <pal@cs.berkeley.edu>
 */


package edu.wustl.mobilab.agilla;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;


public class AgillaAssembler implements Assembler, AgillaConstants {
	
	/**
	 * A hashtable that maps string->byte representation of an instruction.
	 */
    private Hashtable s2bTable, b2sTable;
	
    private ClassLoader loader;
	
    public AgillaAssembler() {
		loader = this.getClass().getClassLoader();
		s2bTable = new Hashtable();
		b2sTable = new Hashtable();
		loadOpcodes();
    }
	
    private void loadOpcodes() {
		try {
			Class constants = loader.loadClass("edu.wustl.mobilab.agilla.AgillaOpcodes");
			Field[] fields = constants.getFields();
			for (int i = 0; i < fields.length; i++) {
				Field field = fields[i];
				String name = field.getName();
				if (name.substring(0,2).equals("OP")) {
					String code = name.substring(2);
					byte val = (byte)(field.getShort(constants) & 0xff);
					s2bTable.put(code, new Byte(val));
					b2sTable.put(new Short(val), code);
				}
				
			}
		}
		catch (Exception e) {
			System.out.println();
			System.err.println(e);
			e.printStackTrace();
		}
    }
	
	public String byte2String(short b) {
		return (String)b2sTable.get(new Short(b));
	}
    
    public String toHexString(ProgramTokenizer tokenizer)
		throws IOException, InvalidInstructionException {
		
		byte[] program = toByteCodes(tokenizer);
		String bytes = "";
		for (int i = 0; i < program.length; i++) {
			String val = Integer.toHexString(program[i] & 0x00ff);
			if (val.length() == 1) {
				val = "0" + val;
			}
			bytes += "0x"+val;
			bytes += " ";
		}
		return bytes;
    }
	
	public void printDebugCode(ProgramTokenizer tokenizer, String filename)
		throws IOException, InvalidInstructionException {
		
		Vector result = new Vector();
		Vector stringVector = new Vector();
		int pc = 0;
		while (tokenizer.hasMoreInstructions()) {
			String instr = tokenizer.nextInstruction();
			if (!isInstruction(instr))
				throw new InvalidInstructionException(pc, instr);
			
			if (tokenizer.isEclass(instr)) {
				Argument val = tokenizer.argument();
				stringVector.add("OP" + instr + ";");
				stringVector.add(val.b1 + ";");
				stringVector.add(val.b2 + ";");
				pc = pc+3;
			} else if (tokenizer.hasEmbeddedOperand(instr)) {
				Argument val = tokenizer.argument();
				stringVector.add("OP" + instr + " | " + val.b1 + ";");
				pc++;
			} else {
				stringVector.add("OP" + instr + ";");
				pc++;
			}
		}
		
		pc = 0;
		int msgNum = 0;
		int i = 0;
		while (i < stringVector.size()){
			result.add("    cMsg.msgNum = " + (msgNum++) + ";");
			int msgSize = 0;
			while (msgSize < AGILLA_CODE_BLOCK_SIZE  && i < stringVector.size()) {
				String instr = (String)stringVector.get(i++);
				if (tokenizer.isEclass(instr)) {
					result.add("    cMsg.code[" + (msgSize++) + "] = " + instr);
					result.add("    cMsg.code[" + (msgSize++) + "] = " + stringVector.get(i++));
					result.add("    cMsg.code[" + (msgSize++) + "] = " + stringVector.get(i++));
					pc = pc+3;
				} else if (tokenizer.hasEmbeddedOperand(instr)) {
					Argument val = tokenizer.argument();
					result.add("    cMsg.code[" + (msgSize++) + "] = " + instr);
					pc++;
				} else {
					result.add("    cMsg.code[" + (msgSize++) + "] = " + instr);
					pc++;
				}
				
			}
			result.add("    call CodeMgrI.setBlock(&agents[0], &cMsg);\n\n");
		}
		
		
		result.add(0, "    agents[0].id.id = call AgentMgrI.getNewID();;");
		result.add(1, "    agents[0].pc = 0;");
		//result.add(2, "       agents[0].integrity = AGILLA_AGENT_READY;");
		result.add(2, "    agents[0].state = AGILLA_STATE_READY;");
		result.add(3, "    call CodeMgrI.allocateBlocks(&agents[0], " + pc + ");");
		
		System.out.println("-----------------------------------------------------------\n\n");
		//System.out.println("// Begin debug code output.");
		System.out.println("    dbg(DBG_USR1, \"||||||||||||||||||||||||||||||||||||||||||||||||||||||||\\n\");");
		if (filename == null)
			System.out.println("    dbg(DBG_USR1, \"Running untitled\\n\");");
		else
			System.out.println("    dbg(DBG_USR1, \"Running " + filename + "\\n\");");
		for (int j = 0; j < result.size(); j++) {
			System.out.println(result.get(j).toString());
		}
		System.out.println("\n\n-----------------------------------------------------------");
	}
	
	public boolean isInstruction(String instr) {
		boolean result = s2bTable.containsKey(instr);
		/*if (result)
		 System.out.println("Instruction " + instr + " is an instruction");
		 else
		 System.out.println("Instruction " + instr + " is NOT an instruction");*/
		return result;
	}
	
	/**
	 * Returns the byte represenation of a program.
	 */
	public byte[] toByteCodes(ProgramTokenizer tokenizer)
		throws IOException, InvalidInstructionException {
		
		Vector program = new Vector();
		while (tokenizer.hasMoreInstructions()) {
			String instr = tokenizer.nextInstruction();
			
			if (!isInstruction(instr))
				throw new InvalidInstructionException(program.size(), instr);
			
			Byte obj = (Byte)s2bTable.get(instr);
			byte code = obj.byteValue();
			if (tokenizer.isEclass(instr)) {
				Argument val = tokenizer.argument();
				program.add(obj);
				program.add(new Byte(val.b1));
				program.add(new Byte(val.b2));
			} else if (tokenizer.hasEmbeddedOperand(instr)) {
				Argument val = tokenizer.argument();
				code = (byte)(code | val.b1);
				obj = new Byte(code);
				program.add(obj);
			} else
				program.add(obj);
		}
		
		int size = program.size();
		byte[] result = new byte[size];
		for (int i = 0; i < size; i++) {
			Byte instr = (Byte)program.elementAt(i);
			result[i] = instr.byteValue();
		}
		
		return result;
	}
	
	
	public static void main(String[] args) {
		try {
			AgillaAssembler assembler = new AgillaAssembler();
			FileReader reader = new FileReader(args[0]);
			ProgramTokenizer tokenizer = new ProgramTokenizer(reader, assembler);
			String program = assembler.toHexString(tokenizer);
			System.out.println(program);
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
