// $Id: AgentSender.java,v 1.2 2005/02/09 18:00:39 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
package edu.wustl.mobilab.agilla;
import edu.wustl.mobilab.agilla.messages.*;
import edu.wustl.mobilab.agilla.variables.*;


import net.tinyos.message.*;
import java.util.*;

public class AgentSender implements AgillaConstants, AgillaOpcodes,
	MessageListenerJ, Runnable {
	private SNInterface sni;
	private Vector queue;
	private Object lock;
	private int nCodeBlocks;
	private short nHeapMsgs, nOSMsgs, nRxnMsgs;
	private MessageJ ackMsg;
	private TimeoutTimer timeoutTimer;
	private short hpIndex, osIndex;
	private AgillaLocation dest;
	private Agent cAgent; // the current migrating agent
	
	public AgentSender(SNInterface sni) {
		this.sni = sni;
		this.queue = new Vector();
		this.lock  = new Object();
		sni.registerListener(new AgillaAckStateMsgJ(), this);
		sni.registerListener(new AgillaAckCodeMsgJ(), this);
		sni.registerListener(new AgillaAckHeapMsgJ(), this);
		sni.registerListener(new AgillaAckOpStackMsgJ(), this);
		sni.registerListener(new AgillaAckRxnMsgJ(), this);
		new Thread(this).start();
	}
	
	/**
	 * Sends an agent to the specified location.
	 */
	public void send(AgillaLocation dest, Agent agent) {
		Debugger.dbg("AgentSender", "Sending " + agent);
		queue.add(new PendingAgent(dest, agent));
		synchronized(queue) {
			try {
				queue.notifyAll();
			} catch(IllegalMonitorStateException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void messageReceived(int to, MessageJ m) {
		//Debugger.dbg("AgentSender", "Received message " + m);
		if (m.getType() == AM_AGILLAACKSTATEMSG ||
			m.getType() == AM_AGILLAACKCODEMSG ||
			m.getType() == AM_AGILLAACKHEAPMSG ||
			m.getType() == AM_AGILLAACKOPSTACKMSG ||
			m.getType() == AM_AGILLAACKRXNMSG) {
			if (timeoutTimer != null)
				timeoutTimer.kill();
			synchronized(lock) {
				this.ackMsg = m;
				try {
					lock.notifyAll();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	private int sendStateMsg() {
		AgillaStateMsgJ msg = new AgillaStateMsgJ(
			this.dest,
			TOS_LOCAL_ADDRESS, // reply address
			cAgent.getID(), AgillaOpcodes.OPsmove, cAgent.getOpStack().size(),
			cAgent.getPC(),
			cAgent.getCondition(),
			cAgent.codeSize(),
			nHeapMsgs,
			nRxnMsgs); // numRxnMsgs
		Debugger.dbg("AgentSender", "StateMsg:\n" + msg + "\n\n");
		
		int nTries = 0;
		while(nTries < AGILLA_MIGRATE_NUM_TIMEOUTS) {
			Debugger.dbg("AgentSender.sendStateMsg()", "Sending state message to " + dest + "...");
			sendMsg(msg);
			boolean done = false;
			int nBadAcks = 0;
			while (!done) {
				Debugger.dbg("AgentSender.sendStateMsg()", "Awaiting ACK for state message from " + dest + "...");
				waitForAck();
				if (ackMsg == null) {
					nTries++;
					Debugger.dbg("AgentSender.sendStateMsg()", "Timed out while waiting for ack from " + dest + ", nTries = " + nTries +"...");
					done = true;  // break out of inner while loop
				} else {
					if (ackMsg instanceof AgillaAckStateMsgJ) {
						AgillaAckStateMsgJ ack = (AgillaAckStateMsgJ)ackMsg;
						if (ack.getID().equals(cAgent.getID())) {
							if (ack.getAccept() == AGILLA_ACCEPT) {
								Debugger.dbg("AgentSender.sendStateMsg()", "ACK ACCEPTED state message.");
								return SUCCESS;
							} else {
								Debugger.dbg("AgentSender.sendStateMsg()", "Received an ACK but it REJECTED the message.");
								return FAIL;
							}
						} else {
							Debugger.dbg("AgentSender.sendStateMsg()", "Ack was for the wrong agent " + ack.getID());
							if (++nBadAcks == AGILLA_MIGRATE_NUM_BAD_ACKS) {
								Debugger.dbg("AgentSender.sendStateMsg()", "Exceeded maximum number of bad acknowledgements.");
								return FAIL;
							}
						}
					} else Debugger.dbg("AgentSender.sendStateMsg()", "The ACK wasn't of type AgillaAckStateMsgJ.");
				}
			}
		} // while...
		Debugger.dbg("AgentSender.sendStateMsg()", "ERROR: Exceeded maximum number of timeouts.");
		return FAIL;
	}
	
	/**
	 * Method sendCodeMsgs
	 *
	 * @return   an int
	 *
	 */
	private int sendCodeMsgs() {
		for (short msgNum = 0; msgNum < nCodeBlocks; msgNum++) {
			AgillaCodeMsgJ msg = new AgillaCodeMsgJ(cAgent.getID(), TOS_LOCAL_ADDRESS, msgNum);
			
			int firstBlockAddr = msgNum*AGILLA_CODE_BLOCK_SIZE;
			int lastBlockAddr = firstBlockAddr + AGILLA_CODE_BLOCK_SIZE;
			for (int j = firstBlockAddr; j < cAgent.codeSize() && j < lastBlockAddr; j++) {
				msg.setCode(j-firstBlockAddr, cAgent.getInstr(j));
			}
			Debugger.dbg("AgentSender.sendCodeMsgs()", "CodeMsg " + msgNum + ": \n" + msg + "\n\n");
			
			int nTries = 0;
			boolean done = false;
			while(!done && nTries < AGILLA_MIGRATE_NUM_TIMEOUTS) {
				Debugger.dbg("AgentSender.sendCodeMsgs()", "Sending code message to " + dest + "...");
				sendMsg(msg);
				int nBadAcks = 0;
				while(!done) {
					waitForAck();
					if (ackMsg == null) {
						nTries++;
						Debugger.dbg("AgentSender.sendCodeMsgs()", "Timed out while waiting for AgillaAckCodeMsgJ");
					} else {
						if (ackMsg instanceof AgillaAckCodeMsgJ) {
							AgillaAckCodeMsgJ ack = (AgillaAckCodeMsgJ)ackMsg;
							if (ack.getID().equals(cAgent.getID()) && ack.getMsgNum() == msgNum) {
								if (ack.getAccept() == AGILLA_ACCEPT) {
									done = true;
									Debugger.dbg("AgentSender.sendCodeMsgs()", "Received ACK for Code message, ACCEPTED");
								} else {
									Debugger.dbg("AgentSender.sendCodeMsgs()", "Received ACK for Code message, REJECTED ");
									return FAIL;
								}
							} else {
								Debugger.dbg("AgentSender.sendCodeMsgs()", "The ACK message wasn't for the right agent (expected " + cAgent.getID() + ", got " + ack.getID() + ") or msgNum (expected " + msgNum + ", got " + ack.getMsgNum() + ")");
								if (++nBadAcks == AGILLA_MIGRATE_NUM_BAD_ACKS) {
									Debugger.dbg("AgentSender.sendCodeMsgs()", "Exceeded maximum number of bad acknowledgements.");
									return FAIL;
								}
							}
						} else Debugger.dbg("AgentSender.sendCodeMsgs()", "The ACK message wasn't of type AgillaAckCodeMsgJ");
					}
				}
			}
			if (nTries == AGILLA_MIGRATE_NUM_TIMEOUTS) {
				Debugger.dbg("AgentSender.sendCodeMsgs()", "Exceeded number of timeouts while sending code messages.");
				return FAIL;
			}
		}
		Debugger.dbg("AgentSender.sendCodeMsgs()", "Successfully sent code messages.");
		return SUCCESS;
	}
	
	private int fillHeapMsg(AgillaHeapMsgJ msg) {
		AgillaStackVariable[] heap = cAgent.getHeap();
		boolean foundFirst = false;
		int hpAddr1 = 0;
		
		while (msg.size() < AGILLA_HEAP_MSG_SIZE && hpIndex < AGILLA_HEAP_SIZE) {
			if (heap[hpIndex].getType() != AGILLA_TYPE_INVALID) {
				msg.addHeapItem(hpIndex, heap[hpIndex]);
				if (!foundFirst) {
					foundFirst = true;
					hpAddr1 = hpIndex;
				}
			}
			hpIndex++;
		}
		return hpAddr1;
	} // fillHeapMsg
	
	private int sendHpMsgs() {
		hpIndex = 0;
		for (int i = 0; i < nHeapMsgs; i++) {
			AgillaHeapMsgJ msg = new AgillaHeapMsgJ(cAgent.getID());
			
			int rhpIndex = fillHeapMsg(msg);
			Debugger.dbg("AgentSender", "HeapMsg: \n" + msg + "\n\n");
			
			int nTries = 0;
			while(nTries < AGILLA_MIGRATE_NUM_TIMEOUTS) {
				Debugger.dbg("AgentSender", "Sending heap message to " + dest + "...");
				sendMsg(msg);
				int nBadAcks = 0;
				boolean success = false;
				while(!success) {
					waitForAck();
					if (ackMsg == null)
						break;
					else {
						if (ackMsg instanceof AgillaAckHeapMsgJ) {
							AgillaAckHeapMsgJ ack = (AgillaAckHeapMsgJ)ackMsg;
							if (ack.getID().equals(cAgent.getID()) && ack.getAddr1() == rhpIndex) {
								if (ack.getAccept() == AGILLA_ACCEPT) {
									Debugger.dbg("AgentSender", "Receive ACK for heap msg.");
									success = true;
								}
								break;
							} else {
								if (++nBadAcks == AGILLA_MIGRATE_NUM_BAD_ACKS) {
									Debugger.dbg("AgentSender.sendHpMsgs()", "Exceeded maximum number of bad acknowledgements.");
									return FAIL;
								}
							}
						}
					}
				}
				if (success)
					break;
				else
					nTries++;
			}
			
			if (nTries == AGILLA_MIGRATE_NUM_TIMEOUTS) {
				Debugger.dbg("AgentSender", "Exceeded number of timeouts while sending heap messages.");
				return FAIL;
			}
		}
		Debugger.dbg("AgentSender", "Successfully sent heap messages.");
		return SUCCESS;
	}
	
	private void fillOpStackMsg(AgillaOpStackMsgJ msg) {
		OpStack os = cAgent.getOpStack();
		int numWordsInMsg = 0;
		
		try {
			while (osIndex < cAgent.getOpStack().size() &&
				   msg.size() + os.get(osIndex).getSize() + 1 < AGILLA_OS_MSG_SIZE) {
				msg.addVar(os.get(osIndex++));
			}
		} catch (OpStackException e) {
			e.printStackTrace();
			System.exit(0);
		}
	} // fillOpStackMsg
	
	private int sendOsMsgs() {
		osIndex = 0;
		for (int which = 0; which < nOSMsgs; which++) {
			int startAddr = osIndex;
			AgillaOpStackMsgJ msg = new AgillaOpStackMsgJ(cAgent.getID(), TOS_LOCAL_ADDRESS, osIndex);
			fillOpStackMsg(msg);
			Debugger.dbg("AgentSender", "OsMsg " + which + ": \n" + msg + "\n\n");
			
			int nTries = 0;
			while(nTries < AGILLA_MIGRATE_NUM_TIMEOUTS) {
				Debugger.dbg("AgentSender", "Sending opStack message " + which + " to " + dest + "...");
				sendMsg(msg);
				boolean success = false;
				int nBadAcks = 0;
				Debugger.dbg("AgentSender", "Awaiting ACK for opStack message " + which + "...");
				while (!success) {
					waitForAck();
					if (ackMsg == null) {
						Debugger.dbg("AgentSender", "Failed to receive ACK for opstack msg " + which + "...");
						break;
					} else {
						if (ackMsg instanceof AgillaAckOpStackMsgJ) {
							AgillaAckOpStackMsgJ ack = (AgillaAckOpStackMsgJ)ackMsg;
							if (ack.getID().equals(cAgent.getID()) && ack.getStartAddr() == startAddr) {
								if (ack.getAccept() == AGILLA_ACCEPT)
									success = true;
								break;
							} else {
								if (++nBadAcks == AGILLA_MIGRATE_NUM_BAD_ACKS) {
									Debugger.dbg("AgentSender.sendHpMsgs()", "Exceeded maximum number of bad acknowledgements.");
									return FAIL;
								}
							}
						}
					}
				}
				if (success)
					break;
				else
					nTries++;
			}
			if (nTries == AGILLA_MIGRATE_NUM_TIMEOUTS) {
				Debugger.dbg("AgentSender", "Exceeded number of timeouts while sending opstack messages.");
				return FAIL;
			}
		}
		Debugger.dbg("AgentSender", "Successfully sent OS messages.");
		return SUCCESS;
	}
	
	/**
	 *  The sender thread sits in a loop sending agents placed into the queue.
	 * */
	public void run() {
		while(true) {
			synchronized(queue) {  // wait for next agent to send
				if (queue.size() == 0) {
					try {
						queue.wait();
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
			}
			
			if (queue.size() == 0)
				continue;
			else {
				PendingAgent pAgent = (PendingAgent)queue.remove(0);
				this.cAgent = pAgent.agent;
				this.dest = pAgent.dest;
				
				
				this.nCodeBlocks = nCodeBlocks(cAgent);
				this.nHeapMsgs = nHeapMsgs(cAgent);
				this.nOSMsgs = nOSMsgs(cAgent);
				this.nRxnMsgs = nRxnMsgs(cAgent);
				
				Debugger.dbg("AgentSender", "nCodeBlocks = " + nCodeBlocks);
				Debugger.dbg("AgentSender", "nHeapMsgs = " + nHeapMsgs);
				Debugger.dbg("AgentSender", "nOSMsgs = " + nOSMsgs);
				
				if (sendStateMsg() == SUCCESS)
					if (sendCodeMsgs() == SUCCESS)
						if (nHeapMsgs == 0 || (nHeapMsgs > 0 && sendHpMsgs() == SUCCESS))
							if (nOSMsgs == 0 || (nOSMsgs > 0 && sendOsMsgs() == SUCCESS)) {
								Debugger.dbg("AgentSender", "Done sending agent.");
								continue;
							}
				Debugger.dbg("AgentSender", "ERROR: Failed to send agent!");
				javax.swing.JOptionPane.showMessageDialog(null, "Failed to send agent.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
				//engine.runAgent(cAgent);
			}
		}
	}
	
	private void sendMsg(MessageJ msg) {
		ackMsg = null;
		try {
			sni.send(msg);// send state
			timeoutTimer = new TimeoutTimer(lock, AGILLA_SNDR_RXMIT_TIMER);
		} catch(Exception e) {
			e.printStackTrace();
			return;
		}
	}
	
	private void waitForAck() {
		synchronized(lock) {
			if (ackMsg == null) {
				try {
					lock.wait();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	private int nCodeBlocks(Agent agent) {
		int result = agent.codeSize() / AGILLA_CODE_BLOCK_SIZE;
		if(result * AGILLA_CODE_BLOCK_SIZE < agent.codeSize())
			result++;
		return result;
	}
	
	private short nHeapMsgs(Agent agent) {
		int counter = 0, numBytes = 0;
		AgillaStackVariable[] heap = agent.getHeap();
		
		for (int i = 0; i < AGILLA_HEAP_SIZE; i++) {
			if (heap[i].getType() != AGILLA_TYPE_INVALID) {
				int nextSize = heap[i].getSize() + 2;
				if (numBytes + nextSize < AGILLA_HEAP_MSG_SIZE) {
					numBytes += nextSize;
				} else {
					numBytes = nextSize;
					counter++;
				}
			}
		}
		if (numBytes == 0)
			return (short)counter;
		else
			return (short)(counter + 1);
	}
	
	private short nOSMsgs(Agent agent)  {
		int counter = 0, numBytes = 0;
		OpStack os = agent.getOpStack();
		try {
			for (int i = 0; i < os.size(); i++) {
				AgillaStackVariable sv = os.get(i);
				int nextSize = sv.getSize() + 1;
				if (numBytes + nextSize < AGILLA_OS_MSG_SIZE) {
					numBytes += nextSize;
				} else {
					numBytes = nextSize;
					counter++;
				}
			}
		} catch(OpStackException e) {
			e.printStackTrace();
			System.exit(0);
		}
		if (numBytes == 0)
			return (short)counter;
		else
			return (short)(counter+1);
	}
	
	private short nRxnMsgs(Agent agent) {
		return (short)0;
	}
	
	/**
	 *  Encapsulates an agent context and the destination it wants migrate to.
	 */
	private class PendingAgent {
		Agent agent;
		AgillaLocation dest;
		
		public PendingAgent(AgillaLocation dest, Agent agent) {
			this.agent = agent;
			this.dest = dest;
		}
	}
}


