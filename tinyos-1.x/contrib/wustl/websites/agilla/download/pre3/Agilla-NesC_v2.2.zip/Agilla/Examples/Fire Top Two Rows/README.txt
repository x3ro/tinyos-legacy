The Fire_Top_2_Rows agent must be injected to the upper-left
corner of the sensor network, at which point it will clone
itself throughout the top two rows. It OUTs a <"fir"> tuple
onto each node it arrives at.

Linear_Adaptive_Fire_Detector moves north until it detects
its neighbor is on fire, at which point it clones to all 
neighbors whose x and y distances are both <= 1 from the 
node on fire.