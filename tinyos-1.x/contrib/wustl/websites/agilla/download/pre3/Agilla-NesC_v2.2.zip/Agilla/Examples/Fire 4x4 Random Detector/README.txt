This is a simple fire detection application where the fire
is the top two columns of a 4x4 network and the fire detector
randomly moves around cloning itself whenever it detects fire.