package edu.wustl.mobilab.agilla.messages;

public class QueryConstants {
	public static final int GLOBAL  = 1;  // whether the query is global or local
}
