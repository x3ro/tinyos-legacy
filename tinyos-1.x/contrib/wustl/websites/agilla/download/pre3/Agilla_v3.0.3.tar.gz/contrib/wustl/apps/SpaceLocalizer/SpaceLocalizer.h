#ifndef _SPACELOCALIZER_H
#define _SPACELOCALIZER_H
  #include <stdio.h>
  #define CC1000_CHANNEL_0 433002000   
  #define CC1000_CHANNEL_2 433616400   
  #define CC1000_CHANNEL_4 434107920   
  #define CC1000_CHANNEL_6 434845141   
#endif
