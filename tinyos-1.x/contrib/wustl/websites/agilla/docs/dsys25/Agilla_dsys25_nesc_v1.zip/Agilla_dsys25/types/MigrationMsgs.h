// $Id: MigrationMsgs.h,v 1.12.2.2 2005/05/06 22:56:35 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */

#include "Agilla.h"
#include "TupleSpace.h"

#ifndef AGILLA_MIGRATION_MSGS_H_INCLUDED
#define AGILLA_MIGRATION_MSGS_H_INCLUDED

#define WEAK TRUE
#define STRONG FALSE

//#define DEBUG_AGENT_RECEIVER  // uncomment to include debug statements
//#define DEBUG_AGENT_SENDER

enum {
  AGILLA_HEAP_MSG_SIZE = 25,
  AGILLA_OS_MSG_SIZE   = 24,

  AGILLA_SNDR_BUFF_SIZE       = 1, // max number of agents being sent
  AGILLA_RCVR_BUFF_SIZE       = 1, // max number of agents arriving


  AGILLA_SNDR_MAX_TIMEOUTS    = 4,
  AGILLA_SNDR_MAX_RETRIES     = 2,

  // Slow
  AGILLA_SNDR_RXMIT_TIMER     = 256, // max time waiting for an ACK
  AGILLA_SNDR_RETRY_TIMER     = 512, // backof period
  AGILLA_RCVR_ABORT_TIMER     = 768, // max time waiting for next message b/f aborting
  AGILLA_RCVR_FIN_TIMER       = 384, // max time waiting for duplicate last message
  

  // Medium
  /*AGILLA_SNDR_RXMIT_TIMER     = 128,  // max time waiting for an ACK
  AGILLA_SNDR_RETRY_TIMER     = 256,  // backof period
  AGILLA_RCVR_ABORT_TIMER     = 512, // max time waiting for next message b/f aborting
  AGILLA_RCVR_FIN_TIMER       = 256, // max time waiting for duplicate last message
  */

  // Fast
  /*AGILLA_SNDR_RXMIT_TIMER     = 128,  // max time waiting for an ACK
  AGILLA_SNDR_RETRY_TIMER     = 128,  // backof period
#ifdef __CYGWIN__
  AGILLA_RCVR_ABORT_TIMER     = 768, // max time waiting for next message b/f aborting
#else
  AGILLA_RCVR_ABORT_TIMER     = 256, // max time waiting for next message b/f aborting
#endif
  AGILLA_RCVR_FIN_TIMER       = 128, // max time waiting for duplicate last message
*/

  /*AGILLA_SNDR_RXMIT_TIMER     = 80,  // max time waiting for an ACK
  AGILLA_SNDR_RETRY_TIMER     = 128,  // backof period
  AGILLA_RCVR_ABORT_TIMER     = 512, // max time waiting for next message b/f aborting
  AGILLA_RCVR_FIN_TIMER       = 120, // max time waiting for duplicate last message
  */

  /*
  AGILLA_SNDR_RXMIT_TIMER     = 75,  // max time waiting for an ACK
  AGILLA_SNDR_RETRY_TIMER     = 128,  // backof period
  AGILLA_RCVR_ABORT_TIMER     = 256, // max time waiting for next message b/f aborting
  AGILLA_RCVR_FIN_TIMER       = 120, // max time waiting for duplicate last message
  */

  // FAILED
  /*AGILLA_SNDR_RXMIT_TIMER     = 64,  // max time waiting for an ACK
  AGILLA_SNDR_RETRY_TIMER     = 128,  // backof period
  AGILLA_RCVR_ABORT_TIMER     = 256, // max time waiting for next message b/f aborting
  AGILLA_RCVR_FIN_TIMER       = 110, // max time waiting for duplicate last message

  AGILLA_SNDR_RXMIT_TIMER     = 32,  // max time waiting for an ACK
  AGILLA_SNDR_RETRY_TIMER     = 64,  // backof period
  AGILLA_RCVR_ABORT_TIMER     = 128, // max time waiting for next message b/f aborting
  AGILLA_RCVR_FIN_TIMER       = 64, // max time waiting for duplicate last message
  */
};

// Agent migration state
typedef enum {
  AGILLA_RECEIVED_NOTHING  = 0,
  AGILLA_RECEIVED_CODE     = 1,
  AGILLA_RECEIVED_STATE    = 2,
  AGILLA_RECEIVED_OPSTACK  = 4,
  AGILLA_RECEIVED_HEAP     = 8,
  AGILLA_RECEIVED_RXN      = 16,
  AGILLA_AGENT_READY = AGILLA_RECEIVED_CODE | AGILLA_RECEIVED_STATE |
                       AGILLA_RECEIVED_OPSTACK | AGILLA_RECEIVED_HEAP |
                       AGILLA_RECEIVED_RXN
} AgillaAgentIntegrity;

//------------------------------------------------------------------------------
// Active message port numbers
enum {
  AM_AGILLASTATEMSG       = 0x10,
  AM_AGILLACODEMSG        = 0x11,
  AM_AGILLAHEAPMSG        = 0x12,
  AM_AGILLAOPSTACKMSG     = 0x13,
  AM_AGILLARXNMSG         = 0X14,
  AM_AGILLAACKSTATEMSG    = 0x15,
  AM_AGILLAACKCODEMSG     = 0x16,
  AM_AGILLAACKHEAPMSG     = 0x17,
  AM_AGILLAACKOPSTACKMSG  = 0x18,
  AM_AGILLAACKRXNMSG      = 0x19,
};

typedef struct AgillaAgentInfo {
  AgillaAgentID id;
  AgillaLocation dest;
  uint16_t numHpMsgs, nCBlocks, nRxnMsgs;
  uint8_t integrity, op;
  AgillaAgentContext* context;
} AgillaAgentInfo;

//------------------------------------------------------------------------------
// Agent migration message contents
typedef struct AgillaStateMsg {
  AgillaLocation dest; // used for geographic routing
  uint16_t replyAddr;           // one-hop reply

  AgillaAgentID id;
  uint8_t op;                 // smove, wmove, sclone, or wclone
  uint8_t  sp;                // stack pointer
  uint16_t pc;                // program counter
  uint16_t condition;         // condition code
  uint16_t codeSize;          // number of bytes of code
  uint8_t numHpMsgs;         // the number of heap messages
  uint8_t numRxnMsgs;        // the number of reaction messages
} AgillaStateMsg;

typedef struct AgillaAckStateMsg {
  AgillaAgentID id;
  uint8_t  accept;  // AGILLA_ACCEPT or AGILLA_REJECT
} AgillaAckStateMsg;

typedef struct AgillaCodeMsg {
  AgillaAgentID id;
  uint16_t replyAddr;
  uint16_t msgNum;
  uint8_t code[AGILLA_CODE_BLOCK_SIZE];
} AgillaCodeMsg;  // 27 bytes

typedef struct AgillaAckCodeMsg {
  AgillaAgentID id;
  uint8_t  accept;  // AGILLA_ACCEPT or AGILLA_REJECT
  uint16_t msgNum;
} AgillaAckCodeMsg;

typedef struct AgillaHeapMsg {
  AgillaAgentID id;    // the ID of the migrating agent
  uint16_t replyAddr;  // the one-hop reply address
  uint8_t data[AGILLA_HEAP_MSG_SIZE]; // [addr][type][dat],...
} AgillaHeapMsg;

typedef struct AgillaAckHeapMsg {
  AgillaAgentID id;
  uint8_t  accept;  // AGILLA_ACCEPT or AGILLA_REJECT
  uint8_t addr1;    // The first heap address
} AgillaAckHeapMsg;

typedef struct AgillaOpStackMsg {
  AgillaAgentID id;
  uint16_t replyAddr;
  uint8_t startAddr;   // the starting address of the data
  uint8_t data[AGILLA_OS_MSG_SIZE];  //[type][dat],...
} AgillaOpStackMsg;

typedef struct AgillaAckOpStackMsg {
  AgillaAgentID id;
  uint8_t accept;     // AGILLA_ACCEPT or AGILLA_REJECT
  uint8_t startAddr;  // the starting address of the data
} AgillaAckOpStackMsg;

typedef struct AgillaRxnMsg {
  uint16_t replyAddr;
  uint8_t msgNum;
  Reaction rxn;           // id, pc, tuple
} AgillaRxnMsg;  // 36 bytes

typedef struct AgillaAckRxnMsg {
  AgillaAgentID id;
  uint8_t  accept;  // AGILLA_ACCEPT or AGILLA_REJECT
  uint8_t msgNum;     // misc info (e.g., which code msg or starting heap address)
} AgillaAckRxnMsg;  // 8 bytes total

#define AGILLA_ACCEPT 1
#define AGILLA_REJECT 0

#endif

