// $Id: VarUtil.java,v 1.1 2005/01/27 22:31:16 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
/**
 * VarUtil.java
 *
 * @author Created by Omnicore CodeGuide
 */

package edu.wustl.mobilab.agilla_dsys25;

import edu.wustl.mobilab.agilla_dsys25.variables.*;

public class VarUtil implements AgillaConstants
{
	/**
	 * Retrieves the fields stored as a byte array.
	 * The byte array must be of the form [vtype], [var], [vtype], [var], ...
	 * startIndex must point to a vtype.
	 */
	public static AgillaStackVariable getField(int startIndex, short[] data) {
		short vtype = data[startIndex++];
		if (vtype == AGILLA_TYPE_VALUE) {
			short val = data[startIndex++];
			val |= (data[startIndex++] << 8);
			return new AgillaValue(val);
		} else if (vtype == AGILLA_TYPE_READING) {
			int rtype = 0, reading = 0;
			rtype = data[startIndex++];
			rtype |= (data[startIndex++] << 8);
			reading = data[startIndex++];
			reading |= (data[startIndex++] << 8);
			return new AgillaReading(rtype, reading);
		} else if (vtype == AGILLA_TYPE_STRING) {
			int string = data[startIndex++];
			string |= (data[startIndex++] << 8);
			return new AgillaString(string);
		} else if (vtype == AGILLA_TYPE_TYPE) {
			int dtype = 0;
			dtype = data[startIndex++];
			dtype |= (data[startIndex++] << 8);
			return new AgillaType(dtype);
		} else if (vtype == AGILLA_TYPE_RTYPE) {
			int stype = 0;
			stype = data[startIndex++];
			stype |= (data[startIndex++] << 8);
			return new AgillaRType(stype);
		} else if (vtype == AGILLA_TYPE_AGENTID) {
			int id = data[startIndex++];
			id |= (data[startIndex++]<< 8);
			return new AgillaAgentID(id);
		} else if (vtype == AGILLA_TYPE_LOCATION) {
			int x, y;
			x = data[startIndex++];
			x |= (data[startIndex++] << 8);
			y = data[startIndex++];
			y |= (data[startIndex++] << 8);
			return new AgillaLocation(x,y);
		} else
			return new AgillaInvalidVariable();
	}
}

