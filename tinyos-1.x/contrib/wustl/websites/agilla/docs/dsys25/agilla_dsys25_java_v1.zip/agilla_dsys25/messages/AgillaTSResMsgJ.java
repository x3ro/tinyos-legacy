// $Id: AgillaTSResMsgJ.java,v 1.3.2.2 2005/06/01 16:54:03 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
package edu.wustl.mobilab.agilla_dsys25.messages;

import edu.wustl.mobilab.agilla_dsys25.*;
import edu.wustl.mobilab.agilla_dsys25.variables.*;

public class AgillaTSResMsgJ  implements MessageJ, AgillaConstants, AgillaOpcodes {
	private AgillaLocation destLoc;
	private short op, success;
	private Tuple tuple;

	public AgillaTSResMsgJ() {
	}

	public AgillaTSResMsgJ(AgillaLocation destLoc, short op, short success,
						   Tuple t)
	{
		this.destLoc = destLoc;
		this.op = op;
		this.success = success;
		this.tuple = t;
	}

	public AgillaTSResMsgJ(AgillaTSResMsg msg) {
		//System.out.println("Creating an AgillaTSResMsgJ from " + msg);
		destLoc = new AgillaLocation(msg.get_destLoc_x(), msg.get_destLoc_y());
		op = msg.get_op();
		success = msg.get_success();
		if (success == 1) {
			tuple = new Tuple(msg.get_tuple_flags());

			short dataIndex = 0;
			short[] tupleData = msg.get_tuple_data();
			int byteIndex = 0;
			for (int i = 0; i < msg.get_tuple_size(); i++) {
				AgillaStackVariable sv = VarUtil.getField(byteIndex, tupleData);
				//System.out.println("Adding field " + i + ": " + sv);
				tuple.addField(sv);
				byteIndex += sv.getSize()+1; // add one for sv type
			}
		}
	}

	public int getType() {
		return AM_AGILLATSRESMSG;
	}

	public net.tinyos.message.Message toTOSMsg() {
		AgillaTSResMsg msg = new AgillaTSResMsg();
		msg.set_destLoc_x(destLoc.getx());
		msg.set_destLoc_y(destLoc.gety());
		msg.set_op(op);
		msg.set_success(success);

		msg.set_tuple_flags(tuple.flags());
		msg.set_tuple_size(tuple.getSize());

		if (success == 1) {
			short dataIndex = 0;
			for (int i = 0; i < tuple.size(); i++) {
				AgillaStackVariable sv = tuple.getField(i);
				short[] bytes = sv.toBytes();
				msg.setElement_tuple_data(dataIndex++, sv.getType());  // save type
				for (int j = 0; j < sv.getSize(); j++) {
					msg.setElement_tuple_data(dataIndex++, bytes[j]);  // save var
				}
			}
		}
		return msg;
	}

	public Tuple getTuple() {
		return tuple;
	}

	public boolean isSuccess() {
		return success == 1;
	}

	private String getString(short op) {
		switch(op) {
			case OProut:
				return "AgillaTSReqMsg: rout";
			case OPrinp:
				return "AgillaTSReqMsg: rinp";
			case OPrrdp:
				return "AgillaTSReqMsg: rrdp";
//			case OPrinpg:
//				return "AgillaTSReqMsg: rinpg";
//			case OPrrdpg:
//				return "AgillaTSReqMsg: rrdpg";
			default:
				return "UNKNOWN";
		}
	}

	public String toString() {
		String result = "AGILLA_TS_RES_MSG:\n";
		result += "\top = " + op + " ("+getString(op)+")\n\t";
		result += "\tdestLoc = " + destLoc + "\n";
		result += "\tsuccess = " + success + "\n";
		result += tuple;
		return result;
	}
}

