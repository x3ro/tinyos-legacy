// $Id: AgillaNbrMsgJ.java,v 1.3.2.2 2005/06/01 16:54:03 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
package edu.wustl.mobilab.agilla_dsys25.messages;

import edu.wustl.mobilab.agilla_dsys25.*;
import edu.wustl.mobilab.agilla_dsys25.variables.*;
import net.tinyos.message.*;
import java.util.Vector;

public class AgillaNbrMsgJ implements MessageJ, AgillaConstants {
	private Vector neighbors = new Vector();
	AgillaLocation bs;
	
	public AgillaNbrMsgJ() {
	}
	
	public void addNeighbor(AgillaLocation nbr) {
		neighbors.add(nbr);
	}
	
	public AgillaNbrMsgJ(AgillaNbrMsg msg) {
		for (int i = 0; i < AGILLA_MAX_NUM_NEIGHBORS; i++) {
			int x = msg.getElement_nbr_x(i);
			int y = msg.getElement_nbr_y(i);
			if (x != 0xffff)
				neighbors.add(new AgillaLocation(x,y));
		}
		bs = new AgillaLocation(msg.get_bs_x(), msg.get_bs_y());
		
	}
	
	public int getType() {
		return AM_AGILLANBRMSG;
	}
	
	public Message toTOSMsg() {
		AgillaNbrMsg msg = new AgillaNbrMsg();
		int i = 0;
		for (; i < neighbors.size(); i++) {
			AgillaLocation curr = (AgillaLocation)neighbors.get(i);
			msg.setElement_nbr_x(i, curr.getx());
			msg.setElement_nbr_y(i, curr.gety());
		}
		if (i < AGILLA_MAX_NUM_NEIGHBORS) {
			msg.setElement_nbr_x(i, 0xffff);
			msg.setElement_nbr_y(i, 0xffff);
			i++;
		}
		msg.set_bs_x(bs.getx());
		msg.set_bs_y(bs.gety());
		return msg;
	}
	
	/**
	 * Returns the number of bytes used in the data field.
	 */
//	public int size() {
//		return 4;
//	}
	
	/**
	 * Returns the address of a particular entry.
	 */
//	public short getAddr(short pos) {
//		HeapItem h = (HeapItem)data.get(pos);
//		return h.pos;
//	}
	
	/**
	 * Returns the data of a particular entry.
	 */
//	public AgillaStackVariable getData(short pos) {
//		HeapItem h = (HeapItem)data.get(pos);
//		return h.sv;
//	}
	
	public String getNbrs() {
	    String result = "";
		for (int i = 0; i < neighbors.size(); i++) {
			AgillaLocation curr = (AgillaLocation)neighbors.get(i);
			result += curr + ", ";
		}
		if (bs.getx() == 0xffff)
			result += "BS = UNKNOWN";
		else
			result += "BS = " + bs; 
		return result;
	}
	public String toString() {
		String result = "NEIGHBOR MESSAGE: ";
		result += getNbrs(); 
		return result;
	}
	
//	private class HeapItem {
//		AgillaStackVariable sv;
//		short pos;
//
//		public HeapItem(AgillaStackVariable sv, short pos) {
//			this.sv = sv;
//			this.pos = pos;
//		}
//	}
}

