// $Id: AgillaOpStackMsgJ.java,v 1.1 2005/01/27 22:31:16 liang Exp $

/* Agilla - A middleware for wireless sensor networks.
 * Copyright (C) 2004, Washington University in Saint Louis
 * By Chien-Liang Fok.
 *
 * Washington University states that Agilla is free software;
 * you can redistribute it and/or modify it under the terms of
 * the current version of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * Agilla is distributed in the hope that it will be useful, but
 * THERE ARE NO WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
 *
 * YOU UNDERSTAND THAT AGILLA IS PROVIDED "AS IS" FOR WHICH NO
 * WARRANTIES AS TO CAPABILITIES OR ACCURACY ARE MADE. THERE ARE NO
 * WARRANTIES AND NO REPRESENTATION THAT AGILLA IS FREE OF
 * INFRINGEMENT OF THIRD PARTY PATENT, COPYRIGHT, OR OTHER
 * PROPRIETARY RIGHTS.  THERE ARE NO WARRANTIES THAT SOFTWARE IS
 * FREE FROM "BUGS", "VIRUSES", "TROJAN HORSES", "TRAP DOORS", "WORMS",
 * OR OTHER HARMFUL CODE.
 *
 * YOU ASSUME THE ENTIRE RISK AS TO THE PERFORMANCE OF SOFTWARE AND/OR
 * ASSOCIATED MATERIALS, AND TO THE PERFORMANCE AND VALIDITY OF
 * INFORMATION GENERATED USING SOFTWARE. By using Agilla you agree to
 * indemnify, defend, and hold harmless WU, its employees, officers and
 * agents from any and all claims, costs, or liabilities, including
 * attorneys fees and court costs at both the trial and appellate levels
 * for any loss, damage, or injury caused by your actions or actions of
 * your officers, servants, agents or third parties acting on behalf or
 * under authorization from you, as a result of using Agilla.
 *
 * See the GNU Lesser General Public License for more details, which can
 * be found here: http://www.gnu.org/copyleft/lesser.html
 */
/**
 * AgiilaOpStackMsgJ.java
 *
 * @author Chien-Liang Fok
 */

package edu.wustl.mobilab.agilla_dsys25.messages;

import java.util.*;
import edu.wustl.mobilab.agilla_dsys25.*;
import edu.wustl.mobilab.agilla_dsys25.variables.*;

public class AgillaOpStackMsgJ implements MessageJ, AgillaConstants  {
	private AgillaAgentID id;
	private int replyAddr;
	private short startAddr;
	private Vector data = new Vector(); // a vector of AgillaStackVariables
	
	private AgillaOpStackMsgJ()  {
	}
	
	public AgillaOpStackMsgJ(AgillaAgentID id, int replyAddr, short startAddr)  {
		this();
		this.id = id;
		this.replyAddr = replyAddr;
		this.startAddr = startAddr;
	}
	
	public AgillaOpStackMsgJ(AgillaOpStackMsg msg)  {
		this.id  = new AgillaAgentID(msg.get_id_id());
		this.replyAddr = msg.get_replyAddr();
		this.startAddr = msg.get_startAddr();

		short[] msgdata = msg.get_data();
		
		int i = 0;
		boolean done = false;
		while (!done && i < msgdata.length - 2) {
			AgillaStackVariable sv = VarUtil.getField(i, msgdata);
			data.add(sv);
			i += sv.getSize()+1;
		}
	}
	
	/**
	 * Returns the number of data bytes used.
	 */
	public int size() {
		int result = 0;
		for (int i = 0; i < data.size(); i++) {
			AgillaStackVariable sv = (AgillaStackVariable)data.get(i);
			result += sv.getSize()+1;
		}
		return result;
	}
	
	public void addVar(AgillaStackVariable v)  {
		data.add(v);
	}
	
	public int getType()  {
		return AM_AGILLAOPSTACKMSG;
	}
	
	public net.tinyos.message.Message toTOSMsg()  {
		AgillaOpStackMsg msg = new AgillaOpStackMsg();
		msg.set_id_id(id.getID());
		msg.set_replyAddr(replyAddr);
		msg.set_startAddr(startAddr);
		int dataIndex = 0;
		
		// the data is stored as ([type], [var])*
		for (int i = 0; i < data.size(); i++) {
			AgillaStackVariable sv = (AgillaStackVariable)data.get(i);
			short[] bytes = sv.toBytes();    // save the variable
			msg.setElement_data(dataIndex++, (short)sv.getType());
			for (int j = 0; j < sv.getSize(); j++) {
				msg.setElement_data(dataIndex++, bytes[j]);
			}
		}
		while (dataIndex < AGILLA_OS_MSG_SIZE) {
			msg.setElement_data(dataIndex++, AGILLA_TYPE_INVALID);
		}
		return msg;
	}
	
	public String toString()  {
		String result = "OPSTACK MESSAGE:\n";
		result += "Start address = " + startAddr + "\n";
		for (int i = 0; i < data.size(); i++) {
			AgillaStackVariable sv = (AgillaStackVariable)data.get(i);
			result += "\tvar" + i + ": " + sv + "\n";
		}
		return result;
	}
}

