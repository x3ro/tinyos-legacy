#ifndef __PCH_h
#define __PCH_h

//#include <mmsystem.h>
//#include <vcl.h>
#include <conio.h>
#include <fcntl.h>
#include <io.h>
#include <iostream.h>

//#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <sys/ioctl.h>
//#include <sys/time.h>
//#include <sys/types.h>
//#include <termio.h>
//#include <unistd.h>
// don't stop here !!! #pragma hdrstop // stop compiling headers here

// application spec headers
#include "Error.h"
#pragma hdrstop // stop compiling headers here

#endif
