#include <stdio.h>

#include "Atmel_base.h"
#include "PartDB.h"


#include "TVicPort.h"


int main3(int argc, char* argv[]){
	return 1;
}