/**
 * File: ServerReceivingThread.java
 *
 * Description:
 * The ServerReceivingThread listens for requests
 * from a connected Aggregator Server.  If a data
 * packet is received, it is sent on to the serial
 * port.
 *
 * Author: Bret Hull
 */

import java.net.*;
import java.io.*;

public class ServerReceivingThread extends Thread
{
  // communications with client
  private Socket              socket        = null;
  private ObjectInputStream   input         = null;
  private ObjectOutputStream  output        = null;
  // host name
  private String              strHstNm      = null;
  // optional gui to send messages
  private ControlWindow       cntrlWindow   = null;
  // thread that writes to serial port
  private SerialPortWriter    portWriter    = null;
  // listen server to which thread is registered
  private ListenServer        lstnSrvr      = null;
  // shutdown flag
  private boolean             bShutdown     = false;

  public ServerReceivingThread ( Socket socket, SerialPortWriter writer, ControlWindow control, ListenServer lstn )
  {
    super("ServerReceivingThread");
    this.socket = socket;
    strHstNm = socket.getInetAddress().toString();
    cntrlWindow = control;
    portWriter = writer;
    lstnSrvr = lstn;
    DEBUG ( "ServerReceivingThread created to service host " + strHstNm );
  }

  private boolean InitConnection ( )
  {
    try {
      //BufferedOutputStream out = new BufferedOutputStream ( socket.getOutputStream() );
      //output = new ObjectOutputStream ( out );
      //output.flush();

      BufferedInputStream in = new BufferedInputStream ( socket.getInputStream() );
      input = new ObjectInputStream ( in );
    }
    catch (IOException e ) {
      e.printStackTrace();
      return false;
    }

      BaseStationInfo info = new BaseStationInfo ( );
      info.location = SerialForward.PACKET_LOCATION;
      lstnSrvr.SendPacket( info, socket );
      //output.writeObject ( info );
      //output.flush();
      DEBUG ( "RECEIVINGTHREAD: Send BaseStationInfo packet" );

    return true;
  }

  public synchronized void run()
  {
    boolean status = true;
    Object currentPckt;
    status = InitConnection ( );
    if ( !status ) {
      bShutdown = true;
    }

    while ( !bShutdown )
    {
      try {
        currentPckt = input.readObject (  );
      }
      catch ( ClassNotFoundException e ) {
        VERBOSE( "RECEIVETHREAD: unknown packet from host " + strHstNm );
        continue;
      }
      catch ( StreamCorruptedException e ) {
        VERBOSE ( "RECEIVETHREAD: stream corrupted" );
        continue;
      }
      catch ( IOException e ) {
        VERBOSE ( "RECEIVETHREAD: unable to read stream from host " + strHstNm );
        bShutdown = true;
        continue;
      }

      if ( currentPckt instanceof DataPckt )
      {
        status = HandleDataPacket ( (DataPckt) currentPckt );
      }
      else if ( currentPckt instanceof BaseStationInfo )
      {
        DEBUG ( "RECEIVETHREAD: received BaseStationInfo packet from host " + strHstNm );
        status = SendBaseStationInfo ( );
        if ( !status ) break;
      }
      else {
        VERBOSE ( "RECEIVETHREAD: unrecognized packet from host " + strHstNm );
      }
    }
    try {
      input.close();
      socket.close();
    } catch (IOException e) {
      DEBUG ( "ServerReceivingThread: connection was closed to host " + strHstNm );
    }
    // thread about to die, remove from listen server receiving threads vector
    DEBUG ("packet forwarder about to unregister");
    lstnSrvr.UnregisterReceiveThread ( this );
    DEBUG ( "ServerReceivingThread shutting-down" );
  }

  private boolean HandleDataPacket ( DataPckt dataPacket )
  {
    DEBUG ( "Packet received from " + strHstNm );
    portWriter.WritePacket( dataPacket.data );
    return true;
  }

  private boolean SendBaseStationInfo (  )
  {
    try {
        BaseStationInfo infoPacket = new BaseStationInfo();
        infoPacket.location = SerialForward.PACKET_LOCATION;
        output.writeObject( infoPacket );
    }
    catch ( IOException e ) {
      DEBUG ( "SeverReceivingThread: unable to send BaseStationInfo packet" );
      return false;
    }
    return true;
  }

  private void ReportMessage ( String msg )
  {
      if ( cntrlWindow == null ) System.out.println (msg);
      else cntrlWindow.AddMessage (msg+"\n");
  }

  private void DEBUG ( String msg )
  {
    if ( SerialForward.debugMode ) { ReportMessage ( msg ); }
  }

  private void VERBOSE ( String msg )
  {
    if ( SerialForward.verboseMode ) { ReportMessage ( msg ); }
  }

  public void Shutdown ( )
  {
    bShutdown = true;
    try{ socket.close(); }
    catch ( IOException e ) { e.printStackTrace(); }
    this.interrupt();
  }

  public String GetHost ( )
  {
    return strHstNm;
  }
}