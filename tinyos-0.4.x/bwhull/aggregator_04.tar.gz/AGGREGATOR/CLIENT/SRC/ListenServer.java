/**
 * File: ListenServer.java
 *
 * Description:
 * The Listen Server is the heart of the serial forwarder.  Upon
 * instantiation, this class spawns the SerialPortReader and the
 * Multicast threads.  As clients connect, this class spawns
 * ServerReceivingThreads as wells as registers the new connection
 * SerialPortReader.  This class also provides the central
 * point of contact for the GUI, allowing the server to easily
 * be shut down
 *
 * Author: Bret Hull
 */

import java.net.*;
import java.io.*;
import javax.comm.*;
import java.util.*;

public class ListenServer extends Thread {

  private static final String CLASS_NAME    = "Listen Server";
  private int                 nPort         = 0;
  private String              commPort      = null;
  private boolean             listening     = true;
  private boolean             bDummyData    = false;
  private boolean             bFileData     = true;
  private SerialPort          serialPort    = null;
  private SerialPortReader    portReader    = null;
  private SerialPortWriter    portWriter    = null;
  private ServerSocket        serverSocket  = null;
  private ControlWindow       cntrlWindow   = null;
  private Vector              rcvThrds      = new Vector ();
  private Vector              pcktFrwrdrs   = new Vector ();
  private MultiCastListen     multicast     = null;

  public ListenServer ( ControlWindow cntrlWindow )
  {
    commPort    = SerialForward.commPort;
    nPort       = SerialForward.serverPort;
    bDummyData  = SerialForward.useDummyData;
    bFileData = SerialForward.useFileData;
    this.cntrlWindow = cntrlWindow;
    if ( cntrlWindow != null ) { cntrlWindow.UpdateNumClients( rcvThrds.size() ); }
  }

  public void run ()
  {
    boolean status;
    // setup the serial port reader/writers
    status = InitSerialPorts ();
    if ( !status ) {
      // an error occurred opening of initializing serial ports
      serialPort = null;
      ListenServerPreExit();
      return;
    }
    // start the serial port reader thread
    portReader.start();

    // open up our server socket
    try { serverSocket = new ServerSocket(nPort); }
    catch (IOException e)
    {
      VERBOSE ( "Could not listen on port: " + nPort );
      ListenServerPreExit();
      return;
    }

    // start multicast listen thread
    if ( SerialForward.multicast )
    {
      multicast = new MultiCastListen ( this, cntrlWindow );
      multicast.start();
    }
    // start listening for connections
    try {
      ServerReceivingThread rcv;
      Socket currentSocket;
      while (listening)
      {
        currentSocket = serverSocket.accept();
        portReader.AddPacketForwarder( currentSocket );
        rcv = new ServerReceivingThread ( currentSocket, portWriter, cntrlWindow, this );
        RegisterReceiveThread ( rcv );
        rcv.start();
      }
      serverSocket.close();
    }
    catch ( IOException e) {
      VERBOSE ("Server Socket closed");
    }
    ListenServerPreExit();
  }

  public void Shutdown ( )
  {
    listening = false;
    try { serverSocket.close(); }
    catch ( IOException e ) { e.printStackTrace(); }
    this.interrupt();
  }

  public void SpawnConnection ( Socket sckt )
  {
    DEBUG ( "Spawning connection based on multicast request");
    portReader.AddPacketForwarder ( sckt );
    ServerReceivingThread rcv = new ServerReceivingThread ( sckt, portWriter, cntrlWindow, this );
    RegisterReceiveThread (rcv);
    rcv.start();
  }

  public synchronized void SetMulticast ( MultiCastListen thrd )
  {
    multicast = thrd;
  }

  private synchronized void RegisterReceiveThread ( ServerReceivingThread thrd )
  {
    rcvThrds.add ( thrd );
    if ( cntrlWindow != null )
    {
      DEBUG ( "Setting num clients to: " + rcvThrds.size() );
      cntrlWindow.UpdateNumClients ( rcvThrds.size() );
    }
    VERBOSE ( "Client connected from host: " + thrd.GetHost() );
  }

  public synchronized void UnregisterReceiveThread ( ServerReceivingThread thrd )
  {
    rcvThrds.remove ( thrd );
    if ( cntrlWindow != null )
    {
      cntrlWindow.UpdateNumClients ( rcvThrds.size() );
    }
    VERBOSE ( "Client disconnected from host: " + thrd.GetHost() );
  }

  private void ShutdownAllReceiveThreads ( )
  {
    ServerReceivingThread thrd;
    while ( !rcvThrds.isEmpty() )
    {
      // one thread should be removed each iteration of
      // the loop
      thrd = (ServerReceivingThread) rcvThrds.firstElement();
      thrd.Shutdown ();
      DEBUG ( "LISTEN SERVER: joining to receive thread");
      try {  thrd.join(); }
      catch (InterruptedException e) { e.printStackTrace(); };
    }
  }

  private boolean InitSerialPorts ( )
  {
    // first open the comm port
    if ( bDummyData ) {
      VERBOSE ("Server sending dummy data");
    }
    else if ( bFileData ) {
      VERBOSE ("Server reading data from file");
    }
    else {
       try {
        OpenCommPort ( );
        VERBOSE ( "Successfully opened comm port: " + commPort );
       }
      catch (Exception e ) {
        VERBOSE ("Unable to open serial port: " + commPort );
        return false;
      }
    }
    // next, setup the serial port readers/writers
    try {
      if ( bDummyData || bFileData )
      {
        portReader = new SerialPortReader ( null , cntrlWindow, pcktFrwrdrs, this );
        portWriter = new SerialPortWriter ( null, cntrlWindow );
      }
      else {
        portReader = new SerialPortReader ( serialPort.getInputStream() , cntrlWindow, pcktFrwrdrs, this );
        portWriter = new SerialPortWriter ( serialPort.getOutputStream(), cntrlWindow );
      }
    }
    catch (IOException e) {
      VERBOSE ( "Unable to get input/output streams");
      return false;
    }
    return true;
  }

  public void SendPacket ( Object pckt, Socket skt )
  {
    Enumeration frwrdrsEnum = pcktFrwrdrs.elements();
    while ( frwrdrsEnum.hasMoreElements() )
    {
      PacketForwarder pf = (PacketForwarder) frwrdrsEnum.nextElement();
      if ( pf.socket == skt )
      {
        pf.SendPacket( pckt );
        DEBUG ( "SENDING PACKET TO HOST");
      }
    }
  }
  private void OpenCommPort() throws NoSuchPortException, PortInUseException, IOException, UnsupportedCommOperationException
  {
    CommPortIdentifier portId = CommPortIdentifier.getPortIdentifier(commPort);
    serialPort = (SerialPort)portId.open(CLASS_NAME, CommPortIdentifier.PORT_SERIAL);
    serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN);
    serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_OUT);
    serialPort.setSerialPortParams(19200, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
  }

  private void ReportMessage ( String msg )
  {
      if ( cntrlWindow == null ) System.out.println (msg);
      else cntrlWindow.AddMessage (msg+"\n");
  }

  private static void ReportMessage ( String msg, ControlWindow wndw )
  {
      if ( wndw == null ) System.out.println (msg);
      else wndw.AddMessage (msg+"\n");
  }

  private void DEBUG ( String msg )
  {
    if ( SerialForward.debugMode ) { ReportMessage ( msg ); }
  }

  private void VERBOSE ( String msg )
  {
    if ( SerialForward.verboseMode ) { ReportMessage ( msg ); }
  }

  private void PrintPortStatus()
  {
    ReportMessage("baud rate: " + serialPort.getBaudRate());
    ReportMessage("data bits: " + serialPort.getDataBits());
    ReportMessage("stop bits: " + serialPort.getStopBits());
    ReportMessage("parity:    " + serialPort.getParity());
  }

  public static void PrintAllPorts( ControlWindow wndw )
  {
    ReportMessage( "--------------------", wndw );
    Enumeration ports = CommPortIdentifier.getPortIdentifiers();

    if (ports == null) {
      ReportMessage("No comm ports found!", wndw );
      return;
    }

    // print out all ports
    ReportMessage( "printing all ports...", wndw );
    while ( ports.hasMoreElements() )
    {
      ReportMessage( "-  " + ((CommPortIdentifier)ports.nextElement()).getName(), wndw );
    }
    ReportMessage( "--------------------", wndw );
  }

  private void ListenServerPreExit ( )
  {
    if ( portReader != null )
    {
      portReader.Shutdown();

      DEBUG ( "LISTEN SERVER: joining to port reader thread");
      try { portReader.join(); }
      catch ( InterruptedException e ) {  }

    }
    if ( multicast != null )
    {
      multicast.Shutdown();
      /*
      DEBUG ("MULTICAST: joing to multicast thread");
      try { multicast.join(1000); }
      catch ( InterruptedException e ) {  }*/

    }
    DEBUG ( "LISTEN SERVER: shutting down all receive threads");
    ShutdownAllReceiveThreads ( );
    if ( serialPort != null )
    {
      serialPort.close();
    }
    VERBOSE ( "LISTEN SERVER SHUTTING-DOWN\n--------------------" );
    if ( cntrlWindow != null )
    {
      cntrlWindow.SetListenServer ( null );
    }
  }
}