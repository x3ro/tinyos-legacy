/**
 * File: SerialPortWriter.java
 *
 * Description:
 * The SerialPortWriter provides functionality to write
 * data to the serial port on which a mote is connected
 *
 * Author: Bret Hull
 */
import java.util.*;
import java.io.*;
import javax.comm.*;

public class SerialPortWriter
{
  OutputStream                  packetStream = null;
  ControlWindow                 cntrlWindow  = null;
  int                           nPackets     = 0;

  public SerialPortWriter ( OutputStream stream, ControlWindow window )
  {
    packetStream = stream;
    this.cntrlWindow = window;
    if ( cntrlWindow != null ) { cntrlWindow.UpdatePacketsWritten( nPackets ); }
  }

  public synchronized void WritePacket ( byte[] packet )
  {
    if (packet.length != SerialForward.PACKET_SIZE)
    {
      // packets must be correct length
      VERBOSE ("Invalid packet size; unable to write packet to serial port");
      return;
    }
    try {
      if ( packetStream != null )
      {
         packetStream.write ( packet );
         nPackets++;
         UpdatePacketsWritten ( );
         DEBUG ( "Packet sent to serial port");
      } else {
        DEBUG ("SerialPortWriter: packetStream null; unable to forward packet");
      }
    }
    catch (IOException e) { VERBOSE ( "Unable to send packet to serial port" ); }
  }

  private void ReportMessage ( String msg )
  {
      if ( cntrlWindow == null ) System.out.println (msg);
      else cntrlWindow.AddMessage (msg+"\n");
  }

  private void UpdatePacketsWritten ( )
  {
    if ( cntrlWindow != null ) cntrlWindow.UpdatePacketsWritten ( nPackets );
  }

  private void DEBUG ( String msg )
  {
    if ( SerialForward.debugMode ) { ReportMessage ( msg ); }
  }

  private void VERBOSE ( String msg )
  {
    if ( SerialForward.verboseMode ) { ReportMessage ( msg ); }
  }
}

