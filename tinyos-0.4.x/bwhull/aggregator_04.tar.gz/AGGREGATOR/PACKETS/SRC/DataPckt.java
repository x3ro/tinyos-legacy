

/**
 * Title:  DataPckt
 * @author Bret Hull
 * @version 1.0
 */

import java.net.*;
import java.io.*;
import java.util.*;

public class DataPckt implements Serializable
{
  public byte[]       data    = null;
  public InetAddress  source  = null;
  public InetAddress  dest    = null;
  public Date         time    = new Date ();
}