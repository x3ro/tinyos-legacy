

/**
 * Title: BaseStationsPckt
 * @author Bret Hull
 * @version 1.0
 */

import java.util.*;
import java.io.*;

public class BaseStationsPckt implements Serializable
{
  public Vector baseStations = new Vector ();
}