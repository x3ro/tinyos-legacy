/**
 * Title: Init.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description:  This class provides various
 * global variables used for defaults and initialization
 * functions run when the program is executed.  This class
 * contains the "Main" function.
 */

import java.io.*;
import javax.swing.*;
import java.awt.*;

public class Init
{
  public static boolean       verboseMode     = true;
  public static boolean       debugMode       = true;
  public static boolean       multicast       = true;
  public static int           appServerPort   = 9002;
  public static int           moteServerPort  = 9001;
  public static int           moteClientPort  = 9000;
  public static boolean       bReadFile       = false;
  public static String        moteFile        = "motes.txt";
  public static int           PACKET_SIZE     = 30;
  public static final byte[]  PACKET_SYNC_DATA        = { 1 };
  public static final byte[]  PACKET_SYNC_LOCATION    = { 2 };
  public static final byte[]  PACKET_SYNC_DESTINATION = { 3 };
  public static final byte[]  PACKET_SYNC_RULE        = { 4 };
  public static final byte[]  PACKET_SYNC_CLEAR_RULE  = { 5 };

  public static String        multicastGroup    = "228.5.6.7";
  public static int           multicastPort     = 6789;
  public static byte          clientMagic       = 50;
  public static byte[]        serverMagic       = { 49, (byte) (moteServerPort & 0xFF), (byte) ((moteServerPort & 0xFF00) >> 8) };

  private static boolean      guiMode         = true;
  private static boolean      displayHelp     = false;
  private static String       APP_NAME        = "Data Aggregator";

  public static void main(String[] args) throws IOException {

    ProcessCommandLineArgs ( args );

    if ( displayHelp )
    {
      PrintHelp ();
    }
    else if ( guiMode )
    {
      System.out.println("Starting in GUI mode\n");
      CreateGui();
    }
    else {
      // no gui, user command line
      RunAggregator( null );
    }
  }

  private static void ProcessCommandLineArgs ( String[] args )
  {
    if ( debugMode ) {
      for ( int i = 0; i < args.length; i++)
      {
        System.out.println(args[i]);
      }
    }
    for ( int i = 0; i < args.length; i++ )
    {
      if ( args[i].equals ( "-no-gui") ) { guiMode = false; }
      else if (args[i].equals ("-appPort" ) )
      {
        i++;
        if ( i < args.length ) { appServerPort = Integer.parseInt(args[i]); }
        else { displayHelp = true; }
      }
      else if (args[i].equals ("-motePort" ) )
      {
        i++;
        if ( i < args.length ) { moteServerPort = Integer.parseInt(args[i]); }
        else { displayHelp = true; }
      }
      else if ( args[i].equals ("-file") )
      {
        bReadFile = true;
        i++;
        if ( i < args.length ) { moteFile = args[i]; }
        else { displayHelp = true; }
      }
      else if ( args[i].equals ("-quiet") ) { verboseMode = false; }
      else if ( args[i].equals ("-debug") ) { debugMode = true; }
      else if ( args[i].equals ("-nomulticast") ) { multicast = false; }
      else { displayHelp = true; }
    }
  }

  private static void PrintHelp ( )
  {
      System.out.println ("optional arguments:");
      System.out.println ("-appPort [port to listen for app requests]");
      System.out.println ("-motePort [port ot listen for mote requests]");
      System.out.println ("-no-gui      = do not display graphic interface");
      System.out.println ("-quiet       = non-verbose mode");
      System.out.println ("-debug       = display debug messages");
      System.out.println ("-nomulticast = disable multicast thread" );
      System.out.println ("-file [file] = read in mote hosts from file" );
  }

  private static void CreateGui ( )
  {
      ControlWindow cntrlWindow = new ControlWindow();
      cntrlWindow.setSize ( new Dimension ( 400,450)  );
      cntrlWindow.addWindowListener ( cntrlWindow );
      cntrlWindow.setVisible( true );
      RunAggregator ( cntrlWindow );
  }

  public static void RunAggregator (ControlWindow wndw )
  {
    DataAggregator dataStore = new DataAggregator ( wndw );
    if (wndw != null) { wndw.SetDataAggregator( dataStore ); }
    MoteListener moteListener = new MoteListener ( moteServerPort, dataStore );
    dataStore.SetMoteListener( moteListener );
    AppListener appListener = new AppListener ( appServerPort, dataStore );
    dataStore.SetAppListener( appListener );

    moteListener.start();
    appListener.start();
    if ( multicast ) {
      MultiCastListen mc = new MultiCastListen ( moteListener, dataStore );
      dataStore.SetMulticast ( mc );
      mc.start();
    }
    if ( bReadFile )
    {
      moteListener.ConnectFromFile();
    }
  }
}