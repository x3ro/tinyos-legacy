
/**
 * Title: FlowData.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description: A FlowData object is merely a collection
 * of counters and other stats that represent the current
 * state of the either an AppFlow or a MoteFlow
 */
import java.net.*;
import java.io.*;

public class FlowData implements Serializable
{
  public  int     rcvdDataPckts                 = 0;
  public  int     rcvdBaseStationInfoPckts      = 0;
  public  int     rcvdBaseStationRequestPckts   = 0;
  public  int     rcvdAppInfoPckts              = 0;
  public  int     sntPckts                      = 0;
  public  InetAddress inet                      = null;
  public  byte[]  address                       = null;
  public  String  host                          = "Unknown";
  public  String  locationText                  = "Unknown";
  public  boolean dsplyState                    = false;

  public String toString ( ) { return host; }
}