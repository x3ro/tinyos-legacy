/**
 * Title: MoteListener.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description: A MoteListener is simply an extension of
 * the Listener class, which spawns MoteFlow threads
 * once a connection with a base station is established.
 */

import java.net.*;
import java.io.*;

public class MoteListener extends Listener
{
  private boolean bReadFile = true;

  public MoteListener ( int nPort, DataAggregator data )
  {
    super ( nPort, data );
    CLASS_NAME = "MoteListener";
  }

  /**
   * Creates a MoteFlow when a connection is initiated
   *
   * @param connection socket through which communication should procede
   */
  public void SpawnThread ( Socket connection )
  {
    dataStore.DEBUG ( CLASS_NAME + " spawning  mote flow for host " + connection.getInetAddress().toString() );
    MoteFlow newMote = new MoteFlow ( connection, dataStore );
    newMote.start();
  }

  /**
   * Spawn connections from IP based in file
   *
   */
  public void ConnectFromFile ( )
  {
    FileReader  moteFile;
    String      currentIP;
    int         currentPort;
    Socket      newSocket;
    MoteFlow    newMote;

    try { moteFile = new FileReader ( Init.moteFile ); }
    catch ( FileNotFoundException e )
    {
      dataStore.VERBOSE( "Unable to find mote connection file: " + Init.moteFile );
      return;
    }

    while ( ( currentIP = extractHost ( moteFile ) ) != null &&
            ( currentPort = ExtractPort( moteFile ) )  != -1 )
    {
      // we're at the end of a line, complete IP has been read
      dataStore.DEBUG( "Read mote IP from file; attempting to connect to host " + currentIP + " port: " + Init.moteClientPort );
      try {
        newSocket = new Socket ( currentIP, currentPort );
        newMote = new MoteFlow ( newSocket, dataStore );
        newMote.start();
        dataStore.VERBOSE( "Connected to mote at host " + currentIP + " and port " + currentPort );
      }
      catch ( IOException e ) {
        dataStore.VERBOSE( "Unable to connect to mote client at IP " + currentIP );
      }
    }
  }

  public void SpawnConnection ( Socket sckt )
  {
    dataStore.DEBUG( "Received multicast request, connecting to mote");

    MoteFlow newMote = new MoteFlow ( sckt, dataStore );
    newMote.start();
    dataStore.VERBOSE( "Connected to mote at host " + sckt.getInetAddress().toString() );
  }

  private String extractHost ( FileReader reader )
  {
    int c;
    String currentIP = "";
    try {
      while ( ( c = reader.read() ) != -1 )
      {
        if ( c != '\n' && c != '\r' )
        {
          currentIP += (char)c;
        }
        else {
          reader.read();
          // found a complete IP
          return currentIP;
        }
      }
    }
    catch ( IOException e ) {
      e.printStackTrace();
    }
    // end of file
    return null;
  }

  private int ExtractPort ( FileReader reader )
  {
    int c;
    String currentPort = "";
    try {
      while ( ( c = reader.read() ) != -1 )
      {
        if ( c != '\n' && c != '\r' )
        {
          currentPort += (char)c;
        }
        else {
          reader.read();
          // found a complete IP
          return Integer.parseInt(currentPort);
        }
      }
    }
    catch ( IOException e ) {
      e.printStackTrace();
    }
    // end of file
    return -1;
  }
}