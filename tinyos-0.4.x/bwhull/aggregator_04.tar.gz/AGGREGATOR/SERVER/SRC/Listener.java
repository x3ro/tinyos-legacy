/**
 * Title: Listener.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description:  A Listener uses a server socket to
 * answer connection requests by spawning threads
 * as implemented in a non-abstract version of this
 * class (AppListener, MoteListener)
 *
 */

import java.net.*;
import java.io.*;

public abstract class Listener extends Thread
{
  private ServerSocket        socket    = null;
  private int                 nPort;
  // shared memory data structure handling connections
  protected DataAggregator    dataStore = null;
  protected String            CLASS_NAME = "Listener";
  private boolean             bShutdown = false;

  /**
   * Manages a server socket on the argument port
   *
   * @param nPort port number to listen on
   */
  public Listener ( int port, DataAggregator data )
  {
    nPort = port;
    dataStore = data;
  }

  /**
   * Registers flows with the DataAggregator once
   * a connection is made
   */
  public void run ( )
  {
    dataStore.DEBUG( "Initiating " + CLASS_NAME + " on port " + nPort );
    // open the server socket
    try { socket = new ServerSocket ( nPort ); }
    catch ( IOException e )
    {
      dataStore.VERBOSE ( CLASS_NAME + " unable to open port " + nPort );
      dataStore.VERBOSE ( CLASS_NAME + " exiting" );
      return;
    }

    // listen for incoming connections
    Socket currentConnection = null;
    while ( !bShutdown )
    {
      try { currentConnection = socket.accept(); }
      catch ( IOException e )
      {
        dataStore.VERBOSE ( CLASS_NAME + " server socket closed" );
        break;
      }
      SpawnThread ( currentConnection );
    }

    dataStore.VERBOSE ( CLASS_NAME + " exiting" );
  }

  /**
   * Terminate this MoteListener
   */
  public void Shutdown ( )
  {
    bShutdown = true;
    PreExit ( );
    this.interrupt();
  }

  private void PreExit ( )
  {
    if ( socket != null ) {
      try { socket.close(); }
      catch ( IOException e )
      {
        e.printStackTrace();
      }
    }
  }

   /**
    * Abstract Method that creates either an AppFlow
    * or a MoteFlow after a connection is initiated
    *
    * @param connection the socket on which the spawned thread should communicate
    */
  abstract void SpawnThread ( Socket connection );
}


