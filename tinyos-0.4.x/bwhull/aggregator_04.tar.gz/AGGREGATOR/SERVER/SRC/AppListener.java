/**
 * Title: AppListener.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description: An AppListener is simply an extension of
 * the Listener class, which spawns AppFlow threads
 * once a connection with an appilcation is established.
 */

import java.net.*;

public class AppListener extends Listener
{

  public AppListener ( int nPort, DataAggregator data )
  {
    super ( nPort, data );
    CLASS_NAME = "AppListener";
  }

  /**
   * Creates an AppFlow when a connection is initiated
   *
   * @param connection socket through which communication should procede
   */
  public void SpawnThread ( Socket connection )
  {
    dataStore.DEBUG ( CLASS_NAME + " spawning  AppFlow flow for host " + connection.getInetAddress().toString() );
    AppFlow newApp = new AppFlow ( connection, dataStore );
    newApp.start();
  }
}