/**
 * Title: MultiCastListen.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description: The MultiCastListen implements a thread
 * that sends out a heartbeat pulse upon initiation
 * and then listens for heartbeat pulses from Forwarding
 * Clients.
 */

import java.net.*;
import java.io.*;

public class MultiCastListen extends Thread
{

  private   InetAddress       groupInet     = null;
  private   MulticastSocket   mcSocket      = null;
  private   boolean           bShutdown     = false;
  private   MoteListener      moteLstnr     = null;
  private   ControlWindow     cntrlWndw     = null;
  private   DataAggregator    dataStore     = null;

  public MultiCastListen( MoteListener lstn, DataAggregator data )
  {
    dataStore = data;
    moteLstnr = lstn;
    dataStore.SetMulticast ( this );
  }

  public void run ( )
  {
    dataStore.DEBUG ("MULTICAST: starting listen thread");
    try { groupInet = InetAddress.getByName( Init.multicastGroup ); }
    catch ( UnknownHostException e ) { dataStore.DEBUG ( "UnknownHostException: host = " + Init.multicastGroup ); }

    try {
      mcSocket = new MulticastSocket ( Init.multicastPort );
      mcSocket.joinGroup( groupInet );

      SendMultiCastAnnounce ( );

      Socket newServer = null;
      byte[] buf = new byte[3];
      DatagramPacket currentPckt = new DatagramPacket ( buf, buf.length);

      while ( !bShutdown )
      {
        mcSocket.receive( currentPckt );
        if ( currentPckt.getData()[0] == Init.clientMagic )
        {
          // an aggregator server is up
          int serverPort = currentPckt.getData()[1] | ( ((int) currentPckt.getData()[2]) << 8 );
          dataStore.DEBUG( "MULTICAST: client heartbeat detected from host: " + currentPckt.getAddress().toString() + " and port: " + serverPort);
          try {
            newServer = new Socket ( currentPckt.getAddress(), serverPort );
            moteLstnr.SpawnConnection ( newServer );
          }
          catch ( IOException e ) {
            dataStore.DEBUG("MULTICAST: Unable to spawn connection");
          }
        }
      }
      mcSocket.leaveGroup(groupInet);
      mcSocket.close();
    }
    catch ( IOException e ) {
      dataStore.DEBUG ( "MULTICAST: connection closed");
    }
    dataStore.SetMulticast ( null );
    dataStore.DEBUG ("MULTICAST: exiting");
  }

  public void SendMultiCastAnnounce ( )
  {
    DatagramPacket pckt = new DatagramPacket ( Init.serverMagic, Init.serverMagic.length, groupInet, Init.multicastPort );
    try { mcSocket.send( pckt ); }
    catch ( IOException e ) {
      dataStore.DEBUG ("MULTICAST: unable to send announce packet");
    }
  }

  public void Shutdown ( )
  {
    bShutdown = true;
    try {
      mcSocket.leaveGroup( groupInet );
      mcSocket.close();
    }
    catch ( IOException e ) { e.printStackTrace(); }
    this.interrupt();
  }

}