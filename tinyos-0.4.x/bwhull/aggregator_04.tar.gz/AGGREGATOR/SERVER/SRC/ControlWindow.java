import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.tree.*;
import javax.swing.event.*;

/**
 * Title: ControlWindow.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description: This class implements the GUI
 * for the DataAggregator
 */



public class ControlWindow extends JFrame implements WindowListener
{
  public static final String ICON_TITLE_BAR   = "mote.gif";

  DataAggregator dataStore = null;
  ImageIcon iconTitleBar = new ImageIcon ( ICON_TITLE_BAR );
  JMenuBar menuBar = new JMenuBar();
  JMenu menuFile = new JMenu();
  JMenuItem itemQuit = new JMenuItem();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JScrollPane scrlPnlMotes = new JScrollPane();
  GridLayout gridLayout1 = new GridLayout();
  JPanel pnlConnection = new JPanel();
  JScrollPane scrlPnlApps = new JScrollPane();
  DefaultMutableTreeNode moteRoot = new DefaultMutableTreeNode ( "Connected Mote Base Stations" );
  DefaultMutableTreeNode appRoot = new DefaultMutableTreeNode ( "Connected Apps" );
  DefaultTreeModel treeModelMotes = new DefaultTreeModel ( moteRoot );
  DefaultTreeModel treeModelApps = new DefaultTreeModel ( appRoot );
  JTree treeMotes = new JTree( treeModelMotes );
  JTree treeApps = new JTree( treeModelApps );

  GridLayout gridLayout2 = new GridLayout();
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JTextArea mssgArea = new JTextArea();
  JScrollPane scrlPnlMsgs = new JScrollPane();
  JPanel pnlSetup = new JPanel();
  GridLayout gridLayout4 = new GridLayout();
  JLabel lblAppPort = new JLabel();
  JTextField fldAppPort = new JTextField();
  JLabel lblMotePort = new JLabel();
  JTextField fldMotePort = new JTextField();
  JCheckBox cbDebug = new JCheckBox();
  JCheckBox cbVerbose = new JCheckBox();
  JLabel lblFile = new JLabel();
  JTextField fldFile = new JTextField();
  JMenu jMenu1 = new JMenu();
  JMenuItem jMenuItem1 = new JMenuItem();
  JMenuItem jMenuItem2 = new JMenuItem();
  JMenuItem jMenuItem3 = new JMenuItem();
  JButton bttnSave = new JButton();
  JMenuItem jMenuItem4 = new JMenuItem();
  JMenuItem jMenuItem5 = new JMenuItem();
  JPanel pnlDetails = new JPanel();
  JLabel lblDataNum = new JLabel();
  JLabel lblDataPckts = new JLabel();
  JLabel lblBasePckts = new JLabel();
  JLabel lblSntPcktsNum = new JLabel();
  JLabel lblSntPckts = new JLabel();
  GridLayout gridLayout3 = new GridLayout();
  JLabel lblBasePcktsNum = new JLabel();
  JPanel pnlMoteDetails = new JPanel();
  JLabel lblAppDataNum = new JLabel();
  JLabel lblAppDataPckts = new JLabel();
  JLabel lblAppInfoPckts = new JLabel();
  JLabel lblBaseRequestNum = new JLabel();
  JLabel lblBaseRequest = new JLabel();
  GridLayout gridLayout5 = new GridLayout();
  JLabel lblAppInfoPcktsNum = new JLabel();
  JPanel pnlAppDetails = new JPanel();
  GridLayout gridLayout6 = new GridLayout();
  JLabel lblMoteDetails = new JLabel();
  JLabel lblAppDetails = new JLabel();
  JLabel lblMoteHost = new JLabel();
  JLabel lblAppHost = new JLabel();
  JLabel lblAppFrwrdPckts = new JLabel();
  JLabel lblFrwrdPcktsNum = new JLabel();
  JCheckBox cbMulticast = new JCheckBox();
  JTextField fldMulticastGrp = new JTextField();
  JLabel lblMulticastGrp = new JLabel();
  JLabel lblMulticastPort = new JLabel();
  JTextField fldMulticastPort = new JTextField();
  JMenuItem jMenuItem6 = new JMenuItem();

  public ControlWindow() {
    super ( "DataAggregator Server" );
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    menuFile.setText("File");
    itemQuit.setText("Quit");
    itemQuit.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        itemQuit_actionPerformed(e);
      }
    });

    this.setIconImage( iconTitleBar.getImage() );
    this.setJMenuBar(menuBar);
    this.getContentPane().setLayout(borderLayout1);
    gridLayout1.setColumns(3);
    pnlConnection.setLayout(gridLayout1);
    pnlConnection.setPreferredSize(new Dimension(300, 300));
    jPanel1.setLayout(gridLayout2);
    gridLayout2.setRows(2);
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(1);
    jPanel1.setPreferredSize(new Dimension(600, 500));
    treeApps.setFont(new java.awt.Font("Dialog", 0, 10));
    treeMotes.setFont(new java.awt.Font("Dialog", 0, 10));
    jTabbedPane1.setTabPlacement(JTabbedPane.BOTTOM);
    pnlSetup.setLayout(gridLayout4);
    gridLayout4.setRows(8);
    gridLayout4.setColumns(3);
    lblAppPort.setFont(new java.awt.Font("Dialog", 0, 10));
    lblAppPort.setText("App Listen Port:");
    fldAppPort.setFont(new java.awt.Font("Dialog", 0, 10));
    fldAppPort.setText( new Integer ( Init.appServerPort ).toString() );
    lblMotePort.setFont(new java.awt.Font("Dialog", 0, 10));
    lblMotePort.setText("Mote Listen Port:");
    fldMotePort.setFont(new java.awt.Font("Dialog", 0, 10));
    fldMotePort.setText( new Integer ( Init.moteServerPort ).toString());
    cbDebug.setText("Debug Output");
    cbDebug.setFont(new java.awt.Font("Dialog", 0, 10));
    cbDebug.setSelected( Init.debugMode );
    cbDebug.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        cbDebug_actionPerformed(e);
      }
    });
    cbVerbose.setText("Verbose Output");
    cbVerbose.setFont(new java.awt.Font("Dialog", 0, 10));
    cbVerbose.setSelected( Init.verboseMode );
    cbVerbose.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        cbVerbose_actionPerformed(e);
      }
    });
    lblFile.setFont(new java.awt.Font("Dialog", 0, 10));
    lblFile.setText("File:");
    fldFile.setFont(new java.awt.Font("SansSerif", 0, 10));
    fldFile.setText("motes.txt");
    jMenu1.setText("Connection");
    jMenuItem1.setText("Start Server");
    jMenuItem1.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItem1_actionPerformed(e);
      }
    });
    jMenuItem2.setText("Stop Server");
    jMenuItem2.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItem2_actionPerformed(e);
      }
    });
    jMenuItem3.setText("Connect From File");
    jMenuItem3.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItem3_actionPerformed(e);
      }
    });
    bttnSave.setFont(new java.awt.Font("Dialog", 0, 10));
    bttnSave.setText("Save");
    bttnSave.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        bttnSave_actionPerformed(e);
      }
    });
    jMenuItem4.setText("Disconnect Apps");
    jMenuItem4.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItem4_actionPerformed(e);
      }
    });
    jMenuItem5.setText("Disconnect Motes");
    jMenuItem5.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItem5_actionPerformed(e);
      }
    });
    pnlDetails.setLayout(gridLayout6);
    lblDataNum.setFont(new java.awt.Font("Dialog", 0, 10));
    lblDataNum.setText("0");
    lblDataPckts.setFont(new java.awt.Font("Dialog", 0, 10));
    lblDataPckts.setText("Rcvd Data Packets:");
    lblBasePckts.setFont(new java.awt.Font("Dialog", 0, 10));
    lblBasePckts.setText("Rcvd Base Station Info Pckts:");
    lblSntPcktsNum.setFont(new java.awt.Font("Dialog", 0, 10));
    lblSntPcktsNum.setText("0");
    lblSntPckts.setFont(new java.awt.Font("Dialog", 0, 10));
    lblSntPckts.setText("Data Pckts Sent to Mote:");
    gridLayout3.setRows(12);
    gridLayout3.setColumns(3);
    lblBasePcktsNum.setFont(new java.awt.Font("Dialog", 0, 10));
    lblBasePcktsNum.setText("0");
    pnlMoteDetails.setLayout(gridLayout3);
    lblAppDataNum.setFont(new java.awt.Font("Dialog", 0, 10));
    lblAppDataNum.setText("0");
    lblAppDataPckts.setFont(new java.awt.Font("Dialog", 0, 10));
    lblAppDataPckts.setText("Rcvd Data Pckts:");
    lblAppInfoPckts.setFont(new java.awt.Font("Dialog", 0, 10));
    lblAppInfoPckts.setText("Rcvd AppInfo Pckts:");
    lblBaseRequestNum.setFont(new java.awt.Font("Dialog", 0, 10));
    lblBaseRequestNum.setText("0");
    lblBaseRequest.setFont(new java.awt.Font("Dialog", 0, 10));
    lblBaseRequest.setText("Rcvd BaseStations Request Pckt:");
    gridLayout5.setColumns(3);
    gridLayout5.setRows(12);
    lblAppInfoPcktsNum.setFont(new java.awt.Font("Dialog", 0, 10));
    lblAppInfoPcktsNum.setText("0");
    pnlAppDetails.setLayout(gridLayout5);
    lblMoteDetails.setFont(new java.awt.Font("Dialog", 1, 14));
    lblMoteDetails.setText("Mote Details:");
    lblAppDetails.setFont(new java.awt.Font("Dialog", 1, 14));
    lblAppDetails.setText("App Details:");
    lblMoteHost.setFont(new java.awt.Font("Dialog", 0, 10));
    lblMoteHost.setText("Host:");
    lblAppHost.setFont(new java.awt.Font("Dialog", 0, 10));
    lblAppHost.setText("Host:");
    lblAppFrwrdPckts.setFont(new java.awt.Font("Dialog", 0, 10));
    lblAppFrwrdPckts.setText("Pckts Forwarded to App:");
    lblFrwrdPcktsNum.setFont(new java.awt.Font("Dialog", 0, 10));
    lblFrwrdPcktsNum.setText("0");
    cbMulticast.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        cbMulticast_actionPerformed(e);
      }
    });
    cbMulticast.setSelected(Init.multicast);
    cbMulticast.setFont(new java.awt.Font("Dialog", 0, 10));
    cbMulticast.setText("Multicast");
    mssgArea.setFont(new java.awt.Font("Dialog", 0, 10));
    fldMulticastGrp.setText( Init.multicastGroup );
    fldMulticastGrp.setFont(new java.awt.Font("SansSerif", 0, 10));
    lblMulticastGrp.setText("Multicast Group:");
    lblMulticastGrp.setFont(new java.awt.Font("Dialog", 0, 10));
    lblMulticastPort.setFont(new java.awt.Font("Dialog", 0, 10));
    lblMulticastPort.setText("Multicast Port:");
    fldMulticastPort.setFont(new java.awt.Font("Dialog", 0, 10));
    fldMulticastPort.setText(new Integer ( Init.multicastPort ).toString() );
    jMenuItem6.setText("Send MC Announce");
    jMenuItem6.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItem6_actionPerformed(e);
      }
    });
    menuBar.add(menuFile);
    menuBar.add(jMenu1);
    menuFile.add(itemQuit);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(pnlConnection, null);
    pnlConnection.add(scrlPnlMotes, null);
    pnlConnection.add(scrlPnlApps, null);
    jPanel1.add(jTabbedPane1, null);
    jTabbedPane1.add(scrlPnlMsgs, "Messages");
    jTabbedPane1.add(pnlSetup, "Setup");
    pnlSetup.add(lblFile, null);
    pnlSetup.add(fldFile, null);
    pnlSetup.add(lblAppPort, null);
    pnlSetup.add(fldAppPort, null);
    pnlSetup.add(lblMotePort, null);
    pnlSetup.add(fldMotePort, null);
    pnlSetup.add(lblMulticastGrp, null);
    pnlSetup.add(fldMulticastGrp, null);
    pnlSetup.add(lblMulticastPort, null);
    pnlSetup.add(fldMulticastPort, null);
    pnlSetup.add(cbMulticast, null);
    pnlSetup.add(cbVerbose, null);
    pnlSetup.add(cbDebug, null);
    pnlSetup.add(bttnSave, null);
    jTabbedPane1.add(pnlDetails, "Details");
    pnlDetails.add(pnlMoteDetails, null);
    pnlMoteDetails.add(lblMoteDetails, null);
    pnlMoteDetails.add(lblMoteHost, null);
    pnlMoteDetails.add(lblDataPckts, null);
    pnlMoteDetails.add(lblDataNum, null);
    pnlMoteDetails.add(lblBasePckts, null);
    pnlMoteDetails.add(lblBasePcktsNum, null);
    pnlMoteDetails.add(lblSntPckts, null);
    pnlMoteDetails.add(lblSntPcktsNum, null);
    pnlDetails.add(pnlAppDetails, null);
    pnlAppDetails.add(lblAppDetails, null);
    pnlAppDetails.add(lblAppHost, null);
    pnlAppDetails.add(lblAppDataPckts, null);
    pnlAppDetails.add(lblAppDataNum, null);
    pnlAppDetails.add(lblAppInfoPckts, null);
    pnlAppDetails.add(lblAppInfoPcktsNum, null);
    pnlAppDetails.add(lblBaseRequest, null);
    pnlAppDetails.add(lblBaseRequestNum, null);
    pnlAppDetails.add(lblAppFrwrdPckts, null);
    pnlAppDetails.add(lblFrwrdPcktsNum, null);
    scrlPnlMsgs.getViewport().add(mssgArea, null);
    scrlPnlApps.getViewport().add(treeApps, null);
    scrlPnlMotes.getViewport().add(treeMotes, null);
    jMenu1.add(jMenuItem1);
    jMenu1.add(jMenuItem2);
    jMenu1.add(jMenuItem3);
    jMenu1.add(jMenuItem4);
    jMenu1.add(jMenuItem5);
    jMenu1.add(jMenuItem6);
    treeMotes.getSelectionModel().setSelectionMode( TreeSelectionModel.SINGLE_TREE_SELECTION );
    treeMotes.addTreeSelectionListener( new TreeSelectionListener () {
      public void valueChanged ( TreeSelectionEvent e) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) treeMotes.getLastSelectedPathComponent();
        if ( node == null ) return;
        else if ( node == moteRoot ) return;
        else {
          while ( (DefaultMutableTreeNode) node.getParent() != moteRoot )
          {
            node = (DefaultMutableTreeNode) node.getParent();
          }
          MoteFlow selectedMote = (MoteFlow) node.getUserObject();
          if ( dataStore != null ) { dataStore.SetSelectedMote ( selectedMote ); }
          UpdateMoteDetails ( selectedMote.GetDetails () );
        }
      }
    });
    treeApps.getSelectionModel().setSelectionMode( TreeSelectionModel.SINGLE_TREE_SELECTION );
    treeApps.addTreeSelectionListener( new TreeSelectionListener () {
      public void valueChanged ( TreeSelectionEvent e) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) treeApps.getLastSelectedPathComponent();
        if ( node == null ) return;
        else if ( node == appRoot ) return;
        else {
          while ( (DefaultMutableTreeNode) node.getParent() != appRoot )
          {
            node = (DefaultMutableTreeNode) node.getParent();
          }
          AppFlow selectedApp = (AppFlow) node.getUserObject();
          dataStore.SetSelectedApp ( selectedApp );
          UpdateAppDetails ( selectedApp.GetDetails () );
        }
      }
    });
    DefaultTreeCellRenderer renderer = new DefaultTreeCellRenderer();
    renderer.setLeafIcon(new ImageIcon("moteBullet.gif"));
    treeMotes.setCellRenderer(renderer);
    DefaultTreeCellRenderer renderer2 = new DefaultTreeCellRenderer();
    renderer2.setLeafIcon(new ImageIcon("ruleBullet.gif"));
    treeApps.setCellRenderer(renderer2);
  }

  public synchronized void windowClosing ( WindowEvent e )
  {
    if ( dataStore != null ) {
      dataStore.Shutdown();
    }
    System.out.println ( "Data Aggregator Exited Normally\n" );
    System.exit(1);
  }

  public void windowClosed      ( WindowEvent e ) { }
  public void windowActivated   ( WindowEvent e ) { }
  public void windowIconified   ( WindowEvent e ) { }
  public void windowDeactivated ( WindowEvent e ) { }
  public void windowDeiconified ( WindowEvent e ) { }
  public void windowOpened      ( WindowEvent e ) { }

  public synchronized void AddMessage ( String mssg )
  {
    mssgArea.append(mssg);
  }

  public void AddMoteTreeNode ( DefaultMutableTreeNode node )
  {
    moteRoot.add( node );
    treeModelMotes.reload();
  }

  public void RemoveMoteTreeNode ( DefaultMutableTreeNode node )
  {
    moteRoot.remove( node );
    treeModelMotes.reload();
  }

  public void AddAppTreeNode ( DefaultMutableTreeNode node )
  {
    appRoot.add( node );
    treeModelApps.reload();
  }

  public void RemoveAppTreeNode ( DefaultMutableTreeNode node )
  {
    appRoot.remove( node );
    treeModelApps.reload();
  }

  public void SetAppTreePath ( TreePath path )
  {
    treeApps.collapsePath( path );
  }

  public synchronized void SetMoteTreePath ( TreePath path )
  {
    treeMotes.collapsePath( path );
  }

  public void SetDataAggregator ( DataAggregator data )
  {
    dataStore = data;
  }

  public synchronized void RefreshMoteTree ( )
  {
    treeModelMotes.reload ();
  }

  public synchronized void RefreshAppTree ( )
  {
    treeModelApps.reload ();
  }

  /**
   * connect to motes from file
   */
  void bttnCnnctFile_actionPerformed(ActionEvent e)
  {
    Init.moteFile = fldFile.getText();
    if ( dataStore != null )
    {
      AddMessage ( "Reading motes in from a file\n" );
      dataStore.OpenMotesFromFile ();
    }
    else {
      AddMessage ( "Must start server first\n" );
    }
  }

  /**
   * stop the server
   */
  void bttnStop_actionPerformed(ActionEvent e)
  {
    if ( dataStore != null ) {
      AddMessage ( "DataAggregator shutting-down\n");
      dataStore.Shutdown();
    }
    else {
      AddMessage ( "Server already stopped\n" );
    }
  }

  /**
   * exit the application
   */
  void itemQuit_actionPerformed(ActionEvent e)
  {
    if ( dataStore != null ) {
      dataStore.Shutdown();
    }
    System.out.println ( "Data Aggregator Exited Normally\n" );
    System.exit(1);
  }
  /**
   * start the server
   */
  void bttnStart_actionPerformed(ActionEvent e)
  {
    if ( dataStore == null ) {
      AddMessage ( "Starting server\n" );
      Init.RunAggregator ( this );
    }
    else {
      AddMessage ( "Server already started\n");
    }
  }

  void jMenuItem1_actionPerformed(ActionEvent e)
  {
    if ( dataStore == null ) {
      AddMessage ( "Starting server\n" );
      Init.RunAggregator ( this );
    }
    else {
      AddMessage ( "Server already started\n");
    }
  }

  void jMenuItem2_actionPerformed(ActionEvent e)
  {
    if ( dataStore != null ) {
      AddMessage ( "DataAggregator shutting-down\n");
      dataStore.Shutdown();
    }
    else {
      AddMessage ( "Server already stopped\n" );
    }
  }

  void jMenuItem3_actionPerformed(ActionEvent e)
  {
    Init.moteFile = fldFile.getText();
    if ( dataStore != null )
    {
      AddMessage ( "Reading motes in from a file\n" );
      dataStore.OpenMotesFromFile ();
    }
    else {
      AddMessage ( "Must start server first\n" );
    }
  }

  void cbVerbose_actionPerformed(ActionEvent e)
  {
    Init.verboseMode = cbVerbose.isEnabled();
  }

  void cbDebug_actionPerformed(ActionEvent e)
  {
    Init.debugMode = cbDebug.isEnabled();
  }

  void jMenuItem4_actionPerformed(ActionEvent e)
  {
    if ( dataStore != null )
    {
      dataStore.DisconnectAllApps();
    }
    else {
      AddMessage ( "Server not running\n");
    }
  }

  void jMenuItem5_actionPerformed(ActionEvent e)
  {
    if ( dataStore != null )
    {
      dataStore.DisconnectAllMotes();
    }
    else {
      AddMessage ( "Server not running\n");
    }
  }


  void UpdateMoteDetails ( FlowData data ) {
    lblDataNum.setText( new Integer ( data.rcvdDataPckts ).toString() );
    lblBasePcktsNum.setText( new Integer ( data.rcvdBaseStationInfoPckts ).toString() );
    lblSntPcktsNum.setText( new Integer ( data.sntPckts ).toString() );
    lblMoteHost.setText( "Host: " + data.host );
  }

  void UpdateAppDetails ( FlowData data ) {
    lblAppDataNum.setText( new Integer ( data.rcvdDataPckts ).toString() );
    lblAppInfoPcktsNum.setText( new Integer ( data.rcvdAppInfoPckts ).toString() );
    lblBaseRequestNum.setText( new Integer ( data.rcvdBaseStationRequestPckts ).toString() );
    lblFrwrdPcktsNum.setText( new Integer ( data.sntPckts ).toString () );
    lblAppHost.setText( "Host: " + data.host );
  }

  void cbMulticast_actionPerformed(ActionEvent e)
  {
    Init.debugMode = cbDebug.isSelected();
    Init.verboseMode = cbVerbose.isSelected();
    Init.multicast = cbMulticast.isSelected();
    Init.appServerPort = Integer.parseInt( fldAppPort.getText() );
    Init.moteServerPort = Integer.parseInt( fldMotePort.getText() );
  }

  void bttnSave_actionPerformed(ActionEvent e)
  {

  }

  void jMenuItem6_actionPerformed(ActionEvent e)
  {
    if ( dataStore != null ) { dataStore.SendMulticastHeartBeat (); }
  }
}
