/**
 * Title: MoteFlow.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description:  A MoteFlow represents a connection between
 * a forwarding client (base station) and the server.  Each
 * Flow is a thread that continually receives data from the
 * base station and is fed to the DataAggregator to be forwarded
 * to applications.
 */

import java.net.*;
import java.io.*;
import javax.swing.tree.*;

public class MoteFlow extends Thread
{
  private Socket          connection            = null;
  private ObjectOutputStream    output                = null;
  private ObjectInputStream     input                 = null;
  private DataAggregator  dataStore             = null;

  private boolean         bShutdown             = false;
  private DefaultMutableTreeNode treeNode       = new DefaultMutableTreeNode (this);
  private DefaultMutableTreeNode nodeLocation   = new DefaultMutableTreeNode ("Location: unknown");

  private FlowData        crrntState            = new FlowData();
  /**
   * MoteFlows handle the communication between a specific mote
   *
   * @param connection socket through which communication procedes
   */
  public MoteFlow ( Socket conn, DataAggregator data )
  {
    connection            = conn;
    crrntState.inet       = connection.getInetAddress();
    crrntState.address    = crrntState.inet.getAddress();
    crrntState.host       = crrntState.inet.getHostName ();
    dataStore             = data;

    treeNode.add(nodeLocation);
  }

  /**
   * Sends packet to client on base station host
   *
   * @param packet byte array to be sent
   */
  public void SendPacket ( Object packet )
  {
    try { output.writeObject( packet ); }
    catch ( IOException e )
    {
      dataStore.VERBOSE ( "MoteFlow: unable to send packet, socket closed to " + crrntState.host);
      Shutdown ( );
      return;
    }
  }

  public void SendDataPacket ( DataPckt packet )
  {
    SendPacket ( packet );
    crrntState.sntPckts++;
    if ( crrntState.dsplyState ) { dataStore.UpdateMoteDetails( crrntState ); }
    dataStore.DEBUG ( "MoteFlow: packet sent to host " + crrntState.host );
  }

  /**
   * Starts reading data from socket
   */
  public void run ( )
  {
    try {
      dataStore.VERBOSE ( "MOTEFLOW: running hst: " + crrntState.host );
      // create input stream first
      InputStream in = connection.getInputStream();
      input = new ObjectInputStream ( in );
      // now do the output stream (reverse order on client )
      OutputStream out = connection.getOutputStream();
      output = new ObjectOutputStream ( out );
      // make sure to send header to client
      output.flush();

      dataStore.RegisterMote( this );


      boolean status = true;

      while ( !bShutdown )
      {
        Object currentPckt;
        try {
          currentPckt = input.readObject (  );
        }
        catch ( ClassNotFoundException e ) {
          dataStore.VERBOSE( "MOTEFLOW: unknown packet from host " + crrntState.host );
          continue;
        }
        catch ( StreamCorruptedException e ) {
          dataStore.VERBOSE( "MOTEFLOW: corrupted stream " );
          continue;
        }
        catch ( ClassCastException e ) {
          dataStore.VERBOSE( "MOTEFLOW: classCastException occuring" );
          e.printStackTrace();
          continue;
        }
        UpdatePacketCounts ( currentPckt );
        if ( currentPckt instanceof DataPckt )
        {
          status = HandleDataPacket ( (DataPckt) currentPckt );
        }
        else if ( currentPckt instanceof BaseStationInfo )
        {
          dataStore.DEBUG ( "Receiving BaseStationInfo packet from host " + crrntState.host );
          status = HandleBaseStationInfoPacket ( (BaseStationInfo) currentPckt );
          if ( !status ) bShutdown = true;
        }
        else {
          dataStore.VERBOSE ( "Unrecognized messaged from client at host " + crrntState.host);
        }
      }
    }
    catch ( IOException e )
    {
      dataStore.DEBUG ( "Socket closed on mote flow for host " + crrntState.host );
    }
    PreExit ( );
    dataStore.DEBUG ( "MoteFlow exiting for host " + crrntState.host );
  }

  /**
   * Reads a packet representing mote data from the communications
   * port
   *
   */
  private boolean HandleDataPacket ( DataPckt packet )
  {
    dataStore.PacketReceived( packet );
    return true;
  }

  /**
   * A location sync packet has just been received; read the
   * following packets as location text
   */
  private boolean HandleBaseStationInfoPacket ( BaseStationInfo packet )
  {

    if ( packet.location == null )
    {
      dataStore.VERBOSE( "MOTE: Unable to read location packet" );
      return false;
    }
    crrntState.locationText = packet.location;
    dataStore.DEBUG( "MOTEFLOW: setting location text to: "+ packet.location );
    nodeLocation.setUserObject( "Location: " + crrntState.locationText );
    dataStore.RefreshMoteTree ();

    return true;
  }

  private void UpdatePacketCounts ( Object packet )
  {
    if ( packet instanceof DataPckt ) { crrntState.rcvdDataPckts++; }
    else if ( packet instanceof BaseStationInfo ) { crrntState.rcvdBaseStationInfoPckts++; }
    if ( crrntState.dsplyState ) dataStore.UpdateMoteDetails ( crrntState );
  }

  public FlowData GetDetails ( )
  {
    return crrntState;
  }

  public byte[] GetAddress ( )
  {
    return crrntState.address;
  }

  public void SetDisplayState ( boolean value )
  {
    crrntState.dsplyState = value;
  }

  public String toString ( )
  {
    return crrntState.host;
  }

  /**
   * Terminate this MoteFlow
   */
  public void Shutdown ( )
  {
    bShutdown = true;
    try {
      if ( input != null ) { input.close(); }
      if ( output != null ) { output.close(); }
    }
    catch ( IOException e ) { e.printStackTrace(); }
    this.interrupt();
  }

  public DefaultMutableTreeNode getTreeNode ( )
  {
    return treeNode;
  }


  /**
   * Closes any open streams or sockets
   */
  private void PreExit ( )
  {
    try {
      if ( input != null ) {
        input.close();
        input = null;
      }
      if ( output != null ) {
        output.close();
        output = null;
      }
      if ( connection != null ) {
        connection.close();
        connection = null;
      }
      if ( dataStore != null ) {
        dataStore.UnregisterMote( this );
      }
    }
    catch ( IOException e ) {
      e.printStackTrace ( );
    }
  }
}