import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.tree.*;
import java.net.*;

public class ClientWindow extends JPanel implements WindowListener
{
  Logger client = null;
  BorderLayout borderLayout1 = new BorderLayout();
  boolean               bCommandReady = false;
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JButton buttonConnect = new JButton();
  JTextField fldMskHost = new JTextField();
  JButton bttnSend = new JButton();
  JButton bttnSetMask = new JButton();
  JPanel jPanel1 = new JPanel();
  JLabel labelPort = new JLabel();
  JTextField fieldServer = new JTextField();
  JButton bDisconnect = new JButton();
  JTextField fldMask = new JTextField();
  JTextField fldDstntn = new JTextField();
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel buttonPanel = new JPanel();
  JLabel lblPcktSend = new JLabel();
  JTextField fieldPort = new JTextField();
  JLabel labelServer = new JLabel();
  JLabel lblMask = new JLabel();
  GridLayout gridLayout2 = new GridLayout();
  GridLayout gridLayout1 = new GridLayout();
  JTextField fldPcktSend = new JTextField();
  JLabel lblMskHost = new JLabel();
  JLabel labelLogFile = new JLabel();
  JLabel lblDstntn = new JLabel();
  JTextField fieldLogFile = new JTextField();
  JButton bttnClrMsks = new JButton();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel pnlSetup = new JPanel();
  JLabel labelPackets = new JLabel();
  BorderLayout borderLayout3 = new BorderLayout();
  GridLayout gridLayout3 = new GridLayout();
  DefaultMutableTreeNode motesRoot = new DefaultMutableTreeNode ( "Base Stations (none)" );
  public DefaultMutableTreeNode rulesRoot = new DefaultMutableTreeNode ( "Current Rules (none)" );
  DefaultTreeModel treeModelMotes = new DefaultTreeModel ( motesRoot );
  DefaultTreeModel treeModelRules = new DefaultTreeModel ( rulesRoot );
  JScrollPane jScrollPane1 = new JScrollPane();
  JTree treeMotes = new JTree( treeModelMotes );
  JScrollPane jScrollPane2 = new JScrollPane();
  JTree treeRules = new JTree( treeModelRules );
  JScrollPane msgPanel = new JScrollPane();
  JTextArea msgWndw = new JTextArea();

  public ClientWindow( ) {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {

    this.setLayout(borderLayout1);
    this.setMinimumSize(new Dimension(200, 400));
    this.setPreferredSize(new Dimension(400, 430));
    buttonConnect.setFont(new java.awt.Font("Dialog", 0, 10));
    buttonConnect.setText("Connect");
    buttonConnect.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonConnect_actionPerformed(e);
      }
    });
    fldMskHost.setFont(new java.awt.Font("SansSerif", 0, 10));
    bttnSend.setFont(new java.awt.Font("Dialog", 0, 10));
    bttnSend.setText("Send Packet");
    bttnSend.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        bttnSend_actionPerformed(e);
      }
    });
    bttnSetMask.setFont(new java.awt.Font("Dialog", 0, 10));
    bttnSetMask.setText("Set Mask");
    bttnSetMask.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        bttnSetMask_actionPerformed(e);
      }
    });
    jPanel1.setLayout(borderLayout2);
    labelPort.setFont(new java.awt.Font("Dialog", 0, 10));
    labelPort.setText("Port:");
    fieldServer.setFont(new java.awt.Font("Dialog", 0, 10));
    fieldServer.setText(InitLogger.server);
    bDisconnect.setFont(new java.awt.Font("Dialog", 0, 10));
    bDisconnect.setText("Disconnect");
    bDisconnect.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        bDisconnect_actionPerformed(e);
      }
    });
    fldMask.setText("0");
    fldMask.setFont(new java.awt.Font("Dialog", 0, 10));
    buttonPanel.setLayout(gridLayout1);
    buttonPanel.setMinimumSize(new Dimension(100, 170));
    buttonPanel.setPreferredSize(new Dimension(100, 170));
    lblPcktSend.setFont(new java.awt.Font("Dialog", 0, 10));
    lblPcktSend.setText("Packet To Send:");
    fieldPort.setFont(new java.awt.Font("Dialog", 0, 10));
    fieldPort.setText(Integer.toString( InitLogger.serverPort));
    labelServer.setFont(new java.awt.Font("Dialog", 0, 10));
    labelServer.setText("Server:");
    lblMask.setText("Mask:");
    lblMask.setFont(new java.awt.Font("Dialog", 0, 10));
    gridLayout2.setRows(13);
    gridLayout1.setRows(15);
    fldPcktSend.setFont(new java.awt.Font("Dialog", 0, 10));
    lblMskHost.setFont(new java.awt.Font("Dialog", 0, 10));
    lblMskHost.setText("Base Station:");
    labelLogFile.setText("Log File:");
    lblDstntn.setFont(new java.awt.Font("Dialog", 0, 10));
    lblDstntn.setText("Dest. Base Station:");
    fieldLogFile.setText(InitLogger.strFileName);
    bttnClrMsks.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        bttnClrMsks_actionPerformed(e);
      }
    });
    bttnClrMsks.setText("Clear Masks");
    bttnClrMsks.setFont(new java.awt.Font("Dialog", 0, 10));
    pnlSetup.setLayout(gridLayout2);
    labelPackets.setFont(new java.awt.Font("Dialog", 0, 10));
    labelPackets.setToolTipText("");
    labelPackets.setText("Pckts Rcvd: 0");
    jPanel3.setLayout(borderLayout3);
    jPanel2.setLayout(gridLayout3);
    gridLayout3.setColumns(2);
    jPanel2.setPreferredSize(new Dimension(428, 100));
    this.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jScrollPane1, null);
    jPanel2.add(jScrollPane2, null);
    jScrollPane2.getViewport().add(treeRules, null);
    jScrollPane1.getViewport().add(treeMotes, null);
    this.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(jPanel1, BorderLayout.SOUTH);
    jPanel1.add(fieldLogFile, BorderLayout.CENTER);
    jPanel1.add(labelLogFile, BorderLayout.WEST);
    jPanel3.add(jTabbedPane1, BorderLayout.EAST);
    jTabbedPane1.add(buttonPanel, "Main");
    buttonPanel.add(labelPackets, null);
    buttonPanel.add(buttonConnect, null);
    buttonPanel.add(bDisconnect, null);
    buttonPanel.add(lblMask, null);
    buttonPanel.add(fldMask, null);
    buttonPanel.add(lblMskHost, null);
    buttonPanel.add(fldMskHost, null);
    buttonPanel.add(bttnSetMask, null);
    buttonPanel.add(bttnClrMsks, null);
    buttonPanel.add(lblPcktSend, null);
    buttonPanel.add(fldPcktSend, null);
    buttonPanel.add(bttnSend, null);
    buttonPanel.add(lblDstntn, null);
    buttonPanel.add(fldDstntn, null);
    jTabbedPane1.add(pnlSetup, "Setup");
    pnlSetup.add(labelServer, null);
    pnlSetup.add(fieldServer, null);
    pnlSetup.add(labelPort, null);
    pnlSetup.add(fieldPort, null);
    jPanel3.add(msgPanel, BorderLayout.CENTER);
    msgPanel.getViewport().add(msgWndw, null);

  }

  public synchronized void windowClosing ( WindowEvent e )
  {
    if ( client != null )
    {
      client.Shutdown();
      try { client.join(1000); }
      catch ( InterruptedException ex ) { }
    }
    System.out.println ( "Serial Logger Exited Normally\n" );
    System.exit(1);
  }

  public void windowClosed      ( WindowEvent e ) { }
  public void windowActivated   ( WindowEvent e ) { }
  public void windowIconified   ( WindowEvent e ) { }
  public void windowDeactivated ( WindowEvent e ) { }
  public void windowDeiconified ( WindowEvent e ) { }
  public void windowOpened      ( WindowEvent e ) { }

  public synchronized void AddMessage ( String msg )
  {
    msgWndw.append ( msg );
  }

  public void UpdatePacketsReceived ( int nPackets )
  {
    labelPackets.setText( "Pckts Rcvd: " + nPackets );
  }

  public synchronized void SetClient ( Logger clnt )
  {
    client = clnt;
  }

  void buttonConnect_actionPerformed(ActionEvent e)
  {
    if ( client == null )
    {
      InitLogger.server = fieldServer.getText();
      InitLogger.serverPort = Integer.parseInt ( fieldPort.getText() );
      InitLogger.strFileName = fieldLogFile.getText();

      client = new Logger ( this );
      client.start();
    }
  }

  private void bDisconnect_actionPerformed(ActionEvent e) {
    if ( client != null )
    {
      client.Shutdown ();
    }
  }

  void bttnSetMask_actionPerformed(ActionEvent e)
  {
    if ( client != null )
    {
      String hostName       = fldMskHost.getText();
      InetAddress host      = null;
      try { host = InetAddress.getByName ( hostName ); }
      catch ( UnknownHostException ex ) {
        ex.printStackTrace();
        return;
      }
      String pcktData       = fldMask.getText ();
      byte[] mask           = new byte[ Utility.CountBytes ( pcktData ) ];
      Utility.ParseMask ( pcktData, mask );
      client.AddRule ( mask, host );
    }
  }

  public void RefreshTrees ( )
  {
    treeModelRules.reload();
    treeModelMotes.reload();
  }

  void bttnClrMsks_actionPerformed(ActionEvent e) {
       if ( client != null ) { client.SendClearMasks (); }
  }

  void bttnSend_actionPerformed(ActionEvent e)
  {
    if ( client != null )
    {
      String pcktDest         = fldDstntn.getText();
      InetAddress destination = null;
      try { destination = InetAddress.getByName( pcktDest ); }
      catch ( UnknownHostException ex ) {
        AddMessage ( "LOGGER: unknown destination base station host: " + pcktDest + "\n" );
        return;
      }
      String pcktData         = fldPcktSend.getText ();
      byte[] pckt             = new byte[ Utility.CountBytes ( pcktData ) ];
      Utility.ParseMask ( pcktData, pckt );

      DataPckt dataPacket = new DataPckt ();
      dataPacket.data     =  pckt;
      dataPacket.dest     = destination;

      client.SendDataPacket ( dataPacket );
    }
  }

  public void AddMoteNode ( FlowData info )
  {
    motesRoot.setUserObject( "Motes:");
    DefaultMutableTreeNode node = new DefaultMutableTreeNode ( info );
    motesRoot.add ( node );
    treeModelMotes.reload();
  }

  public void ClearMotes ( )
  {
    motesRoot.removeAllChildren();
    motesRoot.setUserObject( "Motes: (none)");
    treeModelMotes.reload();
  }

  public void ClearRules ( )
  {
    rulesRoot.removeAllChildren();
    rulesRoot.setUserObject( "Rules: (none)" );
    treeModelRules.reload();
  }
}