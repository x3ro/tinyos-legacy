import java.util.*;
import java.net.*;
import java.io.*;


public class Logger extends Thread
{
  // optional gui
  private ClientWindow              clntWndw      = null;
  // flag to kill client
  private boolean                   bShutdown      = false;
  // packet streams from socket
  private ObjectInputStream         packetStream   = null;
  private ObjectOutputStream        output         = null;
  private ObjectOutputStream        fileStream     = null;
  private Socket                    commSocket     = null;
  private InetAddress               localHost      = null;
  private int                       nPackets       = 0;
  private int                       sntPckts       = 0;
  private String                    host           = "Unknown";
  private AppInfo                   myInfo         = new AppInfo ();


  public Logger ( ClientWindow window )
  {
    clntWndw = window;
    myInfo.appName = "Logger";
    if ( clntWndw != null ) { clntWndw.UpdatePacketsReceived ( nPackets ); }
  }

  public void run ()
  {
    // open the log file
    OpenLogFile ( );
    // connect to the serial port forwarding server
    Connect ( );
    SendBaseStationsRequest();
    // Log incoming packets
    GetIncomingPackets ( );
    PreExit ();
    return;
  }

  private void OpenLogFile ( )
  {
    if ( !bShutdown ) {
      try {
        fileStream = new ObjectOutputStream ( new FileOutputStream ( InitLogger.strFileName ) );
        VERBOSE ( "Successfully opened log file: " + InitLogger.strFileName );
      }
      catch ( IOException e )
      {
        if ( InitLogger.debugMode ) { e.printStackTrace(); }
        VERBOSE ( "Unable to write log to file: " + InitLogger.strFileName );
        bShutdown = true;
      }
    }
  }

  private void CloseLogFile ( )
  {
    try { fileStream.close(); }
    catch ( IOException e ) {
      if ( InitLogger.debugMode ) { e.printStackTrace(); }
    }
  }

  private void Connect ( )
  {
    if ( !bShutdown ) {
      try
      {
        DEBUG ( "LOGGER: Connecting to host: " + InitLogger.server + " port: " + InitLogger.serverPort );
        commSocket          = new Socket ( InitLogger.server, InitLogger.serverPort);
        OutputStream out    = commSocket.getOutputStream();
        output              = new ObjectOutputStream ( out );
        output.flush();

        InputStream in      = commSocket.getInputStream ();
        packetStream        = new ObjectInputStream ( in );

        host                = commSocket.getInetAddress().toString();
        localHost           = commSocket.getLocalAddress();
        VERBOSE ( "Successfully connect to host: " + InitLogger.server );
        SendAppInfo ( );
      }
      catch ( Exception e ) {
        if ( InitLogger.debugMode ) { e.printStackTrace(); }
        VERBOSE ( "Unable to connect to host: " + InitLogger.server );
        bShutdown = true;
      }
    }
  }

  private void GetIncomingPackets ( )
  {
    try {
      boolean status             = true;
      Object currentPckt;

      while ( !bShutdown )
      {
        try { currentPckt = packetStream.readObject (  ); }
        catch ( ClassNotFoundException e ) {
          VERBOSE( "LOGGER: unknown packet from host " + host );
          continue;
        }
        catch ( StreamCorruptedException e ) {
          VERBOSE( "LOGGER: corrupted stream " );
          continue;
        }
        if ( currentPckt instanceof DataPckt )
        {
          status = HandleDataPacket ( (DataPckt) currentPckt );
        }
        else if ( currentPckt instanceof BaseStationsPckt )
        {
          status = HandleBaseStationsPacket ( (BaseStationsPckt) currentPckt );
        }
        else {
          VERBOSE ( "Unrecognized messaged from client at host " + host);
        }
      }
    }
    catch ( IOException e )
    {
      DEBUG ( "Socket closed" );
    }
  }

  private boolean HandleDataPacket ( DataPckt packet )
  {
    try {
      fileStream.writeObject ( packet );
      PacketReceived ();
    }
    catch ( IOException e )
    {
      VERBOSE ( "LOGGER:  Unable to write to file" );
      bShutdown = true;
    }
    return false;
  }

  private boolean HandleBaseStationsPacket ( BaseStationsPckt packet )
  {
    if ( clntWndw != null ) {
      clntWndw.ClearMotes ();
      Enumeration stationsEnum = packet.baseStations.elements();
      while ( stationsEnum.hasMoreElements () )
      {
        FlowData info = (FlowData) stationsEnum.nextElement();
        clntWndw.AddMoteNode ( info );
      }
      clntWndw.RefreshTrees();
    }
    return true;
  }

  public void SendClearMasks ( )
  {
    myInfo.masks.removeAllElements();
    myInfo.hosts.removeAllElements();
    SendAppInfo ( );
    if ( clntWndw != null ) {
      Utility.BuildRulesNode( myInfo, clntWndw.rulesRoot );
      clntWndw.RefreshTrees (); }
    sntPckts++;
    DEBUG ( "Sent clear packet to server" );
  }

  public void AddRule ( byte[] bitmask, InetAddress host )
  {
    myInfo.masks.add ( bitmask );
    myInfo.hosts.add ( host );
    SendAppInfo ( );
    if ( clntWndw != null ) {
      Utility.BuildRulesNode ( myInfo, clntWndw.rulesRoot );
      clntWndw.RefreshTrees ();
    }
  }
  public void SendAppInfo ( )
  {
    DEBUG ( "LOGGER: sending rules packet" );
    AppInfo pckt = new AppInfo();
    pckt.appName = myInfo.appName;
    pckt.hosts = new Vector ( myInfo.hosts );
    pckt.masks = new Vector ( myInfo.masks );
    SendPacket ( pckt );
  }

  public void SendBaseStationsRequest ( )
  {
    if ( !bShutdown ) {
      try { output.writeObject( new BaseStationsRequestPckt() ); }
      catch ( IOException e ) { DEBUG ( "LOGGER: unable to send BaseStationsRequest" ); }
    }
  }

  public void SendDataPacket ( DataPckt packet )
  {

    SendPacket ( packet );
    sntPckts++;
    DEBUG ( "LOGGER: Sent data packet to server" );
  }

  private void SendPacket ( byte[] packet )
  {
    try { output.write( packet ); }
    catch ( IOException e )
    {
      DEBUG ( "Logger: unable to send packet, socket closed to " + host);
      Shutdown ( );
      return;
    }
  }

  private void SendPacket ( Object packet )
  {
    try { output.writeObject( packet ); }
    catch ( IOException e ) {
      DEBUG ( "Logger unable to send packet, socket closed to " + host);
    }
    return;
  }

  private void PacketReceived ()
  {
    nPackets++;
    if ( clntWndw != null ) clntWndw.UpdatePacketsReceived ( nPackets );
  }

  public void Shutdown () {
    bShutdown = true;
    try { commSocket.close(); }
    catch ( IOException e ) {
      if ( InitLogger.debugMode ) { e.printStackTrace( ); }
    }
    interrupt();
  }

  private void ReportMessage ( String msg )
  {
      if ( clntWndw == null ) System.out.println (msg);
      else clntWndw.AddMessage (msg+"\n");
  }

  private void DEBUG ( String msg )
  {
    if ( InitLogger.debugMode ) { ReportMessage ( msg ); }
  }

  private void VERBOSE ( String msg )
  {
    if ( InitLogger.verboseMode ) { ReportMessage ( msg ); }
  }

  private void PreExit ( )
  {
    if ( clntWndw != null )
    {
      clntWndw.SetClient ( null );
      clntWndw.ClearMotes();
      clntWndw.ClearRules();
    }
    CloseLogFile ( );
    ReportMessage ( "Logger shutting down" );
  }
}