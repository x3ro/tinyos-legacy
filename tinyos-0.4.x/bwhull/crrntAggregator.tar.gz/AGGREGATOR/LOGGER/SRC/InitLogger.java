import java.io.*;
import javax.swing.*;

public class InitLogger
{
  // flags used during client start-up
  public static boolean       guiMode        = true;
  public static boolean       displayHelp    = false;
  public static boolean       debugMode      = true;
  public static boolean       verboseMode    = true;
  public static int           serverPort     = 9002;
  public static String        server         = "127.0.0.1";
  public static String        strFileName    = "serialportlog.bin";

  // packet mask
  public static byte[]          MASK           = null;
  public static String          MASK_HOST      = "";

  public static void main(String[] args) throws IOException
  {
    ProcessCommandLineArgs ( args );

    if ( displayHelp )
    {
      PrintHelp ();
    }
    else if ( guiMode )
    {
      if ( debugMode ) System.out.println ("Starting in GUI mode\n");
      CreateGui();
    }
    else
    {
      // no gui, user command line
      if ( debugMode ) System.out.println ("Starting in GUI mode\n");
      RunClient();
    }
  }

  private static void ProcessCommandLineArgs ( String[] args )
  {
    for ( int i = 0; i < args.length; i++ )
    {
      if ( args[i].equals ( "-no-gui") ) { guiMode = false; }
      else if (args[i].equals ("-server" ) )
      {
        i++;
        if ( i < args.length ) { server = args[i]; }
        else { displayHelp = true; }
      }
      else if (args[i].equals ("-file" ) )
      {
        i++;
        if ( i < args.length ) { strFileName = args[i]; }
        else { displayHelp = true; }
      }
      else if (args[i].equals ("-port" ) )
      {
        i++;
        if ( i < args.length ) { serverPort = Integer.parseInt(args[i]); }
        else { displayHelp = true; }
      }
      else if ( args[i].equals ("-debug") ) { debugMode = true; }
      else if ( args[i].equals ("-no-verbose") ) { verboseMode = false; }
      else { displayHelp = true; }
    }
  }

  private static void PrintHelp ( )
  {
      System.out.println ("optional arguments:");
      System.out.println ("-server [server address]");
      System.out.println ("-port [server port]");
      System.out.println ("-file [file name] ");
      System.out.println ("-no-gui      = do not display graphic interface");
      System.out.println ("-debug       = display debug output");
      System.out.println ("-no-verbose  = do not display any textual output");
  }

  private static void CreateGui ( )
  {
    // create frame
    JFrame clientFrame = new JFrame("SerialForwarder Logger");
    // create client gui
    ClientWindow clntWindow = new ClientWindow ( );
    // create comm processing thread
    clientFrame.addWindowListener( clntWindow );
    clientFrame.setSize( clntWindow.getPreferredSize() );
    clientFrame.getContentPane().add("Center", clntWindow);
    clientFrame.show();
  }

  private static void RunClient ( )
  {
    Logger client = new Logger ( null );
    client.start();
  }
}