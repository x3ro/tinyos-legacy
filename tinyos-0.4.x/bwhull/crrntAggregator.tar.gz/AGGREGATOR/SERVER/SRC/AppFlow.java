/**
 * Title: AppFlow.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description: An AppFlow represents the a connection between
 * an application and the server.  AppFlows respond to various
 * requests made by the applications and forwards all packets
 * from base stations to which this app is subscribed.
 */

import java.net.*;
import java.io.*;
import javax.swing.tree.*;
import java.util.*;

public class AppFlow extends Thread
{
  private Socket                connection            = null;
  private ObjectInputStream     input                 = null;
  private ObjectOutputStream    output                = null;
  private DataAggregator        dataStore             = null;
  private AppInfo               myInfo                = new AppInfo();
  private FlowData              crrntState            = new FlowData();
  private boolean               bShutdown             = false;

  private DefaultMutableTreeNode treeNode             = new DefaultMutableTreeNode ( this );
  private DefaultMutableTreeNode nodeName             = new DefaultMutableTreeNode ( "Unknown App Name" );
  private DefaultMutableTreeNode nodeRules            = new DefaultMutableTreeNode ( "Rules: (none)" );

  /**
   * Creates an AppFlow which handles the forwarding
   * of packets based on masked setup by applications
   *
   * @param connection socket to communicate with the app
   */
  public AppFlow ( Socket conn, DataAggregator data )
  {
    connection      = conn;
    crrntState.host = connection.getInetAddress().toString();
    crrntState.port = connection.getPort();
    dataStore       = data;

    treeNode.add( nodeName );
    treeNode.add( nodeRules );
  }

  /**
   * Sends packet to application
   *
   * @param packet byte array to be sent
   */
  public void SendPacket ( Object packet )
  {
    if ( packet == null || output == null || dataStore == null ) {
      dataStore.VERBOSE( "APPFLOW: Unable to send packet" );
      return;
    }
    try { output.writeObject( packet ); }
    catch ( IOException e )
    {
      dataStore.VERBOSE ( "APPFLOW: unable to send packet, socket closed to " + crrntState.host);
      Shutdown ( );
      return;
    }
  }

  public void SendDataPacket ( DataPckt packet )
  {
    crrntState.sntPckts++;
    if ( crrntState.dsplyState ) dataStore.UpdateAppDetails ( crrntState );
    SendPacket ( packet );
  }

  private void UpdatePacketCounts ( Object packet )
  {
    if ( packet instanceof DataPckt ) { crrntState.rcvdDataPckts++; }
    else if ( packet instanceof AppInfo ) { crrntState.rcvdAppInfoPckts++; }
    else if ( packet instanceof BaseStationsRequestPckt ) { crrntState.rcvdBaseStationRequestPckts++; }
    if ( crrntState.dsplyState ) dataStore.UpdateAppDetails ( crrntState );
  }

  /**
   * Determines whether or not the argument packet is of
   * interest to this application based on established
   * rules
   *
   * @param packet to be forwarded
   * @param mote flow from which packet came
   */
  public synchronized boolean SubscribedPacket ( DataPckt packet )
  {
    // if there aren't any rules, return
    if ( myInfo.masks.size() == 0 ) { return true; }

    boolean match = false;
    Enumeration myRules = myInfo.masks.elements();
    Enumeration myHosts = myInfo.hosts.elements();
    byte[] moteAddress = packet.source.getAddress();

    while ( myRules.hasMoreElements() && myHosts.hasMoreElements() )
    {
      byte[] currentHost = ((InetAddress) myHosts.nextElement()).getAddress();
      for ( int i = 0; i < currentHost.length && i < moteAddress.length; i++ )
      {
        if ( (currentHost[i] & moteAddress[i]) == currentHost[i] )
        {
          // byte matches, continue checking rest of address
          match = true;
          continue;
        }
        else {
          // byte does not match, stop checking address
          match = false;
          break;
        }
      }
      // address didn't match, skip to next rule
      if ( !match ) { continue; }

      byte[] currentRule = (byte[]) myRules.nextElement();
      if ( currentRule.length > packet.data.length ) { return false; }
      for ( int i = 0; i < currentRule.length; i++ )
      {
        if ( (currentRule[i] & packet.data[i]) == currentRule[i] )
        {
            // matches mask
            match = true;
            continue;
        }
        else {
          // does not match mask
          match = false;
          break;
        }
      }
      // mask and address matched, ok to forward
      if ( match ) { return true; }
    }
    dataStore.DEBUG( "App: Rejecting packet from host " + packet.source.toString() );
    return false;
  }
  /**
   * Starts reading data from socket
   */
  public void run ( )
  {
    try {
      boolean status  = true;
      RunInit ( );

      while (!bShutdown )
      {
        Object currentPckt;
        try { currentPckt = input.readObject(); }
        catch ( ClassNotFoundException e )
        {
          dataStore.VERBOSE ( "APPFLOW: invalid packet received");
          continue;
        }
        UpdatePacketCounts ( currentPckt );
        if ( currentPckt instanceof DataPckt )
        {
          dataStore.DEBUG( "Receiving DataPckt from host " + crrntState.host );
          status = HandleDataPacket ( (DataPckt) currentPckt );
        }
        else if ( currentPckt instanceof AppInfo )
        {
          dataStore.DEBUG ( "Receiving AppInfo packet from host " + crrntState.host );
          status = HandleAppInfoPacket ( (AppInfo) currentPckt );
        }
        else if ( currentPckt instanceof BaseStationsRequestPckt )
        {
          dataStore.DEBUG( "Receiving BaseStationsRequestPckt from host " + crrntState.host);
          status = HandleBaseStationsRequest ( );
        }
        else {
          dataStore.VERBOSE ( "Unrecognized messaged from client at host " + crrntState.host);
        }
        currentPckt = null;
      }
    }
    catch ( IOException e )
    {
      dataStore.DEBUG ( "APPFLOW: Socket closed for host " + crrntState.host );
    }
    PreExit ( );
    dataStore.DEBUG ( "APPFLOW: exiting for host " + crrntState.host );
  }

  private void RunInit ( )
  {
    try {
      dataStore.VERBOSE ( "APPFLOW: running hst: " + crrntState.host );
      // create input stream first
      InputStream in = connection.getInputStream();
      input = new ObjectInputStream ( in );
      // now do the output stream (reverse order on client )
      OutputStream out = connection.getOutputStream();
      output = new ObjectOutputStream ( out );
      // make sure to send header to client
      output.flush();
    }
    catch ( IOException e ) {
      e.printStackTrace();
      dataStore.VERBOSE( "APPFLOW: unable to object streams for hst: " + crrntState.host );
      bShutdown = true;
      return;
    }
    dataStore.RegisterApp( this );
  }

  /**
   * Reads in the data packet from the input stream and passes
   * it along to the DataAggregator
   *
   */
  private boolean HandleDataPacket ( DataPckt dataPckt )
  {
    boolean success = dataStore.SendDataPacketToMote ( dataPckt );
    if ( success )
    {
      // packet was sent successfully
      return true;
    }
    else { return false; }
  }


  private synchronized boolean HandleAppInfoPacket ( AppInfo info )
  {
    myInfo = info;

    BuildAppNameNode ( );
    BuildRulesNode ( );
    dataStore.RefreshAppTree();

    return true;
  }

  private synchronized boolean HandleBaseStationsRequest ( )
  {
    BaseStationsPckt stations = new BaseStationsPckt ();
    stations.baseStations = dataStore.GetBaseStations ();
    SendPacket ( stations );
    return true;
  }

  private void BuildAppNameNode ( )
  {
    nodeName.setUserObject( "App Name: " + myInfo.appName );
  }

  /**
   * Terminate this MoteFlow
   */
  public void Shutdown ( )
  {
    bShutdown = true;
    try {
      input.close();
      output.close();
    }
    catch ( SocketException e ) { /*just closing socket */ }
    catch ( IOException e ) { e.printStackTrace(); }
    this.interrupt();
  }

  public DefaultMutableTreeNode getTreeNode ( )
  {
    return treeNode;
  }

  public void SetDisplayState ( boolean value )
  {
    crrntState.dsplyState = value;
  }


  public FlowData GetDetails ( )
  {
    return crrntState;
  }

  public String toString ( )
  {
    return crrntState.host;
  }

  /**
   * Populates the rule tree with all masks that have been registered
   */
  private void BuildRulesNode ( )
  {
    if ( myInfo.masks.size() == 0 || myInfo.masks.size() == 0 )
    {
      // clear the tree
      nodeRules.removeAllChildren();
      nodeRules.setUserObject( "Rules: (none)" ); }
    else
    {
      // clear the tree
      nodeRules.removeAllChildren ();

      // set the root object
      nodeRules.setUserObject( "Rules: (" + myInfo.masks.size() + ")" );

      Enumeration ruleEnum = myInfo.masks.elements();
      Enumeration hostsEnum = myInfo.hosts.elements();
      byte[] crrntMsk;
      InetAddress crrntHost;
      String mskDsply;
      DefaultMutableTreeNode newChild;

      while ( ruleEnum.hasMoreElements() && hostsEnum.hasMoreElements() )
      {
        // build a node for each mask
        crrntMsk = (byte[]) ruleEnum.nextElement();
        crrntHost = (InetAddress) hostsEnum.nextElement();

        if ( crrntMsk.length == 0 ) {
          mskDsply = "All Packets";
        }
        else {
          mskDsply = new Integer ( crrntMsk[0] ).toString();
          for ( int i = 1; i < crrntMsk.length; i++ )
          {
            mskDsply += "." + crrntMsk[i];
          }
        }
        mskDsply += "/ " + crrntHost.getHostAddress();
        newChild = new DefaultMutableTreeNode ( mskDsply );
        nodeRules.add( newChild );
      }
    }
  }
  /**
   * Closes any open streams or sockets
   */
  private void PreExit ( )
  {
    try {
      if ( connection != null ) {
        connection.close();
        connection = null;
      }
    }
    catch ( IOException e ) {
      e.printStackTrace ( );
    }
    if ( dataStore != null ) {
      dataStore.UnregisterApp( this );
    }
  }
}