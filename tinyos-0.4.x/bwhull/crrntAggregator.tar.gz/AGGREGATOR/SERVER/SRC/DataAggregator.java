/**
 * Title: DataAggregator.java
 * @author Bret Hull
 * @version 1.0
 *
 * Description:  The DataAggregator provides the common
 * point of communication between MoteFlows, AppFlows,
 * and the ControlWindow.  This class keeps track of which
 * apps and base stations are connected, exposing this data
 * to all concerned class through its functional interface.
 */

import java.util.*;
import java.net.*;
import javax.swing.tree.*;
import java.io.*;

public class DataAggregator
{
  private Vector            motes           = new Vector ();
  private Vector            apps            = new Vector ();
  private AppListener       appListener     = null;
  private MoteListener      moteListener    = null;
  private ControlWindow     cntrlWndw       = null;
  private MoteFlow          selectedMote    = null;
  private AppFlow           selectedApp     = null;
  private MultiCastListen   multicast       = null;

  public DataAggregator ( ControlWindow wndw )
  {
    cntrlWndw = wndw;
  }

  /**
   * Creates a receiving thread based on the argument socket
   * to receive packets from the mote at the base station
   *
   * @param flow  a socket representing connection for mote
   */
  public synchronized void RegisterMote ( MoteFlow flow )
  {
    // add base station to vector
    motes.add ( flow );
    // add a node in the GUI
    AddMoteTreeNode ( flow.getTreeNode () );
    // send out updated info to connected Apps
    UpdateApps ( );
    // have GUI do a tree refresh
    RefreshMoteTree ( );
  }

  /**
   * Sends a BaseStationsPckt to every connected app
   * in order to ensure each has the most current
   * list of attached base stations
   */
  private synchronized void UpdateApps ( )
  {
    Enumeration appEnum = apps.elements();
    BaseStationsPckt stations = new BaseStationsPckt();
    stations.baseStations = GetBaseStations();

    while ( appEnum.hasMoreElements() )
    {
      AppFlow app = (AppFlow) appEnum.nextElement();
      app.SendPacket( stations );
    }
  }

  /**
   * Creates a receiving thread based on the argument socket
   * to receive requests from client application
   *
   * @param flow  a socket representing connection for mote
   */
  public synchronized void RegisterApp ( AppFlow flow )
  {
    apps.add ( flow );
    AddAppTreeNode ( flow.getTreeNode () );
  }

 /**
  * Removes the argument MoteFlow from the internal data store
  *
  * @param flow       MoteFlow to be removed
  */
  public synchronized void UnregisterMote ( MoteFlow flow )
  {
    if ( selectedMote == flow ) selectedMote = null;
    motes.remove( flow );
    RemoveMoteTreeNode ( flow.getTreeNode() );
    // send out updated info to connected Apps
    UpdateApps ( );
    // have GUI do a tree refresh
    RefreshMoteTree ( );
  }

  /**
   * Removes argumet AppFlow from internal data store
   *
   * @param flow AppFlow to be removed
   */
  public synchronized void UnregisterApp ( AppFlow flow )
  {
    apps.remove ( flow );
    RemoveAppTreeNode ( flow.getTreeNode () );
  }

  /**
   * Propogates packet to every AppFlow, which filters
   * based on bit mask
   *
   * @param packet    byte array to be sent to registered apps
   * @param mote      MoteFlow from which packet came
   */
  public synchronized void PacketReceived ( DataPckt packet )
  {
    Enumeration appEnum   = apps.elements();
    AppFlow currentApp  = null;

    while ( appEnum.hasMoreElements () )
    {
      currentApp = (AppFlow) appEnum.nextElement();
      if ( currentApp.SubscribedPacket ( packet ) )
      {
        currentApp.SendDataPacket ( packet );
      }
    }
  }

  /**
   * Handles the forwarding of a data packet from
   * an application to a base station
   *
   * @param dataPckt  to be sent to base station
   */
  public boolean SendDataPacketToMote ( DataPckt dataPckt )
  {
    MoteFlow mote = GetMoteFlow ( dataPckt.dest );
    if ( mote == null ) {
      VERBOSE( "APPFLOW: Destination mote not connected: " + dataPckt.dest.toString() );
      return false;
    }
    else {
      mote.SendDataPacket ( dataPckt );
      return true;
    }
  }

  /**
   * Set the multicast thread
   *
   * @param mc multicast thread
   */
  public void SetMulticast ( MultiCastListen mc )
  {
    multicast = mc;
  }

  public void SetAppTreePath ( TreePath path )
  {
    if ( cntrlWndw != null ) { cntrlWndw.SetAppTreePath ( path ); }
  }

  public void SetMoteTreePath ( TreePath path )
  {
    if ( cntrlWndw != null ) { cntrlWndw.SetMoteTreePath ( path ); }
  }

  /**
   * Set which base stations details are displayed in
   * the details tab of the control window
   *
   * @param mote whose details should be displayed
   */
  public void SetSelectedMote ( MoteFlow mote )
  {
    if ( selectedMote != null ) selectedMote.SetDisplayState( false );
    selectedMote = mote;
    selectedMote.SetDisplayState( true );
  }

  /**
   * Set which apps details are displayed in
   * the details tab of the control window
   *
   * @param app whose details should be displayed
   */
  public void SetSelectedApp ( AppFlow app )
  {
    if ( selectedApp != null ) selectedApp.SetDisplayState ( false );
    selectedApp = app;
    selectedApp.SetDisplayState ( true );
  }

  public void UpdateMoteDetails ( FlowData data )
  {
    if ( cntrlWndw != null ) { cntrlWndw.UpdateMoteDetails ( data ); }
  }

  public void UpdateAppDetails ( FlowData data )
  {
    if ( cntrlWndw != null ) { cntrlWndw.UpdateAppDetails ( data ); }
  }

  /**
  * Close all open connections in preparation for application
  * halt
  *
  */
  public void Shutdown ( )
  {
    // shutdown MoteListener
    if ( moteListener != null )
    {
      moteListener.Shutdown ();
      DEBUG ( "Shutting-down mote listener" );
      try { moteListener.join( 1000 ); }
      catch ( InterruptedException e ) { e.printStackTrace(); }
    }
    // shutdown AppListener
    if ( appListener != null )
    {
      appListener.Shutdown ();
      DEBUG ( "Shutting-down app listener");
      try { appListener.join( 1000 ); }
      catch ( InterruptedException e ) { e.printStackTrace(); }
    }

    if ( multicast != null )
    {
      multicast.Shutdown ();
      DEBUG ("Shutting-down multicast thread");
    }
    // shutdown all mote flows
    DisconnectAllMotes ( );
    // shutdown all app flows
    DisconnectAllApps ( );

    cntrlWndw.SetDataAggregator( null );
  }

  /**
   * Disconnects all connected motes from server
   */
  public void DisconnectAllMotes ( )
  {
    while ( motes.size() != 0 )
    {
      DisconnectMote ( (MoteFlow) motes.firstElement() );
    }
  }

  /**
   * Disconnects the argument mote from the server
   *
   * @param mote to be disonnected
   */
  public void DisconnectMote ( MoteFlow mote )
  {
    mote.Shutdown();
    try { mote.join( 1000 ); }
    catch ( InterruptedException e ) { e.printStackTrace(); }
  }

  /**
   * Disconnects all connected apps from server
   */
  public void DisconnectAllApps ( )
  {
    while ( apps.size() != 0 )
    {
      DisconnectApp ( (AppFlow) apps.firstElement() );
    }
  }

  /**
   * Disconnects the argument app from the server
   *
   * @param app to be disonnected
   */
  public void DisconnectApp ( AppFlow app )
  {
    app.Shutdown();
    try { app.join( 1000 ); }
    catch ( InterruptedException e ) { e.printStackTrace(); }
  }
  public void SetMoteListener ( MoteListener listener )
  {
    moteListener = listener;
  }

  public void SetAppListener ( AppListener listener )
  {
    appListener = listener;
  }

  /**
   * Connect to motes from ip in moteFile
   */
  public void OpenMotesFromFile ( ) { moteListener.ConnectFromFile (this); }

  public void VERBOSE ( String msg )
  {
    if ( Init.verboseMode ) {
      if ( cntrlWndw == null )
      {
        System.out.println ( msg );
      }
      else
      {
        cntrlWndw.AddMessage( msg + "\n" );
      }
    }
  }

  public void DEBUG ( String msg )
  {
    if ( Init.debugMode ) {
      if ( cntrlWndw == null )
      {
        System.out.println ( msg );
      }
      else
      {
        cntrlWndw.AddMessage( msg + "\n" );
      }
    }
  }

  private void AddMoteTreeNode ( DefaultMutableTreeNode node )
  {
    if ( cntrlWndw != null )
    {
      cntrlWndw.AddMoteTreeNode ( node );
    }
  }

  private void RemoveMoteTreeNode ( DefaultMutableTreeNode node )
  {
    if ( cntrlWndw != null ) {
      cntrlWndw.RemoveMoteTreeNode ( node );
    }
  }

  private void AddAppTreeNode ( DefaultMutableTreeNode node )
  {
    if ( cntrlWndw != null )
    {
      cntrlWndw.AddAppTreeNode ( node );
    }
  }

  private void RemoveAppTreeNode ( DefaultMutableTreeNode node )
  {
    if ( cntrlWndw != null ) {
      cntrlWndw.RemoveAppTreeNode ( node );
    }
  }

  public void RefreshMoteTree ( )
  {
    if ( cntrlWndw != null ) {
      cntrlWndw.RefreshMoteTree ( );
    }
  }

  public void RefreshAppTree ( )
  {
    if ( cntrlWndw != null )
    {
      cntrlWndw.RefreshAppTree ( );
    }
  }

  public MoteFlow GetMoteFlow ( InetAddress host )
  {
    Enumeration moteEnum = motes.elements();
    MoteFlow currentMote;
    while ( moteEnum.hasMoreElements() )
    {
      currentMote = (MoteFlow) moteEnum.nextElement();
      if ( currentMote.GetDetails().inet.equals( host ) )
      {
        // we have found a matching base station
        return currentMote;
      }
    }
    return null;
  }

  public Vector GetBaseStations ( )
  {
    Enumeration stations = motes.elements();
    Vector baseStations = new Vector ();

    while ( stations.hasMoreElements() )
    {
      MoteFlow currentMote = (MoteFlow) stations.nextElement();
      baseStations.add ( currentMote.GetDetails() );
    }
    return baseStations;
  }

  public void SendMulticastHeartBeat ( )
  {
    if ( multicast != null ) { multicast.SendMultiCastAnnounce(); }
    else { VERBOSE ( "Multicast not running; unable to send annouce!" ); }
  }

  public void ConnectToMote ( String host, int port )
  {
    VERBOSE ( "Attempting to connect to host " + host + " at port " + port );
    try {
      Socket skt = new Socket ( host, port );
      MoteFlow mote = new MoteFlow ( skt, this );
      mote.start();
      VERBOSE ("Connection successful!");
    }
    catch ( IOException e )
    {
      VERBOSE ("Unable to connect to host " + host + " at port " + port );
    }
  }

  public void SaveMotesToFile ( )
  {
    FileWriter fw;
    try { fw = new FileWriter ( Init.moteFile ); }
    catch ( IOException e ) {
      VERBOSE ("Unable to save motes to file " + Init.moteFile );
      return;
    }

    Enumeration myMotes = motes.elements();

    while ( myMotes.hasMoreElements() )
    {
      MoteFlow baseStation = (MoteFlow) myMotes.nextElement();
      FlowData data = baseStation.GetDetails();
      try {
      fw.write( data.inet.getHostAddress() + "\n");
      fw.write( Integer.toString( data.port ) + "\n" );
      }
      catch ( IOException e ) {
        VERBOSE ("Unable to write to mote file " + Init.moteFile );
        return;
      }
    }
    VERBOSE ( "BaseStations successfully saved to file " + Init.moteFile );

    try { fw.close(); }
    catch ( IOException e ) { VERBOSE ("Unable to close file " + Init.moteFile ); }
  }
}