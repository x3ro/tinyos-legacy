

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ConnectWindow extends Dialog
{
  DataAggregator dataStore  = null;
  GridLayout    gridLayout1 = new GridLayout();
  JPanel        jPanel1     = new JPanel();
  JPanel        jPanel2     = new JPanel();
  JButton       bttnCancel  = new JButton();
  JButton       bttnConnect = new JButton();
  JLabel        lblHost     = new JLabel();
  JTextField    fldHost     = new JTextField();
  BorderLayout  borderLayout1 = new BorderLayout();
  JTextField fldPort = new JTextField();

  public ConnectWindow( JFrame wndw)
  {
    super ( wndw );
    try
    {
      jbInit();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception
  {
    gridLayout1.setRows(2);
    gridLayout1.setColumns(1);
    this.setLayout(gridLayout1);
    bttnCancel.setText("Cancel");
    bttnCancel.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        bttnCancel_actionPerformed(e);
      }
    });
    bttnConnect.setText("Connect");
    bttnConnect.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        bttnConnect_actionPerformed(e);
      }
    });
    lblHost.setText("Host:");
    fldHost.setText("127.0.0.1");
    jPanel1.setLayout(borderLayout1);
    fldPort.setText("9000");
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    this.add(jPanel1, null);
    jPanel1.add(lblHost, BorderLayout.WEST);
    jPanel1.add(fldHost, BorderLayout.CENTER);
    jPanel1.add(fldPort, BorderLayout.EAST);
    this.add(jPanel2, null);
    jPanel2.add(bttnConnect, null);
    jPanel2.add(bttnCancel, null);
  }

  void SetDataStore ( DataAggregator data )
  {
    dataStore = data;
  }

  void bttnConnect_actionPerformed(ActionEvent e)
  {
    if ( dataStore != null ) {
      dataStore.ConnectToMote ( fldHost.getText(), Integer.parseInt( fldPort.getText() ) );
    }
    this.dispose();

  }

  void bttnCancel_actionPerformed(ActionEvent e)
  {
    this.dispose();
  }
}
