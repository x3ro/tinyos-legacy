

/**
 * Title: AppInfo.java
 * @author Bret Hull
 * @version 1.0
 */

import java.util.*;
import java.io.*;

public class AppInfo implements Serializable, Cloneable
{
  public String   appName   = "unknown";
  public Vector   masks     = new Vector ();
  public Vector   hosts     = new Vector ();
}