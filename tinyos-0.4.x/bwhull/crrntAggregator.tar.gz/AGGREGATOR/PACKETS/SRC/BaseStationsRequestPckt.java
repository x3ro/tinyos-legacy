

/**
 * Title: BaseStationsRequestPckt
 * @author Bret Hull
 * @version 1.0
 */

import java.io.*;

public class BaseStationsRequestPckt implements Serializable
{
}