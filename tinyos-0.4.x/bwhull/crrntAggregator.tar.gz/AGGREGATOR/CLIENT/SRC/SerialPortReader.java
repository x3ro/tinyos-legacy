/**
 * File: SerialPortReader.java
 *
 * Description:
 * The SerialPortReader handles the collection of packets
 * from a mote connected to the serial port.  The Constructor
 * takes in an already open input stream from which to read
 * data.
 *
 * Author: Bret Hull
 */

/*
 * ORIGINALLY BASED ON CODE BY:
 * Author: Mike Chen <mikechen@cs.berkeley.edu>
 * Inception Date: October 22th, 2000
*/

import java.util.*;
import java.io.*;
import javax.comm.*;
import java.net.*;

public class SerialPortReader extends Thread {

  private static final String   CLASS_NAME    = "SerialPortReader";

  private InputStream           in            = null;
  Vector                        forwarders    = null;
  ControlWindow                 cntrlWindow   = null;
  boolean                       bDummyData    = false;
  boolean                       bFileData     = true;
  boolean                       bShutdown     = false;
  boolean                       bNetData      = false;
  int                           nPacket       = 0;
  int                           dmmyDtPrd     = 1000;
  ListenServer                  lstnSrvr      = null;

  public SerialPortReader(InputStream stream, ControlWindow control, Vector pcktForwarders, ListenServer lstn ) {
    in            = stream;
    cntrlWindow   = control;
    forwarders    = pcktForwarders;
    bDummyData    = SerialForward.useDummyData;
    bFileData     = SerialForward.useFileData;
    bNetData      = SerialForward.useNetData;
    lstnSrvr      = lstn;
    if ( cntrlWindow != null ) { cntrlWindow.UpdatePacketsRead( nPacket ); }
  }

  public void run ( )
  {
    if ( bDummyData ) {
      // do not read from serial port
      // output a random set of data to clients
      DEBUG ( "SERIALPORTREADER: Using DummyData" );
      ReadDummyData ();
    }
    else if ( bFileData ) {
      // read data from file
      DEBUG ( "SERIALPORTREADER: Using FileData" );
      ReadFileData ();
    }
    else if ( bNetData ) {
      // read data from network
      DEBUG ( "SERIALPORTREADER: Using NetData" );
    }
    else {
      // we're using the serial port
      DEBUG ( "SERIALPORTREADER: Using Serial Port" );
      try { read(); }
      catch(Exception e)
      {
        VERBOSE ( "Unable to read from serial port" );
        if ( SerialForward.debugMode ) e.printStackTrace();
        return;
      }
    }
    CloseAllSockets ();
    DEBUG ( "SerialPortReader: shutting down" );
  }

  private void CloseAllSockets ( )
  {
    Enumeration sockets = forwarders.elements();
    PacketForwarder currentForwarder;

    while ( sockets.hasMoreElements() )
    {
       currentForwarder = (PacketForwarder) sockets.nextElement();
       currentForwarder.CloseSocket();
    }

    forwarders.clear();
  }
  private void ReadDummyData ()
  {
    DEBUG ( "SerialPortReader: sending dummy data" );

    while ( !bShutdown )
    {
      UpdateListeners ( SerialForward.PACKET_DUMMY_DATA );
      try { sleep ( dmmyDtPrd ); }
      catch (Exception e ) { }
    }
  }

  private void ReadFileData ( )
  {
    VERBOSE ( "Reading data from file" );
    FileInputStream fs    = null;
    ObjectInputStream ois = null;
    try {
      fs  = new FileInputStream ( SerialForward.dataFile );
      ois = new ObjectInputStream ( fs );
    }
    catch ( IOException e ) {
      DEBUG ( "SERIALPORTREADER: Unable to open file: " + SerialForward.dataFile );
      bShutdown = true;
    }

    Object currentPckt;
    Object lastPckt = null;

    while ( !bShutdown ) {
      try { currentPckt = ois.readObject(); }
      catch ( ClassNotFoundException e ) {
        bShutdown = true;
        continue;
      }
      catch ( EOFException e ) {
        VERBOSE ( "PORTREADER: End of data file" );
        lstnSrvr.Shutdown();
        bShutdown = true;
        continue;
      }
      catch ( IOException e ) {
        bShutdown = true;
        continue;
      }

      if ( currentPckt instanceof DataPckt ) {
        if ( lastPckt == null )
        {
          UpdateListeners ( ( (DataPckt) currentPckt).data );
        }
        else {
          SimulatePcktDelay ( (DataPckt) currentPckt, (DataPckt) lastPckt );
          UpdateListeners ( ( (DataPckt) currentPckt).data );
        }
        lastPckt = currentPckt;
      }
    }
  }

  private void SimulatePcktDelay ( DataPckt currentPckt, DataPckt lastPckt )
  {
    long timeDelta = currentPckt.time.getTime() - lastPckt.time.getTime();
    if ( timeDelta < 0 ) { return; }
    else {
      try { this.sleep( timeDelta ); }
      catch ( InterruptedException e ) { }
    }
  }
  private void UpdatePacketsRead ( )
  {
    if ( cntrlWindow != null ) { cntrlWindow.UpdatePacketsRead ( nPacket ); }
  }

  public void Shutdown ( )
  {
    bShutdown = true;
    this.interrupt();
  }

  private void registerPacketForwarder ( PacketForwarder listener )
  {
    forwarders.addElement (listener );
    DEBUG ( "SerialPortReader: Added listener to position: " + forwarders.size() );
  }

  private void unregisterPacketForwarder ( PacketForwarder listener)
  {
    if ( !forwarders.removeElement( listener ) )
    {
      VERBOSE ( "Unable to unregister listener");
    }
    else { DEBUG ( "SerialPortReader: Removed listener from SerialPortReader" ); }
  }

  public void read() throws IOException
  {
    int     i;
    int     count = 0;
    byte[]  packet = new byte[SerialForward.PACKET_SIZE];

    while ((i = in.read()) != -1 && !bShutdown)
    {
      packet[count] = (byte) i;
      count++;
      if (count == SerialForward.PACKET_SIZE) {
        count = 0;
        // send data to listener threads
        UpdateListeners ( packet );
        packet = new byte[SerialForward.PACKET_SIZE];
      }
      else if(count == 1 && i != 0x7e)
      {
          count = 0;
          if ( cntrlWindow != null ) cntrlWindow.AddMessage (".");
      }
    }
  }

  private void UpdateListeners ( byte[] packet )
  {
    nPacket++;
    UpdatePacketsRead ();
    PacketForwarder currentForwarder;
    boolean bSuccessful;

    for ( int i = 0; i < forwarders.size(); i++)
    {
      currentForwarder = (PacketForwarder) forwarders.elementAt(i);
      bSuccessful = currentForwarder.packetReceived(packet);

      if ( !bSuccessful )
      {
        unregisterPacketForwarder ( currentForwarder );
        i--;
      }
    }
  }
  private void ReportMessage ( String msg )
  {
      if ( cntrlWindow == null ) System.out.println (msg);
      else cntrlWindow.AddMessage (msg+"\n");
  }

  private void DEBUG ( String msg )
  {
    if ( SerialForward.debugMode ) { ReportMessage ( msg ); }
  }

  private void VERBOSE ( String msg )
  {
    if ( SerialForward.verboseMode ) { ReportMessage ( msg ); }
  }

  public synchronized void AddPacketForwarder ( Socket sckt )
  {
    PacketForwarder newPacketForwarder = new PacketForwarder ( sckt, cntrlWindow );
    registerPacketForwarder ( newPacketForwarder );
  }
}

