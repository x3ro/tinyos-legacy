/**
 * File: MultiCastListen.java
 *
 * Description:
 * The MultiCastListen class implements a thread
 * that listens for DataAggregators and connects
 * to them once they are available.
 *
 * Author: Bret Hull
 */

import java.net.*;
import java.io.*;

public class MultiCastListen extends Thread
{


  private   InetAddress       groupInet     = null;
  private   MulticastSocket   mcSocket      = null;
  private   boolean           bShutdown     = false;

  private   ListenServer      lstnServer    = null;
  private   ControlWindow     cntrlWndw  = null;

  public MultiCastListen( ListenServer lstn, ControlWindow cntrl )
  {

    lstnServer = lstn;
    cntrlWndw = cntrl;
  }

  public void run ( )
  {
    DEBUG ("MULTICAST: starting listen thread");
    try { groupInet = InetAddress.getByName( SerialForward.multicastGroup ); }
    catch ( UnknownHostException e ) { DEBUG ( "UnknownHostException: host = " + SerialForward.multicastGroup ); }

    try {
      mcSocket = new MulticastSocket ( SerialForward.multicastPort );
      mcSocket.joinGroup( groupInet );

      SendMultiCastAnnounce ( );

      Socket newServer = null;
      byte[] buf = new byte[3];
      DatagramPacket currentPckt = new DatagramPacket ( buf, buf.length);

      while ( !bShutdown )
      {
        mcSocket.receive( currentPckt );
        if ( currentPckt.getData()[0] == SerialForward.serverMagic )
        {
          // an aggregator server is up
          int serverPort = currentPckt.getData()[1] | ((int)currentPckt.getData()[2] << 8 );
          VERBOSE("MULTICAST: heartbeat detected from server at host = " + currentPckt.getAddress() + " port = " + serverPort );
          newServer = new Socket ( currentPckt.getAddress(), serverPort );
          lstnServer.SpawnConnection ( newServer );
        }
        else {
          DEBUG ( "MULTICAST: received packet magic number= " + currentPckt.getData()[0] );
        }
      }
      mcSocket.leaveGroup(groupInet);
      mcSocket.close();
    }
    catch ( IOException e ) {
      DEBUG ( "MULTICAST: connection closed");
    }
    lstnServer.SetMulticast ( null );
    DEBUG ("MULTICAST: exiting");
  }

  public void SendMultiCastAnnounce ( )
  {
    SerialForward.clientMagic[1] = (byte) (SerialForward.serverPort & 0xFF);
    SerialForward.clientMagic[2] = (byte) ((SerialForward.serverPort & 0xFF00) >> 8);
    DatagramPacket pckt = new DatagramPacket ( SerialForward.clientMagic, SerialForward.clientMagic.length, groupInet, SerialForward.multicastPort );
    try { mcSocket.send( pckt ); }
    catch ( IOException e ) {
      DEBUG ("MULTICAST: unable to send announce packet");
    }
  }

  public synchronized void Shutdown ( )
  {
    bShutdown = true;
    try {
      if ( mcSocket != null ) {
        mcSocket.leaveGroup( groupInet );
        mcSocket.close();
      }
    }
    catch ( IOException e ) { e.printStackTrace(); }
    this.interrupt();
  }
  private void ReportMessage ( String msg )
  {
      if ( cntrlWndw == null ) System.out.println (msg);
      else cntrlWndw.AddMessage (msg+"\n");
  }

  private void DEBUG ( String msg )
  {
    if ( SerialForward.debugMode ) { ReportMessage ( msg ); }
  }

  private void VERBOSE ( String msg )
  {
    if ( SerialForward.verboseMode ) { ReportMessage ( msg ); }
  }

}