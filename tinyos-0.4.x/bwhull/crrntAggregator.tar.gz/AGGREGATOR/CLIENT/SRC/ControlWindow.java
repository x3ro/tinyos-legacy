/**
 * File: ControlWindow.java
 *
 * Description:
 * This class displays the GUI that allows the serial forwarder
 * to be more easily configured
 *
 * Author: Bret Hull
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ControlWindow extends JPanel implements WindowListener
{
  ListenServer  listenServer          = null;
  JScrollPane   mssgPanel             = new JScrollPane();
  JTextArea     mssgArea              = new JTextArea();
  BorderLayout  toplayout             = new BorderLayout();
  JTabbedPane   pnlTabs               = new JTabbedPane();
  JLabel        labelPacketsSent      = new JLabel();
  JLabel        labelServerPort       = new JLabel();
  JLabel        labelFileName         = new JLabel ();
  JTextField    fieldFileName         = new JTextField();
  JTextField    fieldServerPort       = new JTextField();
  JLabel        labelSerialPort       = new JLabel();
  JButton       bPrintPorts           = new JButton();
  JButton       bServerStart          = new JButton();
  JLabel        labelPacketsReceived  = new JLabel();
  JLabel        labelPacketSize       = new JLabel();
  JTextField    fieldSerialPort       = new JTextField();
  JTextField    fieldPacketSize       = new JTextField();
  JCheckBox     cbDummyData           = new JCheckBox();
  JCheckBox     cbFileData            = new JCheckBox ();
  JCheckBox     cbSerialData          = new JCheckBox ();
  JCheckBox     cbNetData             = new JCheckBox ();
  ButtonGroup   bttnGroup             = new ButtonGroup ();
  JPanel        pnlMain               = new JPanel();
  GridLayout    gridLayout1           = new GridLayout();
  JLabel        labelNumClients       = new JLabel();
  JCheckBox     cbVerboseMode         = new JCheckBox();
  JButton       bStopServer           = new JButton();
  JPanel        pnlSetup              = new JPanel();
  GridLayout    gridLayout2           = new GridLayout();
  JLabel        lblLocation           = new JLabel();
  JTextField    fldLoc                = new JTextField();
  JButton       bttnSetup             = new JButton();
  JTextField    fldDmmyPckt           = new JTextField();
  JLabel        lblDmmyPckt           = new JLabel();
  JCheckBox     cbMulticast           = new JCheckBox();
  JLabel        lblMulticastGrp       = new JLabel();
  JTextField    fldMulticastGrp       = new JTextField();
  JTextField    fldMulticastPort      = new JTextField();
  JLabel        lblMulticastPort      = new JLabel();
  JLabel        lblNetDataHost        = new JLabel();
  JTextField    fldNetDataHost        = new JTextField();
  JLabel        lblNetDataPort        = new JLabel();
  JTextField    fldNetDataPort        = new JTextField();

  public ControlWindow( ) {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setLayout(toplayout);

    mssgPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    mssgPanel.setAutoscrolls(true);
    this.setMinimumSize(new Dimension(400, 300));
    this.setPreferredSize(new Dimension(400, 400));
    labelPacketsSent.setFont(new java.awt.Font("Dialog", 1, 10));
    labelPacketsSent.setHorizontalTextPosition(SwingConstants.LEFT);
    labelPacketsSent.setText("Pckts Read: 0");
    labelServerPort.setFont(new java.awt.Font("Dialog", 1, 10));
    labelServerPort.setText("Server Port:");
    labelFileName.setFont(new java.awt.Font("Dialog", 1, 10));
    labelFileName.setText("Data File Name:");
    fieldFileName.setFont(new java.awt.Font("Dialog", 0, 10));
    fieldFileName.setText( SerialForward.dataFile );
    fieldServerPort.setFont(new java.awt.Font("Dialog", 0, 10));
    fieldServerPort.setText(Integer.toString ( SerialForward.serverPort ));
    labelSerialPort.setFont(new java.awt.Font("Dialog", 1, 10));
    labelSerialPort.setText("Serial Port:");
    bPrintPorts.setFont(new java.awt.Font("Dialog", 0, 10));
    bPrintPorts.setText("Print Ports");
    bPrintPorts.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        bPrintPorts_actionPerformed(e);
      }
    });
    bServerStart.setFont(new java.awt.Font("Dialog", 1, 10));
    bServerStart.setMnemonic('0');
    bServerStart.setText("Start Server");
    bServerStart.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        bServerStart_actionPerformed(e);
      }
    });
    labelPacketsReceived.setFont(new java.awt.Font("Dialog", 1, 10));
    labelPacketsReceived.setHorizontalTextPosition(SwingConstants.LEFT);
    labelPacketsReceived.setText("Pckts Wrttn: 0");
    labelPacketSize.setFont(new java.awt.Font("Dialog", 1, 10));
    labelPacketSize.setText("Packet Size:");
    fieldSerialPort.setFont(new java.awt.Font("Dialog", 0, 10));
    fieldSerialPort.setText(SerialForward.commPort);
    fieldPacketSize.setFont(new java.awt.Font("Dialog", 0, 10));
    fieldPacketSize.setText(Integer.toString( SerialForward.PACKET_SIZE));

    // Input CheckBoxes
    cbDummyData.setSelected(SerialForward.useDummyData);
    cbDummyData.setText("Dummy Data");
    cbDummyData.setFont(new java.awt.Font("Dialog", 1, 10));

    cbFileData.setSelected(SerialForward.useFileData);
    cbFileData.setText("File Data");
    cbFileData.setFont(new java.awt.Font("Dialog", 1, 10));

    cbSerialData.setSelected( !( SerialForward.useDummyData || SerialForward.useFileData ) );
    cbSerialData.setText("Serial Port");
    cbSerialData.setFont(new java.awt.Font("Dialog", 1, 10));

    cbNetData.setSelected( SerialForward.useNetData );
    cbNetData.setText( "Net Data");
    cbNetData.setFont(new java.awt.Font("Dialog", 1, 10));

    bttnGroup.add( cbFileData );
    bttnGroup.add( cbDummyData );
    bttnGroup.add( cbSerialData );
    bttnGroup.add( cbNetData );

    pnlMain.setLayout(gridLayout1);
    pnlMain.setMinimumSize(new Dimension(100, 75));
    pnlMain.setPreferredSize(new Dimension(100, 75));
    gridLayout1.setRows(18);
    labelNumClients.setFont(new java.awt.Font("Dialog", 1, 10));
    labelNumClients.setText("Num Clients: 0");
    cbVerboseMode.setSelected(SerialForward.verboseMode);
    cbVerboseMode.setText("Verbose Mode");
    cbVerboseMode.setFont(new java.awt.Font("Dialog", 1, 10));
    bStopServer.setFont(new java.awt.Font("Dialog", 1, 10));
    bStopServer.setText("Stop Server");
    bStopServer.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        bStopServer_actionPerformed(e);
      }
    });
    pnlSetup.setLayout(gridLayout2);
    gridLayout2.setRows(16);
    gridLayout2.setColumns(1);
    lblLocation.setText("Location:");
    lblLocation.setFont(new java.awt.Font("Dialog", 1, 10));
    fldLoc.setFont(new java.awt.Font("Dialog", 0, 10));
    fldLoc.setText(SerialForward.PACKET_LOCATION );
    bttnSetup.setText("Save");
    bttnSetup.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        bttnSetup_actionPerformed(e);
      }
    });
    fldDmmyPckt.setText("255");
    fldDmmyPckt.setFont(new java.awt.Font("Dialog", 0, 10));
    lblDmmyPckt.setFont(new java.awt.Font("Dialog", 1, 10));
    lblDmmyPckt.setText("Dummy Packet Data:");
    cbMulticast.setFont(new java.awt.Font("Dialog", 1, 10));
    cbMulticast.setText("Multicast");
    cbMulticast.setSelected(SerialForward.multicast);
    lblMulticastGrp.setText("Multicast Group:");
    lblMulticastGrp.setFont(new java.awt.Font("Dialog", 1, 10));
    fldMulticastGrp.setFont(new java.awt.Font("Dialog", 0, 10));
    fldMulticastGrp.setText(SerialForward.multicastGroup);
    fldMulticastPort.setText(new Integer ( SerialForward.multicastPort ).toString());
    fldMulticastPort.setFont(new java.awt.Font("Dialog", 0, 10));
    lblMulticastPort.setFont(new java.awt.Font("Dialog", 1, 10));
    lblMulticastPort.setText("Multicast Port:");

    fldNetDataPort.setText( Integer.toString( SerialForward.netDataPort ));
    fldNetDataPort.setFont(new java.awt.Font("Dialog", 0, 10));
    lblNetDataPort.setFont(new java.awt.Font("Dialog", 1, 10));
    lblNetDataPort.setText("Net Data Port:");
    fldNetDataHost.setText( SerialForward.netDataHost );
    fldNetDataHost.setFont(new java.awt.Font("Dialog", 0, 10));
    lblNetDataHost.setFont(new java.awt.Font("Dialog", 1, 10));
    lblNetDataHost.setText("Net Data Host:");

    toplayout.setHgap(1);
    toplayout.setVgap(1);
    this.add(mssgPanel, BorderLayout.CENTER);
    this.add(pnlTabs, BorderLayout.EAST);
    pnlTabs.add(pnlMain, "Main");

    // Main Panel Setup
    pnlMain.add(bServerStart, null);
    pnlMain.add(labelServerPort, null);
    pnlMain.add(fieldServerPort, null);
    pnlMain.add(labelSerialPort, null);
    pnlMain.add(fieldSerialPort, null);
    pnlMain.add(labelPacketSize, null);
    pnlMain.add(fieldPacketSize, null);
    pnlMain.add(bStopServer, null);

    pnlMain.add( cbDummyData, null);
    pnlMain.add( cbFileData, null);
    pnlMain.add( cbSerialData, null );
    pnlMain.add( cbNetData, null );
    pnlMain.add( cbMulticast, null);
    pnlMain.add( cbVerboseMode, null);

    pnlMain.add( labelPacketsSent, null);
    pnlMain.add( labelPacketsReceived, null);
    pnlMain.add( labelNumClients, null);
    pnlMain.add( bPrintPorts, null);

    pnlTabs.add( pnlSetup, "Setup");

    pnlSetup.add( lblLocation, null);
    pnlSetup.add(fldLoc, null);
    pnlSetup.add(lblDmmyPckt, null);
    pnlSetup.add(fldDmmyPckt, null);
    pnlSetup.add(lblMulticastGrp, null);
    pnlSetup.add(fldMulticastGrp, null);
    pnlSetup.add(lblMulticastPort, null);
    pnlSetup.add(fldMulticastPort, null);
    pnlSetup.add(labelFileName, null );
    pnlSetup.add(fieldFileName, null );
    pnlSetup.add(lblNetDataHost, null);
    pnlSetup.add(fldNetDataHost, null);
    pnlSetup.add(lblNetDataPort, null);
    pnlSetup.add(fldNetDataPort, null);
    pnlSetup.add(bttnSetup, null);


    mssgPanel.getViewport().add(mssgArea, null);
  }

  public synchronized void AddMessage ( String mssg )
  {
    mssgArea.append(mssg);
  }

  public void UpdatePacketsRead ( int numPackets )
  {
    labelPacketsSent.setText( "Pckts Read: " + numPackets );
  }

  public void UpdatePacketsWritten ( int numPackets )
  {
    labelPacketsReceived.setText( "Pckts Wrttn: " + numPackets );
  }

  public void UpdateNumClients ( int numClients )
  {
    labelNumClients.setText( "Num Clients: " + numClients );
  }

  public synchronized void windowClosing ( WindowEvent e )
  {
    if ( listenServer != null )
    {
      listenServer.Shutdown();
      try { listenServer.join(2000); }
      catch ( InterruptedException ex ) { }
    }
    System.out.println ( "Serial Forwarder Exited Normally\n" );
    System.exit(1);
  }

  public void windowClosed      ( WindowEvent e ) { }
  public void windowActivated   ( WindowEvent e ) { }
  public void windowIconified   ( WindowEvent e ) { }
  public void windowDeactivated ( WindowEvent e ) { }
  public void windowDeiconified ( WindowEvent e ) { }
  public void windowOpened      ( WindowEvent e ) { }

  void bServerStart_actionPerformed(ActionEvent e)
  {
    if ( listenServer == null )
    {
      UpdateGlobals();
      listenServer = new ListenServer ( this );
      listenServer.start();
    }
  }

  public void UpdateGlobals ( )
  {
    // set application/communications defaults
    SerialForward.useDummyData        = cbDummyData.isSelected();
    SerialForward.useFileData         = cbFileData.isSelected();
    SerialForward.useNetData          = cbNetData.isSelected();
    SerialForward.netDataHost         = fldNetDataHost.getText();
    SerialForward.netDataPort         = Integer.parseInt( fldNetDataPort.getText());
    SerialForward.verboseMode         = cbVerboseMode.isSelected();
    SerialForward.commPort            = fieldSerialPort.getText();
    SerialForward.serverPort          = Integer.parseInt ( fieldServerPort.getText() );
    SerialForward.PACKET_SIZE         = Integer.parseInt ( fieldPacketSize.getText() );
    SerialForward.multicast           = cbMulticast.isSelected();
    SerialForward.multicastGroup      = fldMulticastGrp.getText();
    SerialForward.multicastPort       = Integer.parseInt( fldMulticastPort.getText());
    ParseDummyPacket ( fldDmmyPckt.getText() );
    SerialForward.PACKET_LOCATION     = fldLoc.getText();
    SerialForward.dataFile            = fieldFileName.getText();
  }
  void bStopServer_actionPerformed(ActionEvent e)
  {
    if ( listenServer != null )
    {
      listenServer.Shutdown();
      //listenServer = null;
    }
  }

  public synchronized void SetListenServer ( ListenServer server )
  {
    listenServer = server;
  }

  void bPrintPorts_actionPerformed(ActionEvent e)
  {
    ListenServer.PrintAllPorts ( this );
  }

  void bttnSetup_actionPerformed(ActionEvent e)
  {
    UpdateGlobals();

  }

  private void ParseDummyPacket ( String pcktData )
  {
    int beginByte = 0;
    int endByte = pcktData.indexOf( '.' );
    int currentByte = 0;

    SerialForward.PACKET_DUMMY_DATA = new byte[ (int) SerialForward.PACKET_SIZE];
    while ( endByte != -1 && currentByte < SerialForward.PACKET_SIZE )
    {
      SerialForward.PACKET_DUMMY_DATA [currentByte] = (byte) Integer.parseInt( pcktData.substring( beginByte, endByte ) );
      beginByte = endByte + 1;
      endByte = pcktData.indexOf( '.', beginByte );
      currentByte++;
    }
    byte lastByte = (byte) Integer.parseInt ( pcktData.substring( beginByte ) );
    SerialForward.PACKET_DUMMY_DATA [currentByte] = lastByte;
  }
}