/**
 * File: PacketForwarder.java
 *
 * Description:
 * The PacketForwarder class sends data packet
 * to a connected client.
 *
 * Author: Bret Hull
 */

import java.net.*;
import java.io.*;

public class PacketForwarder
{
  public Socket              socket        = null;
  private ObjectOutputStream  packetStream  = null;
  private InetAddress         localAddress  = null;
  private InetAddress         remoteAddress = null;
  private ControlWindow       cntrlWindow   = null;
  private String              strHstNm      = null;

  public PacketForwarder ( Socket socket, ControlWindow control )
  {
    this.socket = socket;
    strHstNm = socket.getInetAddress().toString();
    localAddress = socket.getLocalAddress();
    remoteAddress = socket.getInetAddress();
    cntrlWindow = control;
    try { packetStream = new ObjectOutputStream ( socket.getOutputStream() ); }
    catch ( IOException e ) { VERBOSE ("Unable to get socket outputstream"); }
    DEBUG ( "PacketForwarder: forwarding setup for host " + strHstNm );
  }

  public boolean packetReceived(byte[] packet)
  {
    DataPckt crrntPckt = new DataPckt ();
    crrntPckt.data = packet;
    crrntPckt.dest = remoteAddress;
    crrntPckt.source = localAddress;

    return SendPacket ( crrntPckt );
  }

  public synchronized boolean SendPacket ( Object pckt )
  {
    try {
      if ( packetStream != null )
      {
        packetStream.writeObject( pckt );
        packetStream.flush();
      }
    }
    catch ( IOException e ) {
      DEBUG ( "PACKETFORWARDER: socket closed on host " + strHstNm );
      return false;
    }
    return true;
  }

  private void ReportMessage ( String msg )
  {
      if ( cntrlWindow == null ) System.out.println (msg);
      else cntrlWindow.AddMessage (msg+"\n");
  }

  private void DEBUG ( String msg )
  {
    if ( SerialForward.debugMode ) { ReportMessage ( msg ); }
  }

  private void VERBOSE ( String msg )
  {
    if ( SerialForward.verboseMode ) { ReportMessage ( msg ); }
  }

  public void CloseSocket ( )
  {
    try { socket.close(); }
    catch ( IOException e ) { DEBUG ( "PacketForwarder unable to close socket" ); }
  }
}