/**
 * File: SerialForward.java
 *
 * Description:
 * The SerialForward class provides many static functions
 * that handle the initialization of the serialforwarder
 * and/or the associated gui.
 *
 * Author: Bret Hull
 */

import java.io.*;
import javax.swing.*;
import java.awt.event.*;

public class SerialForward {

  // appication defaults
  public static boolean       verboseMode   = true;
  public static boolean       debugMode     = false;
  public static boolean       useDummyData  = true;
  public static boolean       useFileData   = false;
  public static boolean       useNetData    = false;
  public static boolean       multicast     = true;
  public static int           serverPort    = 9000;
  public static String        commPort      = "/dev/ttyS0";
  public static String        netDataHost   = "127.0.0.1";
  public static int           netDataPort   = 9000;

  public static String        multicastGroup    = "228.5.6.7";
  public static int           multicastPort     = 6789;
  public static byte          serverMagic       = 49;
  public static byte[]        clientMagic       = { 50, (byte) (serverPort & 0xFF), (byte) ((serverPort & 0xFF00) >> 8) };

  public static int           PACKET_SIZE       = 30;
  public static String        PACKET_LOCATION   = "Unknown";
  public static byte[]        PACKET_DUMMY_DATA = new byte[PACKET_SIZE];

  public static String        dataFile          = "motedata.bin";

  private static boolean      guiMode       = true;
  private static boolean      displayHelp   = false;

  public static void main(String[] args) throws IOException {

    ProcessCommandLineArgs ( args );

    if ( displayHelp )
    {
      PrintHelp ();
    }
    else if ( guiMode )
    {
      System.out.println("Starting in GUI mode\n");
      CreateGui();
    }
    else {
      // no gui, user command line
      RunListenServer();
    }
  }

  private static void ProcessCommandLineArgs ( String[] args )
  {
    if ( debugMode ) {
      for ( int i = 0; i < args.length; i++)
      {
        System.out.println(args[i]);
      }
    }
    for ( int i = 0; i < args.length; i++ )
    {
      if ( args[i].equals ( "-no-gui") ) { guiMode = false; }
      else if (args[i].equals ("-comm" ) )
      {
        i++;
        if ( i < args.length ) { commPort = args[i]; }
        else { displayHelp = true; }
      }
      else if (args[i].equals ("-port" ) )
      {
        i++;
        if ( i < args.length ) { serverPort = Integer.parseInt(args[i]); }
        else { displayHelp = true; }
      }
      else if ( args[i].equals ("-packetsize") )
      {
        i++;
        if ( i < args.length ) { PACKET_SIZE = Integer.parseInt(args[i]); }
        else { displayHelp = true; }
      }
      else if ( args[i].equals ("-loc") )
      {
        i++;
        if ( i < args.length ) { PACKET_LOCATION = args[i]; }
        else { displayHelp = true; }
      }
      else if ( args[i].equals ("-quiet") ) { verboseMode = false; }
      else if ( args[i].equals ("-debug") ) { debugMode = true; }
      else if ( args[i].equals ("-dummy") )
      {
        useDummyData = true;
        useFileData = false;
        useNetData = false;
      }
      else if ( args[i].equals ("-file" ) )
      {
        i++;
        useDummyData = false;
        useFileData = true;
        useNetData = false;
        if ( i < args.length ) { dataFile = args[i]; }
        else { displayHelp = true; }
      }
      else if ( args[i].equals ("-net" ) )
      {
        i+=2;
        useDummyData = false;
        useFileData = false;
        useNetData = true;
        if ( i < args.length ) {
          netDataHost = args[i-1];
          netDataPort = Integer.parseInt( args[i]);
        }
        else { displayHelp = true; }
      }
      else if ( args[i].equals ("-nomulticast") ) { multicast = false; }
      else if ( args[i].equals ("-group" ) )
      {
        i++;
        if ( i < args.length ) { multicastGroup = args[i]; }
        else { displayHelp = true; }
      }
      else if (args[i].equals ("-mport" ) )
      {
        i++;
        if ( i < args.length ) { multicastPort = Integer.parseInt(args[i]); }
        else { displayHelp = true; }
      }
      else { displayHelp = true; }
    }
  }

  private static void PrintHelp ( )
  {
      System.out.println ("optional arguments:");
      System.out.println ("-comm [serial port]");
      System.out.println ("-port [server port]");
      System.out.println ("-packetsize [size]");
      System.out.println ("-no-gui      = do not display graphic interface");
      System.out.println ("-quiet       = non-verbose mode");
      System.out.println ("-debug       = display debug messages");
      System.out.println ("-dummy       = use dummy data");
      System.out.println ("-file [file] = read data from file");
      System.out.println ("-net [host] [port] = read data from network host");
      System.out.println ("-nomulticast = disable multicasting");
      System.out.println ("-group       = multicast group" );
      System.out.println ("-mport       = multicast port" );
      System.out.println ("-loc [location]" );
  }

  private static void CreateGui ( )
  {
      JFrame mainFrame = new JFrame("DataAggregator Client");
      ControlWindow cntrlWindow = new ControlWindow();
      mainFrame.setSize( cntrlWindow.getPreferredSize() );
      mainFrame.getContentPane().add("Center", cntrlWindow);
      mainFrame.show();
      mainFrame.addWindowListener ( cntrlWindow );
  }

  private static void RunListenServer ( )
  {
    ListenServer listener = new ListenServer ( null );
    listener.start();
  }
}