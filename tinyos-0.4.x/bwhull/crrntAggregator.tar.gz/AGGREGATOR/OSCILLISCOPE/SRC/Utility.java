/**
 * Title: Utility.java
 * @author Bret Hull
 * @version 1.0
 */

import javax.swing.tree.*;
import java.util.*;
import java.net.*;

public class Utility {

  public static void ParseMask ( String pcktData, byte[] mask )
  {
    int beginByte = 0;
    int endByte = pcktData.indexOf( '.' );
    int currentByte = 0;

    while ( endByte != -1 && currentByte < mask.length )
    {
      mask[currentByte] = (byte) Integer.parseInt( pcktData.substring( beginByte, endByte ) );

      beginByte = endByte + 1;
      endByte = pcktData.indexOf( '.', beginByte );
      currentByte++;
    }
    if ( beginByte == pcktData.length() || currentByte >= mask.length ) { return; }
    byte lastByte = (byte) Integer.parseInt ( pcktData.substring( beginByte ) );
    mask[currentByte] = lastByte;
  }

  public static int CountBytes ( String pcktData )
  {
    int currentLoc = 0;
    int bytes = 0;
    if ( pcktData == "" ) { return 0; }
    while ( currentLoc != -1 )
    {
      currentLoc = pcktData.indexOf( '.', currentLoc + 1 );
      bytes++;
    }
    return bytes;
  }
  /**
   * Populates the rule tree with all masks that have been registered
   */
  public static void BuildRulesNode ( AppInfo myInfo, DefaultMutableTreeNode nodeRules )
  {
    if ( myInfo.masks.size() == 0 || myInfo.masks.size() == 0 )
    {
      // clear the tree
      nodeRules.removeAllChildren();
      nodeRules.setUserObject( "Rules: (none)" ); }
    else
    {
      // clear the tree
      nodeRules.removeAllChildren ();

      // set the root object
      nodeRules.setUserObject( "Rules: (" + myInfo.masks.size() + ")" );

      Enumeration ruleEnum = myInfo.masks.elements();
      Enumeration hostsEnum = myInfo.hosts.elements();
      byte[] crrntMsk;
      InetAddress crrntHost;
      String mskDsply;
      DefaultMutableTreeNode newChild;

      while ( ruleEnum.hasMoreElements() && hostsEnum.hasMoreElements() )
      {
        // build a node for each mask
        crrntMsk = (byte[]) ruleEnum.nextElement();
        crrntHost = (InetAddress) hostsEnum.nextElement();

        if ( crrntMsk.length == 0 ) {
          mskDsply = "All Packets";
        }
        else {
          mskDsply = new Integer ( crrntMsk[0] ).toString();
          for ( int i = 1; i < crrntMsk.length; i++ )
          {
            mskDsply += "." + crrntMsk[i];
          }
        }
        mskDsply += "/ " + crrntHost.getHostAddress();
        newChild = new DefaultMutableTreeNode ( mskDsply );
        nodeRules.add( newChild );
      }
    }
  }

}