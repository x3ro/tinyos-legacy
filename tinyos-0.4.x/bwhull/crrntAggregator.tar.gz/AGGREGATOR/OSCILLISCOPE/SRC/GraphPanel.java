import java.io.*;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.sql.Time;

public class GraphPanel extends Panel
    implements Runnable, MouseListener, MouseMotionListener, PacketListenerIF {
    boolean debug = false;
    boolean sliding = true;
    oscilloscope graph;

    double bottom, top;
    int start, end;
    Vector cutoff;
    Vector data;
    Vector double_filter;
    Vector small_filter;
    Vector filter;
    Vector marker;
    Point highlight_start, highlight_end;

    GraphPanel(oscilloscope graph) {
	setBackground(Color.white);
 	addMouseListener(this);
 	addMouseMotionListener(this);
	cutoff = new Vector();
	data = new Vector();
	double_filter = new Vector();
	small_filter = new Vector();
	filter = new Vector();
	marker = new Vector();
 	this.graph = graph;
	bottom = 00;
	top = 1024.00;
	start = 0; end = 5000;
	Thread t = new Thread(this);
	t.start();
	//read_data();



    }
    int big_filter;
    int sm_filter;
    int db_filter;



    void add_point(Double val){
	synchronized(data){data.add(val);}
	if(sliding && data.size() > end) {
		start ++;
		end ++;

	}
	repaint(100);
    }
    void add_point_2(Double val){
    int small_filter_feedback = graph.small_feedback.getValue();
    int db_filter_feedback = graph.double_feedback.getValue();
    int big_filter_feedback = graph.big_feedback.getValue();
    int cutoff_val = graph.cutoff.getValue();
	synchronized(data){data.add(val);}
	int value = (int) val.doubleValue();

	sm_filter = sm_filter - (sm_filter >> small_filter_feedback);
	sm_filter += value;
	int sm_val = sm_filter >> small_filter_feedback;

	db_filter = db_filter - (db_filter >> db_filter_feedback);
	db_filter += sm_val;
	int db_val = db_filter >> db_filter_feedback;

	big_filter = big_filter - (big_filter >> big_filter_feedback);
	big_filter += Math.abs((db_filter >> (db_filter_feedback - small_filter_feedback)) - sm_filter);
	int big_val = big_filter >> (big_filter_feedback + small_filter_feedback - 5);

	//System.out.print(small_filter_feedback + " ");
	//System.out.print(db_filter_feedback + " ");
	//System.out.print(big_filter_feedback + " ");
	//System.out.println(cutoff_val + " ");

	//filter.add(new Double(big_val));
	//small_filter.add(new Double(sm_val));
	//double_filter.add(new Double(db_val));
	//cutoff.add(new Double(cutoff_val));
	if(Math.abs(big_val) > cutoff_val){
	  //marker.add(new Double(1024));
	}else{
	  //marker.add(new Double(0));
	}
	graph.time_location.setMaximum(Math.max(end, data.size()));
	if(sliding && data.size() > end) {
		start ++;
		end ++;
		graph.time_location.setValue(end);

	}
	repaint(100);
    }

    void read_data(){
	try{
		FileInputStream fin = new FileInputStream("data");
	byte[] readings = new byte[30];
	int cnt = 0;
	while(fin.read(readings) == 30){
		packetReceived(readings);
	}
	}catch(Exception e){
		e.printStackTrace();
	}
    }

    public void packetReceived(byte[] readings){
	for(int i = 5; i < 24; i += 2){
		int val = readings[i+1] << 8;
		val |= ((int)readings[i]) & 0xff;
		val = val;
		add_point(new Double(val));
	   }
    }

    public void run() {
	//read_data();
        packetReceived ( new byte[30] );
        /*
	SerialForwarderReader r = new SerialForwarderReader("127.0.0.1",9000);

        try{
		r.Open();
		r.registerPacketListener(this);
		r.Read();
	}catch(Exception e){
		e.printStackTrace();
	}*/
    }


    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
	highlight_end.x = e.getX();
	highlight_end.y = e.getY();
	repaint(100);
	e.consume();
    }

    public void mouseMoved(MouseEvent e) {
    }
    public void mouseClicked(MouseEvent e) {
    }
    public void mouseReleased(MouseEvent e) {
	removeMouseMotionListener(this);
	set_zoom();
	highlight_start = null;
	highlight_end = null;
	e.consume();
	repaint(100);
    }
    public void mousePressed(MouseEvent e) {
	addMouseMotionListener(this);
	highlight_start = new Point();
	highlight_end = new Point();
	highlight_start.x = e.getX();
	highlight_start.y = e.getY();
	highlight_end.x = e.getX();
	highlight_end.y = e.getY();
	repaint(100);
	e.consume();
    }

    public void start() {
    }

    public void stop() {
    }
    Image offscreen;
    Dimension offscreensize;
    Graphics offgraphics;
    public synchronized void update(Graphics g) {
    	Dimension d = getSize();
	int end = this.end;
    	graph.time_location.setMaximum(Math.max(end, data.size()));
    	graph.time_location.setValue(end);
    	if ((offscreen == null) || (d.width != offscreensize.width) || (d.height != offscreensize.height)) {
        	offscreen = createImage(d.width, d.height);
        	offscreensize = d;
        	if (offgraphics != null) {
            		offgraphics.dispose();
        	}
        	offgraphics = offscreen.getGraphics();
        	offgraphics.setFont(getFont());
    	}
    offgraphics.setColor(Color.black);
    offgraphics.fillRect(0, 0, d.width, d.height);
    draw_highlight(offgraphics);
    int v_start = Math.max(start, 0);
    Vector small_filter, db_filter, big_filter, third_filter;
    synchronized(data){
    	small_filter = filter(data, v_start, end, graph.small_feedback.getValue());
    db_filter = filter(small_filter, 0, small_filter.size(), graph.double_feedback.getValue());
    	big_filter = filter(diff(small_filter.subList(0, small_filter.size()).iterator(), db_filter.subList(0, db_filter.size()).iterator()), 0, small_filter.size(), graph.big_feedback.getValue());
    	third_filter = filter(diff(data.subList(v_start, Math.min(data.size(), end)).iterator(), db_filter.subList(0, db_filter.size()).iterator()), 0, db_filter.size(), graph.big_feedback.getValue());
    }
    offgraphics.setColor(Color.green);
    draw_data(offgraphics, data, start, end);
    offgraphics.setColor(Color.pink);
    draw_data(offgraphics, small_filter, start - v_start, end - v_start);
    offgraphics.setColor(Color.yellow);
    draw_data(offgraphics, db_filter, start - v_start, end - v_start);
    offgraphics.setColor(Color.red);
    draw_data(offgraphics, big_filter, start - v_start, end - v_start);
    offgraphics.setColor(Color.blue);
    draw_data(offgraphics, third_filter, start - v_start, end - v_start);
   // offgraphics.setColor(Color.pink);
   // draw_data(offgraphics, cutoff);
   // offgraphics.setColor(Color.yellow);
   // draw_data(offgraphics, double_filter);
   // offgraphics.setColor(Color.white);
   // draw_data(offgraphics, small_filter);
   // 	offgraphics.setColor(Color.red);
   // draw_data(offgraphics, filter);
   // 	offgraphics.setColor(Color.blue);
   // draw_data(offgraphics, marker);
    g.drawImage(offscreen, 0, 0, null);
    }
    Vector filter(Vector data, int start, int end, int feedback){
	if(start < 0) start = 0;
	if(end > data.size()) end = data.size();
	Iterator vals = data.subList(start, end).iterator();
	Vector newv = new Vector();
	int filter_val = (int)((Double)data.get(start)).doubleValue() << feedback;
	while(vals.hasNext()){
		filter_val -= filter_val >> feedback;
		filter_val += (int)((Double)vals.next()).doubleValue();
		newv.add(new Double(filter_val >> feedback));
	}
	return newv;
    }

    Vector diff(Iterator a, Iterator b){
	Vector vals = new Vector();
	while(a.hasNext() && b.hasNext()){
	  	vals.add(new Double(40* Math.abs(((Double)a.next()).doubleValue() - ((Double)b.next()).doubleValue())));
	}
	return vals;
    }

    void draw_highlight(Graphics g){
    	if(highlight_start == null) return;
	int x, y, h, l;
	x = Math.min(highlight_start.x, highlight_end.x);
	y = Math.min(highlight_start.y, highlight_end.y);
	l = Math.abs(highlight_start.x - highlight_end.x);
	h = Math.abs(highlight_start.y - highlight_end.y);
	g.setColor(Color.white);
	g.fillRect(x,y,l,h);
    }


    void draw_data(Graphics g, Vector data, int start, int end){
	double h_step_size = (double)getSize().width / (double)(end - start);
	double v_step_size = (double)getSize().height / (double)(top-bottom);
	if(end > data.size()) end = data.size();
	//System.out.println("data.length: " + data.size());
	//System.out.println("h_step_size: " + h_step_size);
	//System.out.println("v_step_size: " + v_step_size);
	//System.out.println("start: " + start);
	//System.out.println("length: " + (end - start));
	//System.out.println("bottom: " + bottom);
	//System.out.println("height: " + (top - bottom));

	int base = getSize().height;
	for(int i = 0; i < end - start - 1; i ++){
	   int x1, y1, x2, y2;
	   if((start + i) >= 0){
	     x1 = (int)(h_step_size * (double)i);
	     y1 = (int)((((Double)(data.get(start + i))).doubleValue() - bottom) * v_step_size);
	     y1 = base - y1;
	     x2 = (int)(h_step_size * (double)(i + 1));
	     y2 = (int)((((Double)(data.get(start + i + 1))).doubleValue() - bottom) * v_step_size);
	     y2 = base - y2;
	     g.drawLine(x1, y1, x2, y2);
	   }
	}
    }
    void move_up(){
	double height = top - bottom;
	bottom += height/4;
	top += height/4;

    }

    void move_down(){
	double height = top - bottom;
	bottom -= height/4;
	top -= height/4;

    }

    void move_right(){
	int width = end - start;
	start += width/4;
	end += width/4;

    }

    void move_left(){
	int width = end - start;
	start -= width/4;
	end -= width/4;

    }

    void zoom_out_x(){
	int width = end - start;
	start -= width/2;

    }

    void zoom_out_y(){
	double height = top - bottom;
	bottom -= height/2;
	top += height/2;

    }

    void zoom_in_x(){
	int width = end - start;
	start += width/2;

    }

    void zoom_in_y(){
	double height = top - bottom;
	bottom += height/4;
	top -= height/4;

    }

    void set_zoom(){
	double h_step_size = (double)getSize().width / (double)(end - start);
	double v_step_size = (double)getSize().height / (double)(top-bottom);
	int base = getSize().height;
	int x_start = Math.min(highlight_start.x, highlight_end.x);
	int x_end = Math.max(highlight_start.x, highlight_end.x);
	int y_start = Math.min(base - highlight_start.y, base - highlight_end.y);
	int y_end = Math.max(base - highlight_start.y, base - highlight_end.y);

	if(Math.abs(x_start - x_end) < 10) return;
	if(Math.abs(y_start - y_end) < 10) return;

	end = start + (int)((double)x_end / h_step_size);
	start = start + (int)((double)x_start / h_step_size);
	top = bottom + (double)((double)y_end / v_step_size);
	bottom = bottom + (double)((double)y_start / v_step_size);
    }

}
