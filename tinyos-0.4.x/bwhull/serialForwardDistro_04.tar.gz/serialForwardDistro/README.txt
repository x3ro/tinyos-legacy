Serial-Port Forwarding Server

Bret Hull (bwhull@uclink4.berkeley.edu)

INCLUDED FILES

SerialForwarder.jar	- serial-port forwarding server
serversrc.tar.gz	- source code to the forwading server
logger.jar		- client app that logs packets from a 
			  a forwarding server to a file
loggersrc.tar.gz	- source code to logger app
oscilloscope.jar	- sample app that connects to a forwarding
			  server and graphs the data as it arrives
oscilloscopesrc.tar.gz	- source code to oscilloscope app


To run any of the applications packaged as a jar file execute
the following command:

java -jar [jar file]

Example

java -jar SerialForwarder.jar -no-gui -comm /dev/ttyS1 -port 25

( starts the serial-port forwarder without a gui forwarding
  /dev/ttyS1 to all clients that connect to port 25 )

Serial-Port Forwarder Server optional arguments:

-comm [serial port]
-port [server port]
-packetsize [size]
-no-gui      = do not display graphic interface
-quiet       = non-verbose mode
-no-debug    = non-debug mode
-dummy       = use dummy data


